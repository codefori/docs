==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0

   (c) Copyright IBM Corporation 1996, 2019. Todos os direitos
reservados. 

==============================================================================
  Este documento é fornecido "tal como está" sem qualquer tipo de garantia.  A IBM rejeita quaisquer garantias,
  explícitas ou implícitas, incluindo sem limitação, as
  garantias implícitas de adequação a um determinado
  fim e comercialização no que respeita às informações contidas
  neste documento. Através da disponibilização deste documento, a IBM não
  concede licenças relativas a quaisquer patentes ou direitos de autor. 

===============================================================================

Este documento foi actualizado pela última vez a: 4 de Novembro de 2019

------------------------------------------------------------------- 

ÍNDICE 

-------------------------------------------------------------------  

1.0 Introdução
2.0 Localização de Fontes de Informação
3.0 Instalação
  3.1 Sistemas Operativos Windows Suportados
  3.2 Considerações da Instalação
  3.3 Actualizar a partir do IBM i Access for Windows
  3.4 Executar a Instalação
  3.5 Acção Requerida Após Instalar o Controlador de Impressora
  3.6 Considerações de instalação de hardware de 64 bits
  3.7 Registos da instalação
4.0 Requisitos de IBM.Data.DB2.iSeries .NET Provider
5.0 Microsoft XML Parser ou Microsoft XML Core Services
6.0 Informações de Instalação Avançadas
  6.1 Informações do Produto Licenciado
  6.2 Ficheiros de Idioma na Imagem de Instalação
  6.3 Componentes de Instalação
  6.4 Opções da linha de comandos
  6.5 Propriedades Públicas
  6.6 Gravar Imagens Administrativas para CD ou DVD
7.0 Informações de Políticas
8.0 Comandos Não Incluídos
  


-------------------------------------------------------------------

1.0 Introdução
-------------------------------------------------------------------
  Este pacote faz parte do produto 5733XJ1 IBM i Access Client Solutions.

  Pode utilizar o IBM i Access Client Solutions para estabelecer ligação a qualquer edição suportada do IBM i.

  Este pacote contém funções que apenas estão disponíveis em sistemas operativos Windows. É baseado no produto IBM i Access for Windows versão 7.1, mas não contém todos os componentes.

  Os componentes incluídos neste pacote do IBM i Access for Windows são:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer e Gestão de Certificados
    Toolkit do Programador para Cabeçalhos, Bibliotecas e Documentação
    Controlador de Impressora AFP
    Programas Requeridos incluindo:
      APIs
      Active X
      Segurança
      Funcionalidade
      Ligações
      Activação NLS
      Tabelas de conversão
      Propriedades
      Políticas
      Impressão de Rede
      Subconjunto de comandos (Consulte a Secção 8.0 para visualizar uma lista do que não está incluído.)
      Guia do Utilizador
      Utilização da Administração da Aplicação para controlar o acesso à função no pacote

  Os seguintes componentes do IBM i Access for Windows não estão incluídos neste pacote. 
  O pacote independente de plataforma IBM i Access Client Solution inclui um substituto para estes componentes:
    Emulador de Monitor e Impressora 5250
    Transferência de Dados
    Suplemento do Excel de Transferência de Dados
    Consola de Operações

  Os seguintes componentes do IBM i Access for Windows não estão incluídos neste pacote. 
  O IBM Navigator for i inclui um substituto para estes componentes:
    System i Navigator
    AFP Workbench Viewer

  O Comando Remoto de Entrada não está incluído.  Em substituição, pode utilizar os Serviços de Ambiente de Trabalho Remoto da Microsoft.

  O Toolbox para Java também não está incluído. Utilize o seguinte sítio da Web para descarregar informações:

  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Outros componentes do IBM i Access for Windows não incluídos neste pacote são:
    Controlador de Impressora SCS
    Suplementos de Ferramentas de Programador de Java para o System i Navigator
    Actualização de Directórios
    Suporte de Formato de Ficheiros Lotus 123
    Verificação de Nível de Serviço

  Como o conteúdo deste pacote também é enviado com o IBM i Access for Windows versão 7.1,
  a documentação e o arquivo de versões reflecte frequentemente o IBM i Access for Windows versão 7.1 no Guia do Utilizador, Toolkit do Programador, texto e mensagens de ajuda, mas também é aplicável ao IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Localização de Fontes de Informação

  - Alterações ao IBM i Access Client Solutions incluindo sistemas operativos suportados, actualizações, restrições, problemas conhecidos significativos, novas informações e mais serão publicadas no sítio da Web do produto IBM i Access:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - O Guia do Utilizador que é instalado com este pacote contém informações sobre como utilizar o produto, algumas sugestões e técnicas, mensagens, e informações de resolução de problemas.

  - As referências técnicas para o fornecedor OLE DB e o .NET Data Provider são instaladas quando o componente Cabeçalhos, Bibliotecas e Documentação é instalado. Pode encontrar as referências técnicas na pasta do Toolkit do Programador.

  - O Information Center do IBM i faculta uma colecção de tópicos concebidos para profissionais do IBM i que necessitam de acesso a informações técnicas:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Na altura desta publicação, o Information Center do IBM i não incluía tópicos sobre o IBM i Access Client Solutions. Porém, muitas das informações sobre o IBM i Access for Windows é aplicável a este pacote do IBM i Access Client Solutions, incluindo os tópicos sobre a instalação, administração e programação: 

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - O IBM i developerWorks contém artigos, guias de iniciação, e recursos técnicos para utilizadores do IBM i:

    https://www.ibm.com/developerworks/ibmi

  - O sítio da Web do IBM i oferece as últimas notícias sobre o IBM i, assim como informações sobre o produto, uma biblioteca de referências, planos de educação, e mais:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Informações de Instalação
-------------------------------------------------------------------



3.1 Sistemas Operativos Windows Suportados
---------------------------------------

  Este pacote pode ser instalado nos seguintes sistemas operativos Windows:

   

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
   - Windows Server 2008 and Windows Server 2008 R2 Standard Enterprise (32-bit and 64bit)
   - Windows 7 Professional, Enterprise, and Ultimate (32-bit and 64-bit)

   Aplicam-se as seguintes restrições:
     a) As edições Home não são suportadas.
     b) Tem de utilizar níveis de pacote de serviços Windows que a Microsoft suporta.
     c) O suporte será descontinuado na data em que a Microsoft cancelar o suporte.
     d) A instalação não é suportada em hardware Itanium.
     e) Utilize as recomendações do hardware e memória do Microsoft Windows. Inclua 256 MB adicionais de memória para as funções do IBM i Access Client Solution.
     f) Não é possível instalar o produto quando estiver a actualizar para um sistema operativo Windows diferente. Execute os seguintes passos:
          1.  Guarde os dados da configuração.
2.  
Desinstale o produto.
3.  
Actualize o sistema operativo Windows.
4.  
Instale o produto.
5.  
Restaure os dados da configuração.


3.2 Considerações da Instalação
--------------------------------------------------

  - São necessários autoridade e privilégios administrativos para executar a instalação.

  - Apenas são suportadas instalações por máquina. Não são suportadas instalações por utilizador.

  - O Windows Installer 4.5 é requerido. Este componente de software da Microsoft é instalado durante a instalação caso não se encontre já presente no sistema. Pode instalar o componente antes da instalação ao descarregar o mesmo a partir do sítio da Web da Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Actualizar a partir do IBM i Access for Windows
-------------------------------------------

  -  A actualização a partir do IBM i Access for Windows não é suportada.  Tem de remover o IBM i Access for Windows
     antes de instalar este pacote.  

  -  Consulte a Secção 1.0 para visualizar a lista de componentes que não estão incluídos. Se
     pretende continuar a utilizar os componentes no IBM i Access for Windows não
     incluídas neste pacote, não instale este pacote e continue a utilizar o
     pacote de correcções mais recente, 7.1, do IBM i Access for Windows.

  -   Quando o IBM i Access for Windows for desinstalado, a configuração de
     de sistema existente será eliminada. Para preservar a configuração de
     sistema existente, é necessário guardar a configuração antes
     de desinstalar o IBM i Access for Windows e, em seguida, restaurar a
     configuração após o IBM i Access Client Solutions Windows Application
     Package ter sido instalado.

     Aqui ficam os passos detalhados para guardar e restaurar a configuração:
     1.  Utilize o comando CWBBACK para salvaguardar a configuração do
         IBM i Access for Windows. cwbback <nomeficheiro.rs> /u
         Por exemplo:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Este exemplo assume que a pasta C:\Users\IBM_ADMIN\Backup já existe.

         O comando anterior irá criar dois ficheiros:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	        Certifique-se de que estes dois ficheiros foram criados antes de avançar para o passo seguinte.


         NOTA:
         Se os dois ficheiros mencionados anteriores não tiverem sido criados, então não terá uma
         configuração guardada. Tente executar o comando como um administrador elevado.
         Uma forma para o fazer será iniciar a linha de comandos da seguinte forma:
             Iniciar->Todos os Programas->Acessórios->Linha de Comandos
         Mas em vez de fazer clique com o botão esquerdo na Linha de Comandos,
         utilize o botão direito do rato e seleccione a opção "Executar como administrador".
         Execute o comando anterior cwbback através da linha de comandos.
         Certifique-se de que os dois ficheiros mencionados anteriormente foram criados antes de avançar para o passo seguinte.


     2.  
Desinstale o IBM i Access for Windows.
3.  
Reinicie.
4.  
Instale o IBM i Access Client Solutions Windows Application Package.
     5.  
Reinicie.
6.
Utilize o comando CWBREST para restaurar a configuração guardada com
o comando CWBBACK.
             cwbrest <nomeficheiro.rs> /c
         Por exemplo:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Caso seja necessário seguir as instruções na NOTA do passo
         1, também precisará de executar o comando cwbrest a partir de
         uma linha de comandos de administrador elevado.


  -  Existem algumas formas através das quais pode verificar a
     configuração do Windows antes e depois dos seguintes passos:
     1. Verificar o registo do Windows.  As configurações de sistema estão armazenadas em:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Para ver os conteúdos do registo do Windows nessa localização, insira este comando:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"

        Se tiver um ambiente com um nome diferente do nome predefinido
        "My Connections", efectue a substituição adequada no caminho mencionado anteriormente.


     2. Se tiver a versão de plataforma independente do IBM i Access Client Solutions no mesmo PC,
        a partir da interface gráfica do utilizador principal pode seleccionar:
               Ficheiro->Copiar Ligações
        O lado direito irá apresentar "IBM i Access (Windows)".
Esta é a configuração utilizada para o IBM i Access for Windows e para o IBM i Access Client Solutions Windows Application Package.


3.4 Executar a Instalação
-----------------------

  - Execute o ficheiro setup.exe na imagem de instalação para iniciar a mesma.  (O comando
    cwblaunch.exe não é enviado com este produto.)      NOTA:  A invocação directa de ficheiros do Microsoft Installer (MSI) não é recomendada, pois o setup.exe utiliza o setup.ini para uma lista de opções de linha de comandos a serem utilizadas e para actualizar a versão do Windows Installer, caso seja necessário.

  - Recomenda-se a utilização da pasta de destino predefinida. Porém, caso altere a pasta:

     a) Não seleccione o directório raiz de uma unidade.
     b) Não seleccione um directório que já contenha ficheiros não relacionados com este produto.
     c) Não seleccione uma unidade de rede. A opção de
         instalação numa unidade de rede não é suportada.


3.5 Acção Requerida Após Instalar o Controlador de Impressora
---------------------------------------------------

  Se instalar o controlador de impressora APF, terá de executar alguns procedimentos antes de utilizar o controlador de impressora. Isto é necessário, pois não é possível adicionar ou actualizar o controlador de impressora durante a instalação, uma vez que o controlador de impressora não é digitalmente assinado pela Microsoft. 

  Durante a instalação, os ficheiros do controlador de impressora são copiados para um subdirectório denominado CWBAFP sob o caminho de destino que é seleccionado. Partindo do princípio que o utilizador instalou para o caminho de destino predefinido, o caminho seria:

  c:\Program Files\IBM\Client Access\CWBAFP directory 

  Utilize as direcções da Microsoft no seu texto de ajuda para adicionar ou actualizar o controlador de impressora.
  Quando for pedido, especifique o caminho para CWBAFP. 

  Se estiver a efectuar a instalação num PC com o IBM i Access for Windows actualizado sobre várias edições, algumas informações antigas serão, possivelmente, apresentadas ao configurar o controlador de impressora. Para remover as
  informações obsoletas dos ficheiros .inf, faça o seguinte após
  ter concluído a instalação:
    a) Abra uma janela da linha de comandos.
    b) Mude para o directório da instalação. O directório de
       instalação predefinido é c:\Program Files\IBM\Client Access.
    c) Insira "cwbrminf" e prima Enter. 


3.6 Considerações de instalação de hardware de 64 bits
-----------------------------------------------

  Quando for instalado num sistema operativo de 64 bits suportado do Windows:

  -  Tanto a versão de 32 bits como a versão de 64 bits são instaladas para ODBC, OLE DB, ActiveX, e Secure Sockets Layer (SSL).  

  -  O .NET Provider do IBM i Access for Windows é executado em aplicações de 32 e 64 bits, dependendo da aplicação que pede o fornecedor.

  -  Apenas é instalada uma versão do Controlador de Impressora AFP. A versão de 64 bits é instalada em sistemas de 64 bits, e a versão de 32 bits é instalada em sistemas de 32 bits. 


3.7 Registos de Instalação
---------------------

  São criados dois registos durante a instalação. Um dos registos é específico do XJ1 e contém as informações de acção personalizada do produto. Este registo é denominado "xe1instlog.txt" e é sempre criado no directório temporário do utilizador. 

  O outro registo é o registo de MSI da Microsoft MSI que contém informações sobre
  eventos, sequências e propriedades de MSI. Por predefinição, este registo é denominado "xe1instlogmsi.txt" e é criado no directório temporário do utilizador. Pode alterar esta opção editando o
  ficheiro setup.ini na imagem de instalação. Aceda à palavra-chave [Startup],
  localize e edite esta entrada: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Para impedir a criação do registo, remova a entrada
    - Para alterar a localização e o nome do registo, altere o caminho e o nome do ficheiro
    - Para alterar o conteúdo do registo, altere /l* para uma opção diferente, conforme
      descrito nas Opções de Linha de Comandos do MSDN Windows Installer da Microsoft,
      na seguinte localização 

      http://msdn.microsoft.com/default.aspx   

  As informações de linha de comandos predefinidas em setup.ini podem ser sobrepostas ao iniciar o setup.exe na linha de comandos com opções da linha de comandos. 



-------------------------------------------------------------------

4.0 Requisitos do IBM.Data.DB2.iSeries .NET Provider 

-------------------------------------------------------------------

  - O IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries)
    requer que o Microsoft .NET Framework Versão 2.0 ou posterior esteja instalado no
    sistema. A maioria dos PCs com sistemas operativos da Microsoft suportados em execução já têm o .NET Framework requerido instalado. O .NET Framework pode ser descarregado no seguinte sítio da Microsoft na Web: 

    http://www.microsoft.com/net 

  - De modo a evitar interromper aplicações .NET escritas para a interface do .NET Provider do Access
    for Windows 5.3 ou 5.4, os pedidos de tempo de execução para a versão 10.0.0.0 do fornecedor
    .NET têm de ser redireccionados para a versão 12.0.0.0.  Consulte o tópico
    "Alterações incompatíveis das versões 5.3 e 5.4" na Referência Técnica de IBM DB2 for i
    .NET Provider para obter instruções sobre como utilizar um ficheiro app.config,
    um ficheiro web.config ou um ficheiro machine.config e para obter informações sobre como seleccionar um
    compilador apropriado para redireccionar aplicações existentes.

    Em alternativa, a aplicação pode ser recompilada utilizando um novo compilador para visar
    a versão 12.0.0.0 do fornecedor .NET incluída na edição 7.1 do IBM i Access for
    Windows.

  - Para obter todas as informações e uma lista de alterações incompatíveis, instale o componente Cabeçalhos, Bibliotecas e Documentação, e em seguida consulte a Referência Técnica do .NET Provider. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser ou Microsoft XML Core Services

-------------------------------------------------------------------

  Ao utilizar os objectos de automatização ActiveX da Transferência de Dados do IBM i Access for Windows para transferir ficheiros de e para o formato XML do Microsoft Excel suportado pelo Excel 2003 e pelo Excel XP), é necessário instalar software adicional no PC. Este componente requer que o Microsoft XML Parser 3.0 ou posterior, também designado por Microsoft XML Core Services, esteja instalado no seu computador pessoal. O XML Parser está incluído em vários produtos
  Microsoft. Para determinar se o suporte de XML Parser está instalado no PC, consulte o
  artigo KB 278674 da Microsoft. Este artigo encontra-se no sítio da Microsoft na Web, em:

  http://support.microsoft.com/kb/278674

  Se o Microsoft XML Parser 3.0 ou posterior não for encontrado, será necessário aceder ao
  sítio da Microsoft na Web para obter instruções sobre como descarregar e instalar o XML Parser, antes
  de poder utilizar o suporte de Transferência de Dados XML. Consulte o artigo KB 324460 da Microsoft
  para obter informações sobre a instalação do XML Parser. Este artigo encontra-se em:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Informações de Instalação Avançadas

-------------------------------------------------------------------

  Pode utilizar a maior parte das informações sobre modificar o nível de interface do utilizador, a utilização de parâmetros da linha de comandos, controlar outros comportamentos de instalação e métodos de implementação no tópico "Configurar o PC" no Information Center do IBM i para o IBM i Access for Windows. As diferenças estão descritas nesta secção. 


6.1 Informações do Produto Licenciado
----------------------------------

  5733XJ1 não é fornecido como um Produto Licenciado para ser instalado no sistema operativo IBM i.
  Apenas está disponível como suporte de PC. É possível copiar o mesmo para o IBM i numa localização que esteja disponível para os seus utilizadores, caso assim o pretenda. 

6.2 Ficheiros de Idioma na Imagem de Instalação
--------------------------------------------

  Os ficheiros de instalação de idioma já não estão separados em três directórios MRI29xx diferentes na imagem de instalação. Em vez disso, existem ficheiros cab separados para cada idioma. Não é possível remover estes ficheiros cab da imagem. 


6.3 Componentes de Instalação
--------------------

  Alguns componentes de instalação no IBM i Access for Windows dependiam da instalação de outros componentes de instalação. Esta restrição não é aplicável a este pacote. 

  É necessário estarem instalados os seguintes componentes de instalação:
    req (Programas Requeridos)
    langacs, amri2924 (Inglês)

  Todos os outros componentes de instalação são instalados por predefinição, mas é possível alterar a definição. 

  Os idiomas são agora componentes de instalação, tal como Programas Requeridos, ODBC, etc. Dado que os idiomas são componentes de instalação, é possível controlar que idiomas são instalados utilizando os mesmos métodos utilizados para controlar qualquer componente de instalação. Os nomes de componente de instalação para os idiomas são amri29xx.  


6.4 Opções da linha de comandos
------------------------

  As opções predefinidas da linha de comandos são especificadas no ficheiro setup.ini incluído na imagem de instalação. Estas opções serão ignoradas caso setup.exe seja invocado a partir da linha de comandos com quaisquer opções especificadas. 

  Se estiver a utilizar uma conversão na linha de comandos, os valores da linha de comandos em setup.ini serão ignorados, dado que a conversão é uma opção. Irá necessitar de incluir outras opções na linha de comandos, tal como as informações de registo. 

  Consulte a Secção 3.7 Registos de Instalação para obter mais informações. 


6.5 Propriedades Públicas
---------------------

  Algumas das propriedades públicas do IBM i Access for Windows são aplicáveis a este pacote. A utilização tem algumas diferenças da utilização no IBM i Access for Windows, conforme descrito aqui: 

  CWBINSTALLTYPE   Esta propriedade é utilizada apenas numa instalação pela primeira vez. Os únicos valores são Typical e Custom. A predefinição é Typical.
                   Exemplo:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   O idioma principal predefinido é a região do seu PC. Esta propriedade permite ao utilizador especificar um idioma principal diferente. O valor a utilizar é MRI29xx. 
                   Exemplo:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   A utilização desta propriedade é a mesma que no IBM i Access for Windows.  Permite ao utilizador actualizar os ficheiros SSL durante uma actualização. Caso os ficheiros de configuração para SSL sejam encontrados no PC de destino, os ficheiros serão actualizados com os certificados mais recentes. Os valores são Yes e No. A predefinição é Yes.
                   Exemplo:  setup /vCWBUPGSSLFILES=NO

  As propriedades comuns do Windows Installer listadas no tópico do Information Center do IBM i Access for Windows permanecem aplicáveis: ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR. 

  Existe uma restrição sobre a utilização da propriedade REBOOT Windows Installer com o IBM i Access
  for Windows. Esta restrição não é aplicável a este pacote. 

6.6 Gravar Imagens Administrativas para CD ou DVD
----------------------------------------------

  Devido a problemas na forma como algum software de gravação de CDs e DVDs processa nomes de ficheiros longos, a gravação de uma imagem administrativa num CD ou DVD não é recomendada. Se ocorrerem problemas ao efectuar a instalação a partir de um CD ou DVD que
      contenha uma imagem administrativa do IBM i Access for Windows, copie a imagem para um
      directório na unidade de disco local e execute o ficheiro setup.exe a partir da
      cópia local.

-------------------------------------------------------------------
7.0 Informações de Políticas
-------------------------------------------------------------------

  É utilizado o mesmo ficheiro de políticas para este pacote e para o IBM i Access for Windows. Isso significa que algumas destas políticas não são aplicáveis quando são utilizadas para este pacote, dado que alguns dos componentes no IBM i Access for Windows não existem neste pacote. 

-------------------------------------------------------------------

8.0 Comandos
-------------------------------------------------------------------

  Os comandos no IBM i Access for Windows que não estão incluídos neste pacote:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe


   [FIM DO DOCUMENTO]
