==============================================================================

            5733XJ1 IBM i Access Client Solutions - Module d'application Windows 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Tous droits réservés. 

==============================================================================
  Ce document vous est concédé "en l'état" sans garantie d'aucune sorte.  IBM décline toute responsabilité, expresse ou implicite,
  relative aux informations contenues dans le présent document,
  y compris en ce qui concerne les garanties de qualité marchande ou
  d'adaptation à vos besoins. Par la remise de ce document, IBM
  n'accorde aucune licence sur quelque brevet ou copyright que ce soit. 

===============================================================================

Date de la dernière mise à jour de ce document : 4 novembre 2019

------------------------------------------------------------------- 

TABLE DES MATIERES 

-------------------------------------------------------------------  

1.0 Introduction
2.0 Emplacement des sources d'information
3.0 Installation
  3.1 Systèmes d'exploitation Windows pris en charge
  3.2 Remarques relatives à l'installation
  3.3 Mise à niveau d'IBM i Access for Windows
  3.4 Exécution de l'installation
  3.5 Action requise après l'installation du pilote d'imprimante
  3.6 Remarques sur l'installation en environnements 64 bits
  3.7 Historiques d'installation
4.0 Conditions requises pour le fournisseur .NET IBM.Data.DB2.iSeries
5.0 Microsoft XML Parser ou Microsoft XML Core Services
6.0 Informations d'installation avancées
  6.1 Informations de logiciel sous licence
  6.2 Fichiers langue dans l'image d'installation
  6.3 Dispositifs d'installation
  6.4 Options de ligne de commande
  6.5 Propriétés publiques
  6.6 Gravure d'images d'administration sur des CD-ROM ou des DVD-ROM
7.0 Informations de stratégie
8.0 Commandes non incluses
  


-------------------------------------------------------------------

1.0 Introduction
-------------------------------------------------------------------
  Ce module fait partie du produit IBM i Access Client Solutions (5733XJ1).

  Vous pouvez utiliser IBM i Access Client Solutions pour vous connecter à n'importe quelle édition IBM i
  prise en charge.

  Ce module contient des fonctions disponibles uniquement sur les systèmes d'exploitation
  Windows.  Il est basé sur le produit IBM i Access for Windows 7.1, mais il ne contient pas tous
  les dispositifs de celui-ci.

  Les dispositifs inclus dans ce module d'IBM i Access for Windows sont les suivants :
    .NET Data Provider
    ODBC
    OLE DB
    Fonction SSL et Gestion de certificats
    Boîte à outils de programmation IBM i Access for Windows (en-tête, bibliothèques et documentation)
    Pilote d'imprimante AFP
    Programmes requis, notamment :
      API
      Active X
      Sécurité
      Maintenabilité
      Connexions
      Activation NLS
      Tables de conversion
      Propriétés
      Stratégies
      Impression réseau
      Sous-ensemble de commandes (pour obtenir une liste des éléments non inclus, voir la section 8.0.)
      Guide d'utilisation
      Utilisation de la fonction Administration d'applications pour contrôler l'accès aux fonctions du module

  Les dispositifs d'IBM i Access for Windows non inclus dans ce module sont répertoriés ci-après. 
  Le module d'IBM i Access Client Solution non tributaire de la plateforme comporte un dispositif de remplacement
  pour les dispositifs suivants :
    Emulation écran et imprimante 5250
    Transfert de données
    Fonction complémentaire Excel pour le transfert de données
    Operations Console
  
  Les dispositifs d'IBM i Access for Windows non inclus dans ce module sont répertoriés ci-après. 
  IBM Navigator for i comporte un dispositif de remplacement pour les dispositifs suivants :
    System i Navigator
    AFP Workbench Viewer

  Le dispositif Commande à distance entrante n'est pas inclus.  Il est remplacé par la fonction
  Services Bureau à distance de Microsoft.

  Toolbox for Java est également absent.  Pour les informations de téléchargement,
  consultez le site Web suivant :
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Les autres dispositifs d'IBM i Access for Windows qui ne sont pas inclus dans ce module sont les suivants :
    Pilote d'imprimante SCS
    Outils de programmation Java pour les modules d'extension System i Navigator
    Mise à jour de répertoire
    Support du format de fichier Lotus 123
    Vérification du niveau de maintenance

  Etant donné que le contenu de ce module est également livré avec IBM i Access for Windows 7.1,
  la documentation et les versions font souvent référence à IBM i Access for Windows 7.1 dans
  le guide d'utilisation, la boîte à outils de programmation, le texte d'aide et les messages, mais
  ces informations s'appliquent également au module d'application Windows d'IBM i Access Client Solutions.


-------------------------------------------------------------------

2.0 Emplacement des sources d'information

-------------------------------------------------------------------

  - Les modifications apportées à IBM i Access Client Solutions, notamment les systèmes d'exploitation
    pris en charge, les mises à jour, les restrictions, les problèmes majeurs connus et les nouveautés, seront
    publiées sur le site Web du produit IBM i Access :

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Le guide d'utilisation qui est installé avec ce module contient des informations relatives à l'utilisation
    du produit et comporte des conseils et des techniques, ainsi que des messages et des informations
    d'identification et de résolution des incidents.

  - Des références techniques au fournisseur OLE DB et au fournisseur .NET Data Provider sont installées en même
    temps que le dispositif En-tête, bibliothèques et documentation.  Les références techniques se trouvent dans
    le dossier Boîte à outils de programmation.

  - L'IBM i Information Center offre un ensemble de rubriques destinées aux spécialistes de l'IBM i
    qui ont besoin d'accéder à des informations techniques :

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Au moment de la publication du présent document, l'IBM i Information Center ne comportait pas de
    rubriques concernant IBM i Access Client Solutions.  Toutefois, la plupart des informations décrites pour IBM i Access
    for Windows s'applique à ce module d'IBM i Access Client Solutions, notamment les rubriques relatives à l'installation,
    à l'administration et à la programmation :

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks contient des articles, des tutoriels et des ressources techniques pour
    les utilisateurs de l'IBM i :

    https://www.ibm.com/developerworks/ibmi

  - Le site Web d'IBM i permet d'accéder aux toutes dernières nouvelles concernant IBM i, aux informations produit, à une
    bibliothèque de référence, aux informations sur le cursus de formation, etc :

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Informations relatives à l'installation
-------------------------------------------------------------------



3.1 Systèmes d'exploitation Windows pris en charge
---------------------------------------------------

  Ce module peut être installé sur les systèmes d'exploitation Microsoft Windows
  suivants :

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 et Windows Server 2008 R2
         Standard Enterprise (32 bits et 64 bits)
   - Windows 7
         Professionnel, Entreprise et Intégrale (32 bits et 64 bits)

   Les restrictions suivantes s'appliquent :
 
     a) Les éditions familiales ne sont pas prises en charge.
     b) Vous devez utiliser les niveaux de service pack Windows acceptés par Microsoft.
     c) L'arrêt du support entrera en vigueur à une date fixée par Microsoft.
     d) L'installation n'est pas prise en charge sur du matériel Itanium.
     e) Utilisez les recommandations Microsoft Windows en matière de mémoire et de matériel. Ajoutez
        256 Mo de mémoire supplémentaires pour les fonctions IBM i Access Client Solutions.
     f) Le produit ne peut pas être installé lors de la mise à niveau vers un autre système d'exploitation
        Windows.  Vous devez effectuer les étapes suivantes :
          1.  Sauvegarder les données de configuration.
          2.  Désinstaller le produit.
          3.  Mettre à niveau le système d'exploitation Windows.
          4.  Installer le produit.
          5.  Restaurer les données de configuration.


3.2 Remarques relatives à l'installation
--------------------------------------------------

  - Les droits et autorisations de niveau administrateur sont requis pour
    exécuter l'installation.
  
  - Seules les installations par machine sont prises en charge.  Les installations par utilisateur ne sont pas
    acceptées.

  - Windows Installer 4.5 est requis.  Ce composant logiciel Microsoft est installé en même
    temps que le produit s'il ne figure pas déjà sur le système.  Vous pouvez installer ce composant
    logiciel avant de procéder à l'installation du produit en le téléchargeant depuis le site Web de Microsoft :

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Mise à niveau d'IBM i Access for Windows
-------------------------------------------

  -  La mise à niveau d'IBM i Access for Windows n'est pas prise en charge.  Vous devez
     retirer IBM i Access for Windows avant d'installer ce module.  

  -  Pour connaître les dispositifs qui ne sont pas inclus, reportez-vous à la section 1.0.  Si
     vous souhaitez continuer d'utiliser des dispositifs d'IBM i Access for Windows qui ne sont
     pas inclus dans ce module, n'installez pas ce module et continuer d'utiliser le dernier
     module de mise à jour de la version 7.1 d'IBM i Access for Windows.

  -  Lorsque IBM i Access for Windows est désinstallé, la configuration
     système existante est supprimée. Pour conserver la configuration
     système existante, vous devez la sauvegarder avant de désinstaller
     IBM i Access for Windows, puis la restaurer une fois IBM i
     Access Client Solutions Windows Application Package installé.

     Les étapes de sauvegarde et de restauration de la configuration sont les suivantes :
     1.  Utilisez la commande CWBBACK pour sauvegarder la configuration d'IBM i Access for Windows.
             cwbback <filename.rs> /u
         Par exemple :
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Cet exemple part du principe que le dossier C:\Users\IBM_ADMIN\Backup existe déjà.

         La commande ci-dessus crée les deux fichiers suivants dans ce dossier :
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Assurez-vous que les deux fichiers ci-dessus ont bien été créés avant de passer à l'étape suivante.

         REMARQUE :
         Si les deux fichiers ci-dessus n'ont pas été créés, vous ne disposez pas d'une configuration
         sauvegardée.  Essayez d'exécuter la commande en tant qu'administrateur doté de privilèges élevés.
         Pour cela, vous pouvez lancer une invite de commande comme suit :
             Démarrer->Tous les programmes->Accessoires->Invite de commandes
         Mais, au lieu de sélectionner Invite de commandes, cliquez dessus avec
         le bouton droit de la souris, puis sélectionnez l'option "Exécuter en tant qu'administrateur".
         Exécutez la commande cwbback ci-dessus à l'aide de cette invite de commande.
         Assurez-vous que les deux fichiers ci-dessus ont bien été créés avant de passer à l'étape suivante.

     2.  Désinstallez IBM i Access for Windows.
     3.  Réamorcez.
     4.  Installez le module d'application Windows IBM i Access Client Solutions.
     5.  Réamorcez.
     6.  Utilisez la commande CWBREST pour restaurer la configuration que vous avez sauvegardée
         à l'aide de la commande CWBBACK.
             cwbrest <filename.rs> /c
         Par exemple :
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Si vous avez suivi les instructions mentionnées dans la remarque de l'étape 1, vous devez
         également exécuter la commande cwbrest à partir d'une invite de commande d'administrateur
         dotée de privilèges élevés.

  -  Deux méthodes vous permettent de vérifier votre configuration Windows avant et après les étapes
     décrites précédemment :
     1. Vérifiez le registre Windows.  Les configurations système sont stockées à l'emplacement suivant :
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\Mes connexions

	Pour afficher le contenu du registre Windows à cet emplacement, entrez la commande suivante :
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\Mes connexions"
        
        Si le nom de votre environnement est différent du nom "Mes connexions" défini par défaut,
        modifiez le chemin en conséquence.

     2. Si vous disposez de la version d'IBM i Access Client Solutions non tributaire de la plateforme
        sur le même ordinateur, dans le panneau principal de l'interface graphique, vous pouvez sélectionner :
            Fichier->Copie de connexions
        "IBM i Access (Windows)" apparaîtra dans le partie droite.  Il s'agit de la configuration utilisée
        à la fois pour IBM i Access for Windows et pour le module d'application Windows IBM i Access Client Solutions.


3.4 Exécution de l'installation
-----------------------

  - Exécutez le fichier setup.exe de l'image d'installation pour lancer l'installation.  (La commande
    cwblaunch.exe n'est pas livrée avec ce produit.)
   
      REMARQUE : Il n'est pas recommandé d'appeler directement les fichiers Microsoft Installer (MSI) car
      setup.exe utilise setup.ini pour obtenir une liste d'options de ligne de commande à utiliser et
      pour mettre à jour la version de Windows Installer si besoin est.
    
  - Nous vous recommandons d'accepter le dossier de destination proposé par défaut.  Si toutefois vous
    décidez de changer le dossier :
     
     a) Ne sélectionnez pas le répertoire principal d'une unité.
     b) Ne sélectionnez pas un répertoire contenant déjà des fichiers qui n'ont aucun
        rapport avec ce produit.
     c) Ne sélectionnez pas une unité réseau.  L'installation sur une unité réseau
        n'est pas prise en charge.


3.5 Action requise après l'installation du pilote d'imprimante
----------------------------------------------------------------

  Si vous installez le pilote d'imprimante AFP, une action de votre part est
  requise avant de l'utiliser.  En effet, le pilote d'imprimante ne peut pas être ajouté ou mis à jour
  automatiquement au cours de l'installation car il n'est pas signé électroniquement par
  Microsoft.  

  Au cours de l'installation, les fichiers de pilote d'imprimante sont copiés dans un
  sous-répertoire nommé CWBAFP situé dans le chemin de destination choisi.  Si vous avez choisi le
  chemin de destination par défaut pour l'installation, l'emplacement de ce sous-répertoire est le suivant :

  c:\Program Files\IBM\Client Access\CWBAFP 

  Utilisez les instructions de Microsoft indiquées dans le texte d'aide pour ajouter ou mettre à jour le pilote d'imprimante.
  Lorsque vous y êtes invité, spécifiez le chemin vers le répertoire CWBAFP. 

  Si vous effectuez une installation sur un PC sur lequel le produit IBM i Access for Windows a été mis
  à niveau plusieurs fois, des informations obsolètes peuvent s'afficher lorsque vous configurez le
  pilote d'imprimante.  Pour supprimer ces informations obsolètes dans les fichiers .inf, procédez
  comme suit après l'installation :
    a) Ouvrez une fenêtre d'invite de commande.
    b) Placez-vous dans le répertoire d'installation ; par défaut,
       ce répertoire est c:\Program Files\IBM\Client Access.
    c) Tapez "cwbrminf" et appuyez sur Entrée. 


3.6 Remarques sur l'installation en environnements 64 bits
-----------------------------------------------------------

  Lorsque le produit est installé sur un système d'exploitation Windows 64 bits pris en charge :
  
  -  Les versions 32 bits et 64 bits d'ODBC, d'OLE DB,
     d'ActiveX et de SSL (Secure Sockets Layer) sont installées.  

  -  Le fournisseur .NET d'IBM i Access for Windows s'exécute à partir des applications 32 bits et
     64 bits en fonction de l'application qui l'appelle.

  -  Une seule version du pilote d'imprimante AFP est installée.  La version 64 bits est
     installée sur des systèmes 64 bits et la version 32 bits est installée sur des systèmes 32 bits.


3.7 Historiques d'installation
-------------------------------

  Deux historiques sont créés lors de l'installation. L'un d'eux est spécifique à XJ1
  et contient les informations d'actions personnalisées du produit.  Cet historique
  est toujours créé dans le répertoire temp de l'utilisateur sous le nom "xe1instlog.txt".

  L'autre historique concerne le MSI Microsoft ; il contient des informations sur
  les événements, les séquences et les propriétés MSI.  Par défaut, cet historique est
  créé dans le répertoire temp de l'utilisateur sous le nom "xe1instlogmsi.txt".   Vous pouvez
  modifier cet historique en éditant le fichier setup.ini de l'image
  d'installation.  Accédez au mot clé [Startup], puis recherchez et éditez l'entrée suivante : 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Pour empêcher la création de l'historique, supprimez l'entrée.
    - Pour modifier l'emplacement et le nom de l'historique, modifiez le chemin d'accès et le nom de fichier.
    - Pour modifier le contenu de l'historique, remplacez /l* par une autre option, comme décrit dans les
      options de ligne de commande du programme MSDN Windows de Microsoft à l'emplacement suivant : 

      http://msdn.microsoft.com/default.aspx   

  Les informations de ligne de commande par défaut indiquées dans le fichier setup.ini peuvent être remplacées en
  exécutant le fichier setup.exe à l'invite de commande avec des options de ligne de commande.



-------------------------------------------------------------------

4.0 Conditions requises pour le fournisseur .NET IBM.Data.DB2.iSeries 

-------------------------------------------------------------------

  - Le fournisseur .NET d'IBM i Access for Windows .NET (IBM.Data.DB2.iSeries)
    nécessite que Microsoft .NET Framework version 2.0 ou ultérieure soit installé
    sur votre système.  La plupart des PC qui exécutent des systèmes d'exploitation Microsoft
    pris en charge comportent déjà le produit .NET Framework requis.  Vous pouvez télécharger .NET Framework
    à partir du site Web de Microsoft suivant : 

    http://www.microsoft.com/net 

  - Pour éviter d'endommager des applications .NET écrites dans l'interface du fournisseur .NET
    d'Access for Windows 5.2 ou 5.4, les demandes d'exécution de la version 10.0.0.0 du fournisseur
    .NET doivent être redirigées vers la version 12.0.0.0.  Voir "Incompatible changes from 5.3 and 5.4"
    dans le manuel IBM DB2 for i .NET Provider Technical Reference pour obtenir des instructions
    sur l'utilisation d'un fichier app.config, web.config ou machine.config et pour obtenir des informations
    sur la sélection d'un compilateur approprié pour la redirection des applications existantes.

    Vous avez également la possibilité de recompiler l'application à l'aide d'un compilateur
    plus récent pour cibler la version 12.0.0.0 du fournisseur .NET incluse dans l'édition 7.1
    d'IBM i Access for Windows.

  - Pour obtenir des informations complètes et la liste des modifications
    incompatibles, installez la fonction En-têtes, bibliothèques et documentation,
    puis affichez le manuel .NET Provider Technical Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser ou Microsoft XML Core Services

-------------------------------------------------------------------

  Lorsque vous utilisez des objets d'automatisation ActiveX pour le dispositif Transfert de données
  d'IBM i Access for Windows afin de transférer des fichiers vers et depuis le format Microsoft Excel XML
  (pris en charge par Excel 2003 et Excel XP), vous devez installer d'autres logiciels sur votre PC. L'utilisation de ce produit requiert que Microsoft XML Parser version 3.0 ou ultérieure, également appelé Microsoft XML Core Services,
  soit installé sur votre ordinateur personnel. XML Parser est inclus dans la plupart des produits
  Microsoft.  Pour déterminer si le support XML Parser est installé sur votre PC, reportez-vous
  à l'article 278674 de la base de connaissances de Microsoft.  Cet article se trouve sur le
  site Web de Microsoft à l'adresse suivante :

  http://support.microsoft.com/kb/278674

  Si Microsoft XML Parser version 3.0 ou ultérieure n'est pas présent, vous devrez accéder
  au site Web de Microsoft pour télécharger et installer XML Parser pour pouvoir utiliser
  le support Data Transfer XML.  Pour obtenir des informations sur l'installation de XML Parser,
  consultez l'article 324460 de la base de connaissances de Microsoft.  Cet article se trouve
  à l'adresse suivante :

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Informations d'installation avancées

-------------------------------------------------------------------

  Vous pouvez utiliser la plupart des informations relatives à la modification du niveau d'interface utilisateur, à l'utilisation
  des paramètres de ligne de commande et au contrôle des autres comportements d'installation et méthodes de déploiement contenues
  dans la rubrique "Configuration du PC" de l'IBM i Information Center pour
  IBM i Access for Windows.  Les différences sont décrites dans cette section.


6.1 Informations de logiciel sous licence
---------------------------------------------
  
  5733XJ1 n'est pas inclus comme un logiciel sous licence à installer sur le système d'exploitation IBM i.
  Il est disponible uniquement en tant que support PC. Vous pouvez le copier sur l'IBM i à l'emplacement
  que vous avez mis à la disposition des utilisateurs, si vous le souhaitez.
  

6.2 Fichiers langue dans l'image d'installation
--------------------------------------------------
  
  Les fichiers d'installation de langue ne sont plus répartis dans différents répertoires MRI29xx dans
  l'image d'installation. En revanche, il existe des fichiers cab distincts pour chaque langue.  Vous ne
  pouvez pas retirer ces fichiers cab de l'image.


6.3 Dispositifs d'installation
-------------------------------

  L'installation de certains dispositifs d'installation d'IBM i Access for Windows dépendait de l'installation d'autres
  dispositifs d'installation.  Cette restriction ne s'applique pas à ce module.

  Les dispositifs d'installation suivants doivent être installés :
    req (Programmes requis)
    langacs, amri2924 (Anglais)

  Tous les autres dispositifs d'installation sont installés par défaut, mais vous pouvez modifier les paramètres.

  Les langues sont désormais des dispositifs d'installation, tout comme Programmes requis, ODBC, etc. Par conséquent,
  vous pouvez identifier les langues qui sont installées en employant les mêmes méthodes que celles utilisées pour
  contrôler n'importe quel dispositif d'installation.  Les noms de dispositif d'installation pour les langues sont
  amri29xx.  


6.4 Options de ligne de commande
---------------------------------

  Les options de ligne de commande par défaut sont spécifiées dans le fichier setup.ini inclus dans
  l'image d'installation.  Ces options sont ignorées si vous appelez le fichier setup.exe à partir
  de la ligne de commande en spécifiant des options.  

  Si vous utilisez une transformation sur la ligne de commande, les valeurs de ligne de commande dans le fichier setup.ini
  sont ignorées car la transformation est une option.  Vous devez inclure d'autres options sur la ligne de commande, telles
  que les informations de consignation.

  Pour plus d'informations, voir la section 3.7 Historiques d'installation.


6.5 Propriétés publiques
------------------------

  Certaines des propriétés publiques d'IBM i Access for Windows s'appliquent à ce module.  Il existe des
  différences concernant leur utilisation par rapport à IBM i Access for Windows, comme décrit ci-dessous :

  CWBINSTALLTYPE   Cette propriété est utilisée uniquement lors d'une première installation.  Les seules valeurs
                   sont Typical et Custom.  La valeur par défaut est Typical.
                   Exemple : setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   La langue principale par défaut correspond aux paramètres régionaux de votre PC.  Cette propriété vous
                   permet de spécifier une autre langue principale. La valeur à utiliser est MRI29xx. 
                   Exemple : setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   L'utilisation de cette propriété est la même que dans IBM i Access for Windows.  Elle vous
                   permet de mettre à niveau les fichiers SSL au cours d'une mise à niveau.  Si les fichiers
                   de configuration pour SSL sont détectés sur le PC cible, les fichiers sont mis à jour avec
                   les certificats les plus récents.  Les valeurs sont Yes (valeur par défaut) et No.
                   Exemple : setup /vCWBUPGSSLFILES=NO

  Les propriétés communes de Windows Installer répertoriées dans l'IBM i Access for Windows Information Center
  continuent de s'appliquer : ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Il existe une restriction relative à l'utilisation de la propriété REBOOT de Windows Installer avec IBM i Access
  for Windows.  Cette restriction ne s'applique pas à ce module.
  

6.6 Gravure d'images d'administration sur des CD-ROM ou des DVD-ROM
-------------------------------------------------------------------

  En raison des problèmes liés à la façon dont certains logiciels de gravure de CD-ROM et DVD-ROM traitent
  les noms de fichiers longs, il n'est pas recommandé de graver une image d'administration sur un CD-ROM ou
  un DVD-ROM. Si vous rencontrez des difficultés lors de l'installation à partir d'un CD-ROM ou d'un DVD-ROM
      contenant une image d'administration d'IBM i Access for Windows, copiez l'image dans un répertoire sur l'unité
      de disque dur locale, puis exécutez setup.exe à partir de la copie locale.

-------------------------------------------------------------------
7.0 Informations de stratégie
-------------------------------------------------------------------

  Le même fichier de stratégie est utilisé pour ce module et IBM i Access for Windows. Cela
  signifie que certaines de ces stratégies ne sont pas applicables lorsqu'elle sont utilisées
  pour ce module car certaines fonctions d'IBM i Access for Windows n'existent pas dans ce module.

-------------------------------------------------------------------

8.0 Commandes non incluses
-------------------------------------------------------------------

  Les commandes d'IBM i Access for Windows qui ne sont pas incluses dans ce module sont les suivantes :
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[FIN DE DOCUMENT]
