==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Pacote de Aplicativos para Windows 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Todos os direitos reservados. 

==============================================================================
  Este documento é fornecido "no estado em que se encontra" sem garantia de nenhum tipo.  A
    IBM renuncia a todas as garantias, sejam expressas ou implícitas,
    incluindo, mas não limitando, as garantias implícitas de adequação
    a um determinado objeto e a comercialização a respeito das informações
    contidas neste publicação. Fornecendo esta publicação, a IBM não
    garante nenhum direito sobre quaisquer patentes ou direitos autorais. 

===============================================================================

Este documento foi atualizado pela última vez em: 4 de novembro de 2019

------------------------------------------------------------------- 

ÍNDICE 

-------------------------------------------------------------------  

1.0 Introdução
2.0 Local das fontes de informações
3.0 Instalação
  3.1 Sistemas operacionais Windows suportados
  3.2 Considerações de instalação
  3.3 Fazendo upgrade a partir do IBM i Access for Windows
  3.4 Executando a instalação
  3.5 Ação necessária após a instalação do driver da impressora
  3.6 Considerações sobre a instalação do hardware de 64 bits
  3.7 Logs de instalação
4.0 Requisitos do provedor IBM.Data.DB2.iSeries .NET
5.0 Microsoft XML Parser ou Microsoft XML Core Services
6.0 Informações sobre instalação avançada
  6.1 Informações sobre o produto licenciado
  6.2 Arquivos de idiomas na imagem de instalação
  6.3 Instalação de recursos
  6.4 Opções da linha de comandos
  6.5 Propriedades públicas
  6.6 Gravando imagens administrativas em CD ou DVD
7.0 Informações sobre políticas
8.0 Comandos não incluídos
  


-------------------------------------------------------------------

1.0 Introdução
-------------------------------------------------------------------
  Este pacote faz parte do produto 5733XJ1 IBM i Access Client Solutions.

  É possível usar o IBM i Access Client Solutions para conectar a qualquer liberação suportada do IBM i.

  Este pacote contém funções que estão disponíveis somente nos sistemas operacionais
  Windows.  Ele se baseia no produto 7.1 IBM i Access for Windows, mas não contém todos
  os recursos.

  Esse recursos incluídos neste pacote do IBM i Access for Windows são:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer e Gerenciamento de Certificado
    Kit de Ferramentas do Progamador para Cabeçalhos, Biblioteca e Documentação
    Driver da Impressora AFP
    Programas Requeridos incluindo:
      APIs
      Active X
      Segurança
      Capacidade de Manutenção
      Conexões
      Ativações NLS
      Tabelas de Conversão
      Propriedades
      Políticas
      Network Printing
      Subconjuntos de comandos (Consulte a seção 8.0 para ver s lista do que não está incluído.)
      Guia do Usuário
      Uso de Administração do Aplicativo para controlar o acesso à função no pacote

  Os seguintes recursos do IBM i Access for Windows não estão incluídos neste pacote. 
  O pacote IBM i Access Client Solution de plataforma independente inclui uma substituição
  para esses recursos:
    Terminal 5250 e Emulação da Impressora
    Transferência de Dados
    Suplemento de Excel para Transferência de Dados
    Operations Console
  
  Os seguintes recursos do IBM i Access for Windows não estão incluídos neste pacote. 
  O IBM Navigator for i inclui uma substituição para estes recursos:
    System i Navigator
    AFP Workbench Viewer

  Recebimento de Comando Remoto não incluído.  A substituição é para uso dos Serviços de Desktop Remoto da Microsoft.

  Toolbox para Java também não está incluído.  Use o seguinte website para fazer download
  das informações:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Outros recursos do IBM i Access for Windows não incluídos neste pacote são:
    Driver da Impressora SCS
    Ferramentas do Programador Java para Plug-in do System i Navigator
    Atualização de Diretório
    Suporte de Formato de Arquivo Lotus 123
    Nível de Serviço de Verificação

  Como o conteúdo deste pacote também é fornecido com o 7.1 IBM i Access for Windows, a documentação e a versão geralmente refletem o 7.1 IBM i Access for Windows no Guia do Usuário, no Kit de Ferramentas do Programador, no texto da ajuda e nas mensagens, mas são aplicáveis também ao IBM i Access Client Solutions - Pacote de Aplicativos para Windows.


-------------------------------------------------------------------

2.0 Local de Fontes de Informações

-------------------------------------------------------------------

  - As mudanças feitas no IBM i Access Client Solutions, incluindo sistemas operacionais suportados,
    atualizações, restrições, problemas conhecidos significativos, novas informações e mais serão
    publicadas no website do produto IBM i Access:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - O Guia do Usuário que é instalado com este pacote contém informações sobre
    como usar o produto, algumas dicas e técnicas, mensagens e informações para resolução
    de problemas.

  - Referências técnicas para o provedor OLE DB e o Provedor de Dados .NET são instaladas
    quando o recurso de Títulos, Bibliotecas e Documentação for instalado.  É possível localizar
    as referências técnicas na pasta Kit de Ferramentas do Programador.

  - O Centro de Informações do IBM i fornece uma coleção de tópicos criados para profissionais do IBM i
    que precisam de acesso às informações técnicas:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - No momento desta publicação, o Centro de Informações do IBM i não inclui tópicos sobre o
    IBM i Access Client Solutions.  Entretanto, a maioria das informações contidas no IBM i Access
    for Windows é aplicável a este pacote do IBM i Access Client Solutions, incluindo tópicos de
    instalação, administração e programação:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - O IBM i developerWorks contém artigos, tutoriais e recursos técnicos para usuários
    do IBM i:

    https://www.ibm.com/developerworks/ibmi

  - O website do IBM i oferece as notícias mais recentes sobre o IBM i, bem como informações sobre o produto, uma
    biblioteca de referência, roteiros de educação e mais:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Informações de Instalação
-------------------------------------------------------------------



3.1 Sistemas Operacionais Windows Suportados
---------------------------------------

  Este pacote pode ser instalado nos seguintes sistemas operacionais Microsoft Windows:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 e Windows Server 2008 R2
         Standard Enterprise (32-bit e 64bit)
   - Windows 7
         Professional, Enterprise e Ultimate (32-bit e 64-bit)

   As seguintes restrições se aplicam:
 
     a) Home editions não são suportadas.
     b) Você deve usar os níveis de service pack do Windows que a Microsoft suporta.
     c) O suporte será descontinuado na data em que a Microsoft o descartar.
     d) A instalação não é suportada em hardware Itanium.
     e) Use hardware Microsoft Windows e recomendações de memória. Inclua um
        adicional de 256 MB de memória para funções do IBM i Access Client Solution.
     f) O produto não pode ser instalado quando estiver atualizando para um sistema operacional
        Windows diferente.  Siga estas etapas:
          1.  Salve os dados de configuração.
          Desinstale o produto.
          3.  Faça o upgrade do sistema operacional Windows.
          4.  Instale o produto.
          5.  Restaure os dados de configuração.


3.2 Considerações de Instalação
--------------------------------------------------

  - São necessários autoridade e privilégios administrativos para executar a instalação.
  
  - Apenas instalações por máquina são suportadas.  Instalações por usuário não são
    suportadas.

  - O Windows Installer 4.5 é necessário.  Este componente de software Microsoft
    é instalado durante a instalação se ele já não estiver presente no
    sistema.  É possível instalar esse componente antes da instalação fazendo o download
    dele pelo website da Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Fazendo upgrade a partir do IBM i Access for Windows
-------------------------------------------

  -  Atualizar a partir do IBM i Access for Windows não é suportado.  Deve-se
     remover o IBM i Access for Windows antes de instalar esse pacote.  

  -  Consulte a Seção 1.0 para obter a lista de recursos que não estão inclusos.  Se
     desejar continuar usando os recursos no IBM i Access for Windows não
     incluídos neste pacote, não instale este pacote e continue a usar
     o service pack do 7.1 IBM i Access for Windows mais recente.

  -  Quando o IBM i Access for Windows for desinstalado, a configuração do sistema existente
     será excluída. Para preservar a configuração do sistema existente, é necessário
     salvar a configuração antes de desinstalar o IBM i Access for Windows e, em seguida, restaurar a configuração
     após a instalação do Pacote de aplicativos do Windows do IBM i Access Client
     Solutions ter sido instalado.

     Aqui estão as etapas detalhadas para salvar e restaurar a configuração:
     1.  Use o comando CWBBACK para fazer backup da configuração do IBM i Access
         for Windows.
             cwbback <filename.rs> /u
         Por exemplo:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Neste exemplo, presume-se que a pasta C:\Users\IBM_ADMIN\Backup já existe.

         O comando acima criará dois arquivos nessa pasta:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Certifique-se de que esses dois arquivos tenham sido criados antes de ir para a próxima etapa.

         NOTA:
         Caso os dois arquivos acima não tenham sido criados, a configuração não
         foi salva.  Tente executar o comando como um administrador elevado.
         Uma maneira de fazer isso é iniciando um prompt de comandos, conforme a seguir:
             Iniciar->Todos os programas->Acessórios->Prompt de comandos
         Mas, em vez de clicar com o botão esquerdo no Prompt de comandos, use o botão direito e
         selecione a opção para "Executar como administrador".
         Execute o comando cwbback mostrado acima, utilizando esse prompt de comandos.
         Certifique-se de que os dois arquivos acima tenham sido criados antes de ir para a próxima etapa.

     Desinstale o IBM i Access for Windows.
     3.  Reinicialize.
     4.  Instale o Pacote de aplicativos do Windows do IBM i Access Client Solutions.
     5.  Reinicialize.
     6.  Use o comando CWBREST para restaurar a configuração que foi salva com o
         comando CWBBACK.
             cwbrest <filename.rs> /c
         Por exemplo:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Caso tenha sido necessário seguir as instruções da NOTA na etapa 1, também
         será preciso executar o comando cwbrest a partir do prompt de comandos de um
         administrador elevado.

  -  Há algumas maneiras pelas quais é possível verificar a configuração do Windows antes
     e depois das etapas acima:
     1. Verifique o registro do Windows.  As configurações do sistema são armazenadas em:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Para visualizar o conteúdo do registro do Windows nesse local, insira este comando:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Caso o ambiente tenha um nome diferente do padrão
        "My Connections", faça a substituição adequada no caminho acima.

     2. Caso você tenha a versão do IBM i Access Client Solutions independente de plataforma no
        mesmo PC, no painel principal da GUI é possível selecionar:
            Arquivo->Copiar conexões
        O lado direito mostrará "IBM i Access (Windows)".  Esta é a configuração usada para o
        IBM i Access for Windows e para o Pacote de aplicativos do Windows do IBM i Access Client Solutions.


3.4 Executando a instalação
-----------------------

  - Execute setup.exe na imagem de instalação para iniciar a instalação.  (O comando
    cwblaunch.exe não é fornecido com este produto).
   
      NOTA:  A chamada direta de arquivos do Microsoft Installer (MSI) não é
             recomendada porque setup.exe usa setup.ini para obter uma lista
             de opções de linha de comandos a serem usadas e para atualizar a versão do Windows Installer,
             se necessário.
    
  - Recomenda-se utilizar o valor padrão de destino.  Entretanto,
    se você alterar a pasta:
     
     a) Não selecione o diretório-raiz de uma unidade.
     b) Não selecione um diretório que já contenha arquivos não
        relacionados a este produto.
     c) Não selecione uma unidade de rede.  A instalação em uma
    unidade de rede não é suportada.


3.5 Ação Necessária Após a Instalação do Driver de Impressora
---------------------------------------------------

  Se você instalar o driver de impressora APF, deverá executar uma ação antes de usar o driver
  da impressora.  Isso é necessário porque o driver da impressora não pode ser incluído ou atualizado automaticamente durante a instalação, uma vez que o driver da impressora não é assinado digitalmente pela Microsoft.  

  Durante a instalação, os arquivos do driver da impressora são copiados para um subdiretório chamado CWBAFP no caminho de destino que é escolhido.  Supondo que você esteja instalando no caminho de destino padrão, o caminho seria:

  c:\Program Files\IBM\Client Access\diretório CWBAFP 

  Use as orientações da Microsoft em seu texto de ajuda para incluir ou atualizar o driver da impressora.
  Quando solicitado, especifique o caminho para CWBAFP. 

  Se estiver instalando em um PC que tenha feito upgrade do produto IBM i Access for Windows sobre várias liberações, algumas informações antigas podem possivelmente ser exibidas ao configurar o driver da impressora.  Para remover as informações obsoletas de arquivos .inf, faça
  o seguinte depois de concluir a instalação:

    a) Abra uma janela de prompt de comandos.
    b) Altere o diretório para o diretório de instalação. O
        diretório de instalação padrão é c:\Program Files\IBM\Client Access.
    c) Digite "cwbrminf" e pressione Enter. 


3.6 Considerações de Instalação de Hardware de 64 Bits
-----------------------------------------------

  Quando instalado em um sistema operacional Windows de 64 bits suportado:
  
  -  Tanto a versão de 32 bits quanto a versão de 64 bits são instaladas para ODBC, OLE DB,
     ActiveX e Secure Sockets Layer (SSL).  

  -  O provedor .NET do IBM i Access for Windows executa de aplicativos de 32 e de 64 bits,
     dependendo do aplicativo que chama o provedor.

  -  Apenas a versão do Driver da Impressora AFP é instalada.  A versão de 64 bits é instalada
     em sistemas de 64 bits e a versão de 32 bits é instalada nos sistemas de 32 bits.


3.7 Logs de Instalação
---------------------

  Dois logs são criados durante a instalação. Um dos logs é específico para XJ1
  e contém as informações de ação customizadas do produto.  Este log é chamado "xe1instlog.txt"
  e é criado sempre no diretório temporário do usuário.

  O outro log é o log do Microsoft MSI que contém informações sobre
  eventos, sequências e propriedades do MSI.  Por padrão, este log é chamado
  "xe1instlogmsi.txt" e é criado no diretório temporário do usuário.   Você pode alterar esse
  log editando o setup.ini na imagem de instalação.  Acesse a palavra-chave [Startup],
  localize e edite esta entrada 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Para evitar a criação do log, remova a entrada
    - Para alterar o local e o nome do log, altere o caminho e o nome do arquivo
    - Para alterar o conteúdo do log, altere o /l* para opção(ões) diferente(s),
      conforme descrito pelas Opções da Linha de Comandos do MSDN Windows Installer da Microsoft
      neste local 

      http://msdn.microsoft.com/default.aspx   

  As informações da linha de comandos padrão em setup.ini podem ser sobrescritas iniciando
  setup.exe no prompt de comandos com as opções da linha de comandos.



-------------------------------------------------------------------

4.0 Requisitos do Provedor .NET do IBM.Data.DB2.iSeries 

-------------------------------------------------------------------

  - O Provedor .NET do IBM i Access para Windows (IBM.Data.DB2.iSeries)
    requer que o Microsoft .NET Framework Versão 2.0 ou mais recente esteja instalado
    em seu sistema.  A maioria dos PCs que executam sistemas operacionais Microsoft suportados já tem
    o .NET Framework necessário instalado.  O .NET Framework pode ser transferido por download do seguinte website
    da Microsoft: 

    http://www.microsoft.com/net 

  - Para evitar interromper aplicativos .NET que foram gravados na interface do provedor .NET do Access for Windows 5.3
    ou 5.4, os pedidos de tempo de execução para a versão 10.0.0.0 do provedor
    .NET devem ser redirecionados para a versão 12.0.0.0.  Consulte o tópico
    "Mudanças Incompatíveis da 5.3 e 5.4" na Referência Técnica do Provedor .NET do IBM DB2 for i
    para obter instruções sobre como usar um arquivo app.config, web.config ou machine.config e para obter informações sobre como selecionar um compilador adequado para redirecionar aplicativos existentes.

    Como alternativa, o aplicativo pode ser recompilado usando um compilador mais recente para direcionar
    a versão 12.0.0.0 do provedor .NET incluída no release 7.1 do IBM i Access for Windows.

  - Para obter informações completas e uma lista de mudanças incompatíveis, instale o recurso Títulos, Bibliotecas e Documentação e, em seguida, exiba a Referência Técnica do Provedor .NET. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser ou Microsoft XML Core Services

-------------------------------------------------------------------

  Ao usar os objetos de automação do IBM i Access for Windows Data Transfer ActiveX para
  transferir arquivos para e do formato XML do Microsoft Excel (suportados pelo Excel 2003 e
  Excel XP), um software adicional deverá ser instalado em seu PC. Esse recurso requer que o
  Microsoft XML Parser 3.0 ou acima, também conhecido como Microsoft XML Core Services,
  esteja instalado em seu computador pessoal. O XML Parser está incluído em muitos produtos Microsoft.  Para determinar se o suporte ao XML Parser está instalado em seu PC, consulte o
  artigo 278674 do Microsoft KB.  Este artigo pode ser localizado no Web site da Microsoft em:

  http://support.microsoft.com/kb/278674

  Se o Microsoft XML Parser 3.0 ou mais recente não for localizado, será necessário acessar a
  Microsoft na Web para obter instruções sobre como fazer download e instalar o XML Parser antes
  de usar o suporte XML na Transferência de Dados.  Consulte o artigo 324460 do Microsoft KB
  para obter informações sobre como instalar o XML Parser.  Este artigo pode ser localizado em:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Informações de Instalação Avançada

-------------------------------------------------------------------

  É possível usar a maioria das informações sobre como modificar o nível da interface com o usuário,usando parâmetros da linha de comandos, controlando outros métodos de comportamento e implementação no tópico "Configurando o PC" no Centro de Informações do IBM i para IBM i Access for Windows.  As diferenças são descritas nesta seção.


6.1 Informações do Produto Licenciado
----------------------------------
  
  5733XJ1 não é compactado como um Produto Licenciado a ser instalado no sistema operacional do IBM i.
  Ele está disponível apenas como mídia de PC. É possível copiá-lo para o IBM i no local disponível para seus usuários, se você desejar.
  

6.2 Arquivos de Idioma na Imagem de Instalação
--------------------------------------------
  
  Os arquivos de instalação de idioma não são mais separados em diretórios MRI29xx diferentes
  na imagem de instalação. Em vez disso, há arquivos CAB separados para cada idioma.  Não é possível
  remover esses arquivos CAB da imagem.


6.3 Recursos de Instalação
--------------------

  Alguns recursos de instalação do IBM i Access for Windows dependem que outros recursos de instalação sejam instalados.  Essa restrição não é aplicável a este pacote.

  Os seguintes recursos de instalação precisam ser instalados:
    req (Programas Necessários)
    langacs, amri2924 (Inglês)

  Todos os outros recursos de instalação são instalados por padrão, mas é possível alterar a configuração.

  Os idiomas são agora recursos de instalação, exatamente como Programas Necessários, ODBC etc. Como os idiomas são recursos de instalação, é possível controlar quais idiomas são instalados usando os mesmos métodos usados para controlar qualquer recurso de instalação.  Os nomes dos recursos de instalação para os idiomas são amri29xx.  


6.4 Opções da Linha de Comandos
------------------------

  As opções da linha de comandos padrão são especificadas no arquivo setup.ini incluído na imagem de
  instalação.  Essas opções serão ignoradas se você chamar setup.exe a partir da linha de comandos
  com quaisquer opções especificadas.  

  Se você estiver usando uma conversão na linha de comandos, os valores da linhas de comandos em setup.ini
  serão ignorados, pois a conversão é uma opção.  Você precisará incluir outras opções na linha de comandos,
  tais como informações de criação de log.

  Consulte a Seção 3.7 Logs de Instalação para obter informações adicionais.


6.5 Propriedades Públicas
---------------------

  Algumas das propriedades públicas do IBM i Access for Windows são aplicáveis a este pacote.  O uso tem algumas
  mudanças a partir do uso do IBM i Access for Windows, conforme descrito aqui:

  CWBINSTALLTYPE   Essa propriedade é usada apenas em uma instalação pela primeira vez.  Os únicos valores
                   são Típico e Customizado.  O padrão é Típico.
                   Exemplo: setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   O idioma principal padrão é o código de idioma do seu PC.  Essa propriedade permite
                   especificar um idioma principal diferente. O valor a ser usado é MRI29xx. 
                   Exemplo: setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   O uso dessa propriedade é igual ao IBM i Access for Windows.  Ela permite fazer
                   upgrade dos arquivos SSL durante um upgrade.  Se os arquivos de configuração para
                   SSL estiverem localizados em seu PC de destino, os arquivos serão atualizados com
                   os certificados mais recentes.  Os valores são Sim e Não. O padrão é Sim.
                   Exemplo: setup /vCWBUPGSSLFILES=NO

  As propriedades comuns do Windows Installer listadas no tópico Centro de Informações do IBM i Access for Windows permanecem aplicáveis: ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Há uma restrição no uso da propriedade REBOOT Windows Installer com o IBM i Access
  for Windows.  Essa restrição não é aplicável a este pacote.
  

6.6 Gravando Imagens Administrativas no CD ou DVD
----------------------------------------------

  Devido a problemas de como alguns softwares de gravação de CD e DVD tratam nomes de arquivos longos, a gravação de
  uma imagem administrativa em um CD ou DVD não é recomendada. Se você tiver problemas
      ao instalar a partir de um CD ou DVD que contenha uma imagem administrativa do IBM i Access para
      Windows, copie a imagem para um diretório na unidade de disco rígido local e execute setup.exe
      a partir da cópia local.

-------------------------------------------------------------------
7.0 Informações de Política
-------------------------------------------------------------------

  O mesmo arquivo de política é usado para este pacote e para o IBM i Access for Windows. Isso
  significa que algumas dessas políticas não são aplicáveis quando usadas para este pacote, uma
  vez que algumas das funções do IBM i Access for Windows não existem neste pacote.

-------------------------------------------------------------------

8.0 Comandos
-------------------------------------------------------------------

  Os comandos no IBM i Access for Windows que não estão incluídos neste pacote:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[FIM DO DOCUMENTO]
