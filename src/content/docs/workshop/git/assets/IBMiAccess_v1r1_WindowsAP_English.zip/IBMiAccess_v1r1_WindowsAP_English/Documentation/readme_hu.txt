==============================================================================

            5733XJ1 IBM i Access Client Solutions
               Windows alkalmazáscsomag 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Minden jog fenntartva. 

==============================================================================
  E dokumentum "jelenlegi formájában", bármilyen garancia vállalása nélkül
  kerül közreadásra.  A dokumentum információtartalmára vonatkozóan az IBM
  minden kifejezett vagy vélelmezett garancia vállalásától elhatárolódik,
  beleértve, de nem kizárólag, az adott célra alkalmasság és a
  kereskedelmi értékesíthetőség feltételezett garanciáit. E dokumentum
  közreadásával az IBM semmiféle szabadalmához vagy szerzői jogvédelem
  alatt álló tulajdonához nem ad licencet. 

===============================================================================

A dokumentum legutóbbi frissítésének dátuma: 2019. november 4. 

------------------------------------------------------------------- 

Tartalom 

-------------------------------------------------------------------  

1.0 Bevezetés
2.0 Információforrások elérhetősége
3.0 Telepítés
  3.1 Támogatott Windows operációs rendszerek
  3.2 Telepítési szempontok
  3.3 Frissítés IBM i Access for Windows rendszerről
  3.4 Telepítés futtatása
  3.5 Nyomtatóillesztő program telepítése után szükséges művelet
  3.6 64-bites hardvertelepítési szempontok
  3.7 Telepítési naplók
4.0 IBM.Data.DB2.iSeries .NET szolgáltató követelményei
5.0 Microsoft XML Parser vagy Microsoft XML Core szolgáltatások
6.0 Speciális telepítési információk
  6.1 Licenc hatálya alá tartozó termékinformációk
  6.2 Nyelvi fájlok a telepítőkészletben
  6.3 Telepítési összetevők
  6.4 Parancssori paraméterek
  6.5 Nyilvános tulajdonságok
  6.6 Adminisztrációs telepítőkészletek
kiírása CD-re vagy DVD-re
7.0 Házirend-információk
8.0 Nem tartalmazott parancsok
  


-------------------------------------------------------------------

1.0 Bevezetés
-------------------------------------------------------------------
  Ez a csomag része az 5733XJ1 IBM i Access Client Solutions
  terméknek.

  Az IBM i Access Client Solutions termék segítségével bármely támogatott IBM i
  kiadáshoz csatlakozhat.

  Ez a csomag olyan funkciókat foglal magában, amelyek csak Windows operációs
  rendszereken állnak rendelkezésre.  A 7.1 változatú IBM i Access for Windows
  termékre épül, de nem tartalmazza az összes szolgáltatást.

  Ebben a csomagban a következő, IBM i Access for Windows termékből származó
  szolgáltatások találhatók meg:
    .NET adatszolgáltató
    ODBC
    OLE DB
    Védett socket réteg és tanúsítványkezelés
    Programozói eszközkészlet a header fájlok, függvénytárak és dokumentáció
    számára
    AFP nyomtatóillesztő program
    Kötelező programok, köztük az alábbiak:
      Alkalmazásprogramozási felületek (API-k)
      Active X
      Biztonság
      Javíthatóság
      Kapcsolatok
      NLS támogatás
      Átalakítási táblázatok
      Tulajdonságok
      Házirendek
      Hálózati nyomtatás
      A parancsok részhalmaza (a nem tartalmazott parancsok listáját lásd a 8.0
      részben)
      Felhasználói kézikönyv
      Alkalmazásadminisztráció használata a csomagbeli funkció elérésének
      felügyeletéhez

  Az IBM i Access for Windows termék következő szolgáltatásai nem szerepelnek
  ebben a csomagban. 
  A platformfüggetlen IBM i Access Client Solution csomag az alábbi
  szolgáltatások helyett azok helyettesítőit tartalmazza:
    5250 képernyő- és nyomtatóemuláció
    Adatátvitel
    Adatátvitel Excel beépülő
    Műveleti konzol
  
  Az IBM i Access for Windows termék következő szolgáltatásai nem szerepelnek
  ebben a csomagban. 
  Az IBM Navigator for i az alábbi szolgáltatások helyett azok helyettesítőit
  tartalmazza:
    System i Navigator
    AFP munkaasztal-megjelenítő

  A Bejövő távoli parancs szolgáltatás nem szerepel a csomagban.  Helyette a
  Microsoft Távoli asztal szolgáltatásai alkalmazandók.

  A csomag ezenkívül a Toolbox for Java összetevőt sem tartalmazza.  A letöltési
  információkat a következő webhelyen találja:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Az ezen csomag által nem tartalmazott egyéb IBM i Access for Windows
  szolgáltatások a következők:
    SCS nyomtatóillesztő program
    System i Navigator Java programozói eszközeinek bedolgozói
    Könyvtárfrissítés
    Lotus 123 fájlformátum támogatása
    Javítócsomagszint ellenőrzése

  Mivel ezen csomag tartalma a 7.1 változatú IBM i Access for Windows termékkel
  együtt is szállításra kerül, a leírások és a verziókövetés gyakran a 7.1
  változatú IBM i Access for Windows terméket tükrözi a felhasználói
  kézikönyvben, a programozói eszközkészletben, a súgószövegben és az
  üzenetekben, azonban az IBM i Access Client Solutions - Windows
  alkalmazáscsomagra egyaránt vonatkozik.


-------------------------------------------------------------------

2.0 Információforrások elérhetősége

- Az IBM i Access Client Solutions terméket érintő módosítások, köztük a támogatott operációs rendszerek, frissítések,
korlátozások, jelentős ismert problémák, új információk és egyebek az IBM i
Access termék webhelyén kerülnek közzétételre:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Az ezen csomaggal együtt telepített felhasználói kézikönyv termékhasználati
    információkat, néhány tippet és technikát, üzeneteket és hibaelhárítási
    információkat tartalmaz.

  - Az OLE DB szolgáltató és a .NET adatszolgáltató technikai leírásainak
    telepítésére a Header fájlok, függvénytárak és dokumentáció szolgáltatás
    telepítésekor kerül sor.  A technikai leírásokat a Programozói eszközkészlet
    mappában keresse.

  - Az IBM i információs központ a technikai információkat kereső IBM i
    szakértők számára biztosít témakörgyűjteményt:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Jelen kiadvány kiadása idején az IBM i információs központ nem tartalmazza
    az IBM i Access Client Solutions termék témaköreit.  Ennek ellenére az IBM i
    Access for Windows termék legtöbb információja az IBM i Access Client
    Solutions termék ezen csomagjára is vonatkozik, a telepítés, adminisztráció
    és programozás témaköreit is beleértve:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - Az IBM i developerWorks webhelye cikkeket, ismertetőket és technikai
    információforrásokat tartalmaz az IBM i rendszer felhasználói számára:

    https://www.ibm.com/developerworks/ibmi

  - Az IBM i webhelye tartalmazza a legfrissebb IBM i híreket,
    termékinformációkat, hivatkozási könyvtárat, továbbképzési terveket és még
    sok minden mást:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Telepítési információk
-------------------------------------------------------------------



3.1 Támogatott Windows operációs rendszerek
-------------------------------------------

  Ezt a csomagot az alábbi Microsoft Windows operációs rendszereken lehet
  telepíteni:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 és Windows Server 2008 R2
         Standard Enterprise (32 bites és 64 bites)
   - Windows 7
         Professional, Enterprise és Ultimate (32 bites és 64 bites)

   A fentiekre a következő korlátozások vonatkoznak:
 
     a) A Home kiadások nem támogatottak.
     b) A Microsoft által támogatott Windows javítócsomagszinteket kell
        használnia.
     c) A támogatás attól a naptól már nem biztosított, amikor a Microsoft
        megszünteti a támogatást.
     d) A telepítés Itanium hardveren nem támogatott.
     e) Alkalmazza a Microsoft Windows hardver- és
        memóriaajánlásait. Biztosítson további 256 MB-os memóriabővítést az
        IBM i Access Client Solution funkciók számára.
     f) A terméket nem lehet telepíteni, ha egy másik Windows operációs
        rendszerre frissít.  Tegye a következőket:
          1.  Végezze el a konfigurációs adatok mentését.
          2.  Távolítsa el a terméket.
          3.  Frissítse a Windows operációs rendszert.
          4.  Telepítse a terméket.
          5.  Állítsa vissza a konfigurációs adatokat.


3.2 Telepítési szempontok
-------------------------

  - A telepítés futtatásához adminisztrátori jogosultságra és engedélyekre
    van szükség.
  
  - Csak a számítógépenként végzett telepítés támogatott.  A felhasználónként
    végzett telepítés nem támogatott.

  - A Windows Installer 4.5 változatára van szükség.  Ezen Microsoft
    szoftverösszetevő telepítésére a telepítés során kerül sor, ha még nem
    található meg a rendszerben.  Az összetevőt a telepítés előtt a Microsoft
    webhelyéről letöltve telepítheti:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Frissítés IBM i Access for Windows rendszerről
-------------------------------------------

  -  Az IBM i Access for Windows termékről végzett frissítés nem támogatott.  A
     csomag telepítése előtt az IBM i Access for Windows terméket el kell
     távolítani.  

  -  A nem tartalmazott szolgáltatások listájáért tekintse meg az 1.0 szakaszt.  Ha továbbra is használni szeretné az IBM i Access for Windows terméknek az
     e csomagban nem szereplő szolgáltatásait, akkor ne telepítse ezt a
     csomagot, hanem használja továbbra is az IBM i Access for Windows 7.1
     változatát a legfrissebb javítócsomaggal.

  -  Az IBM i Access for Windows eltávolítása után a jelenlegi rendszerkonfiguráció
     törlésre kerül.  A jelenlegi rendszerkonfiguráció megőrzése érdekében az IBM i Access for
     Windows eltávolítása előtt mentenie kell a konfigurációt, majd az IBM i Access Client Solutions
     Windows Application csomag telepítése után vissza kell állítania azt.

     A konfiguráció mentésének és visszaállításának részletes lépései az alábbiak:
     1.  A CWBBACK paranccsal készítsen biztonsági mentést az IBM i Access for Windows konfigurációról.
             cwbback <fájlnév.rs> /u
         Például:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         A példa feltételezi, hogy a C:\Users\IBM_ADMIN\Backup mappa már létezik.

         A fenti parancs két fájlt hoz létre az adott mappában:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Mielőtt a következő lépéssel folytatná, győződjön meg róla, hogy ez a két fájl létrejött

         MEGJEGYZÉS:
         Ha a fenti két fájl nem jött létre, akkor nem mentette a konfigurációt.  Próbálja
meg a parancsot felsőbb szintű rendszergazdaként futtatni.
         Ennek egyik módja egy parancsprompt
indítása, az az alábbiak szerint:
             Start->Minden program->Kellékek->Parancsprompt
         A parancspromptra azonban ne a bal
egérgombbal kattintson, hanem a jobbal, és
válassza az előugró menü "Futtatás
rendszergazdaként" menüpontját.
         Ezzel a parancsprompttal futtass a fenti cwbback parancsot.
         Mielőtt a következő lépéssel folytatná, győződjön meg róla, hogy a fenti két fájl létrejött.

     2.  Távolítsa el az IBM i Access for Windows terméket.
     3.  Indítsa újra a számítógépet.
     4.  Telepítse az IBM i Access Client Solutions Windows Application csomagot.
     5.  Indítsa újra a számítógépet.
     6.  A CWBREST paranccsal állítsa vissza a CWBBACK paranccsal elmentett konfigurációt.
             cwbrest <fájlnév.rs> /c
         Például:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Ha követnie kellett az 2. lépés MEGJEGYZÉS részében leírtakat, akkor a cwbrest parancsot is rendszergazdaként kell futtatnia.

  -  A fenti lépések előtt és után a Windows konfigurációt több módon is ellenőrizheti:
     1. Ellenőrizze a Windows rendszerleíró adatbázist.  A rendszerkonfigurációk tárolásának helye az alábbi:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	A Windows rendszerleíró adatbázis tartalmának megjelenítéséhez a fenti helyen, írja be a következő parancsot:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Ha a környezet neve nem az alapértelmezett "My Connections", akkor ennek megfelelően módosítsa a fenti útvonalat.

     2. Ha az IBM i Access Client Solutions platformfüggetlen változata ugyanarra a
számítógépre van telepítve, akkor a központi grafikus felület ablakban válassza az alábbit:
            Fájl->Kapcsolatok másolása
        A jobb oldalon az "IBM i Access (Windows)" jelenik meg.  Ezt a konfigurációt használja az IBM i Access for Windows és az IBM
i Access Client Solutions Windows Application csomag is.


3.4 A telepítés futtatása
-----------------------

  - A telepítés indításához futtassa a setup.exe fájlt a telepítőkészletben.  (A cwblaunch.exe parancs ezzel a termékkel nem kerül együttesen
    szállításra.)
   
      MEGJEGYZÉS: A Microsoft Installer (MSI) fájlok közvetlen meghívása nem
                ajánlott, mivel a setup.exe fájl az alkalmazandó parancssori
                paraméterek listája esetében, valamint a Windows Installer
                változatának szükség szerinti frissítéséhez a setup.ini fájlt
                használja.
    
  - Ajánlott az alapértelmezett célmappát használni.  Ha mégis módosítja a
    mappát:
     
     a) Ne válassza egy meghajtó gyökérkönyvtárát.
     b) Ne válasszon olyan könyvtárat, amely már tartalmaz nem ehhez a
        termékhez kapcsolódó fájlokat.
     c) Ne válasszon hálózati meghajtót.  A hálózati meghajtóra végzett
        telepítés nem támogatott.


3.5 A nyomtatóillesztő program telepítése után szükséges művelet
----------------------------------------------------------------

  Az APF nyomtatóillesztő program telepítése esetén az illesztőprogram
  használata előtt el kell végeznie egy műveletet.  Erre azért van szükség,
  mivel a nyomtatóillesztő programot a Microsoft nem írta alá digitálisan, és
  így nem lehet automatikusan hozzáadni vagy frissíteni a telepítés során.  

  A telepítés során a rendszer a kiválasztott célútvonalon található, CWBAFP
  nevű alkönyvtárba másolja át a nyomtatóillesztő program fájljait.  Feltéve,
  hogy az alapértelmezett célútvonalon telepít, az útvonal az alábbi lehet:

  c:\Program Files\IBM\Client Access\CWBAFP könyvtár 

  A nyomtatóillesztő program hozzáadásához vagy frissítéséhez alkalmazza a
  Microsoft súgószövegben megjelenő iránymutatásait.
  Ha a rendszer felszólítja rá, adja meg a CWBAFP könyvtárhoz vezető útvonalat. 

  Ha olyan PC-re végzi a telepítést, amelyen korábban az IBM i Access for
  Windows termék több kiadásának frissítése zajlott le, akkor néhány régebbi
  információ megjelenhet a nyomtatóillesztő program beállításakor.  A telepítés
  befejezése után az alábbi lépések elvégzésével távolítsa el az elavult
  információkat az .inf fájlokból:

    a) Nyissa meg a parancssor ablakát.
    b) Váltson át a telepítési könyvtárba. Az alapértelmezett telepítési
       könyvtár: c:\Program Files\IBM\Client Access.
    c) Írja be a "cwbrminf" parancsot, majd nyomja meg az Entert. 


3.6 64 bites hardvertelepítési szempontok
-----------------------------------------

  Amikor a telepítést egy támogatott 64 bites Windows operációs rendszeren
  végzi:
  
  -  Az ODBC, OLE DB, ActiveX és Védett socket réteg (SSL) esetében a 32 és 64
     bites változat egyaránt telepítésre kerül.  

  -  Az IBM i Access for Windows .NET szolgáltató 32 és 64 bites
     alkalmazásokból is fut attól függően, hogy milyen alkalmazás hívja
     meg a szolgáltatót.

  -  Az AFP nyomtatóillesztő program csupán egy változata kerül telepítésre.  A
     64 bites változat a 64 bites, a 32 bites változat pedig a 32 bites
     rendszereken kerül telepítésre.


3.7 Telepítési naplók
---------------------

  A telepítés során a rendszer két naplót hoz létre. A naplók egyike az XJ1
  számára kerül megadásra és a termék egyéni műveleti információit
  tartalmazza.  Ez a napló az "xe1instlog.txt" nevet kapja és mindig a
  felhasználó temp könyvtárában jön létre.

  A mások napló a Microsoft MSI naplója, amely az MSI eseményekről,
  sorrendekről és tulajdonságokról tartalmaz információkat.  Alapértelmezésben
  ez a napló az "xe1instlogmsi.txt" nevet kapja és a felhasználó temp
  könyvtárában jön létre.   Ezt a naplót a telepítőkészletben található setup.ini
  fájl módosításával változtathatja meg.  Keresse meg a [Startup] kulcsszót,
  majd módosítsa a következő bejegyzést: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - A napló létrehozásának megakadályozásához törölje a bejegyzést.
    - A napló helyének és nevének megváltoztatásához módosítsa az
      útvonalat és a fájlnevet.
    - A napló tartalmának meghatározásához módosítsa a /l* kapcsolót a
      kívánt értékre a Microsoft MSDN webhely
      (http://msdn.microsoft.com/default.aspx) "Windows Installer Command
      Line Options" témakörében leírtak szerint.   

  A setup.ini fájlban található alapértelmezett parancssori információkat úgy
  lehet felülbírálni, hogy parancssori paraméterekkel elindítja a setup.exe
  fájlt a parancssorban.



-------------------------------------------------------------------

4.0 Az IBM.Data.DB2.iSeries .NET szolgáltató követelményei 

-------------------------------------------------------------------

  - Az IBM i Access for Windows .NET szolgáltató (IBM.Data.DB2.iSeries)
    megköveteli a Microsoft .NET keretrendszer 2.0 vagy újabb változatának
    telepítését a rendszeren.  A támogatott Microsoft operációs rendszereket
    futtató számítógépek többsége már rendelkezik a szükséges .NET
    keretrendszer telepített változatával.  A .NET keretrendszer a Microsoft
    webhelyéről tölthető le: 

    http://www.microsoft.com/net 

  - Az IBM i Access for Windows 5.3 és 5.4 változatában található .NET
    szolgáltató használatára írt alkalmazások működőképességének
    fenntartásához a .NET szolgáltató 10.0.0.0 változatára irányuló
    futás közbeni kéréseket át kell irányítani a 12.0.0.0 változatra.  Az IBM
    DB2 for i .NET szolgáltató technikai leírásának "5.3 és 5.4 változatokkal
    nem kompatibilis változások" témakörében találhat információkat az
    app.config, a web.config és a machine.config fájlok használatáról, valamint
    a megfelelő fordítóprogram kiválasztásáról a meglévő alkalmazások
    átirányításához.

    Alternatív megoldásként az alkalmazások újra is fordíthatók egy újabb
    fordítóprogrammal az IBM i Access for Windows 7.1 kiadásában található
    .NET szolgáltató 12.0.0.0 változatának használatához.

  - A teljes körű információkért és a nem kompatibilis változások listájának
    eléréséhez telepítse a Header fájlok, függvénytárak és dokumentáció
    szolgáltatást, majd jelenítse meg a .NET szolgáltató technikai leírását. 

-------------------------------------------------------------------

5.0 A Microsoft XML Parser vagy a Microsoft XML Core szolgáltatásai

-------------------------------------------------------------------

  Amikor az IBM i Access for Windows adatátviteli ActiveX automatizálási
  objektumait használja a fájlok Microsoft Excel XML formátumra, illetve
  formátumról való átviteléhez (amit az Excel 2003 és az Excel XP támogat),
  a számítógépen további telepített szoftverekkel kell rendelkeznie. Ez a
  szolgáltatás megköveteli a Microsoft XML Parser 3.0 vagy újabb változatának
  (más néven a Microsoft XML Core Services összetevő) telepítését a
  számítógépre. Az XML Parser számos Microsoft termékben megtalálható.  Forduljon
  a Microsoft tudásbázis 278674 számú dokumentumához annak meghatározása
  érdekében, hogy a számítógépen telepítve van-e az XML Parser összetevő.  A
  dokumentum a Microsoft webhelyén található a következő címen:

  http://support.microsoft.com/kb/278674

  Ha a számítógépen nem található meg a Microsoft XML Parser 3.0 vagy
  újabb változata, akkor az Adatátvitel XML szolgáltatásának használata
  előtt le kell töltenie és telepítenie kell az XML Parser összetevőt.  Az XML
  Parser telepítéséről a Microsoft tudásbázis 324460 számú cikke szolgál
  további részletekkel.  A cikk a következő címen található:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Speciális telepítési információk

-------------------------------------------------------------------

  Az IBM i Access for Windows termék esetében is alkalmazhatja az IBM i
  információs központban a felhasználói felület szintjének módosításáról, a
  parancssori paraméterek használatáról, az egyéb telepítési viselkedésmódok és
  módszerek kezeléséről szóló "PC beállítása" témakörben található
  információk többségét.  A különbségeket ez a szakasz ismerteti.


6.1 Licenc hatálya alá tartozó termékinformációk
------------------------------------------------
  
  Az 5733XJ1 nincs licenc hatálya alá tartozó, IBM i operációs rendszeren
  telepítendő termékként csomagba foglalva.
  Csak számítógépes adathordozón áll
  rendelkezésre. Igény szerint átmásolhatja az IBM i rendszer azon pontjára,
  ahol felhasználói elérhetik azt.
  

6.2 Nyelvi fájlok a telepítőkészletben
--------------------------------------
  
  A telepítőkészletben található nyelvi telepítőfájlok már nem különülnek el
  különféle MRI29xx könyvtárakban. Ehelyett minden egyes nyelvhez különálló CAB
  fájlok tartoznak.  A telepítőkészletből nem távolíthatja el ezeket a CAB
  fájlokat.


6.3 Telepítési összetevők
-------------------------

  Az IBM i Access for Windows termék egyes telepítési összetevői más
  telepítési összetevők előzetes telepítésétől függnek.  Ez a korlátozás nem
  vonatkozik erre a csomagra.

  Az alábbi telepítési összetevőket kötelező előzetesen telepíteni:
    req (Kötelező programok)
    langacs, amri2924 (Angol)

  Minden egyéb telepítési összetevő alapértelmezésben telepítésre kerül, de
  módosíthatja a beállítást.

  A nyelvek ezentúl telepítési összetevők, hasonlóan például a Kötelező
  programok, ODBC stb. összetevőkhöz. Mivel a nyelvek telepítési összetevők,
  ugyanolyan módszerekkel kezelheti a telepítésre kerülő nyelveket, mint
  amelyeket az összes többi telepítési összetevő esetében is alkalmaz.  A
  telepítési összetevők a nyelvek esetében: amri29xx.  


6.4 Parancssori paraméterek
---------------------------

  Az alapértelmezett parancssori paraméterek a telepítőkészletben található   setup.ini fájlban kerültek megadásra.  Ezek a paraméterek figyelmen kívül
  maradnak, ha tetszőleges paraméterek megadásával a parancssorból hívja meg a
  setup.exe fájlt.  

  Ha átalakítást alkalmaz a parancssorban, akkor a rendszer figyelmen kívül
  hagyja a setup.ini fájlban szereplő parancssori értékeket, mivel az
  átalakítás is egy paraméter.  Be kell majd foglalnia ezért a parancssorral
  kapcsolatos egyéb paramétereket, például a naplózási információkat.

  További információkért tekintse meg a 3.7 Telepítési naplók című szakaszt.


6.5 Nyilvános tulajdonságok
---------------------------

  Az IBM i Access for Windows termék nyilvános tulajdonságai közül egyesek erre
  a csomagra is vonatkoznak.  A használat módja néhány ponton eltér az IBM i
  Access for Windows termékbeli használattól, amelyek leírása az alábbiakban
  látható:

  CWBINSTALLTYPE   Ez a tulajdonság csak az első alkalommal végzett telepítés
                   során kerül felhasználásra.  Csak két értékkel rendelkezik
                   (Typical és Custom).  Az alapértelmezett érték: Typical
                   (tipikus).
                   Példa:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Az alapértelmezett elsődleges nyelv a számítógép területi
                   beállításának felel meg.  Ez a tulajdonság egy ettől eltérő
                   elsődleges nyelv meghatározását teszi lehetővé. A
                   használandó érték: MRI29xx. 
                   Példa:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Ez a tulajdonság az IBM i Access for Windows termékbelivel
                   azonos módon használható.  Frissítés során az SSL fájlok
                   frissítését teszi lehetővé.  Ha az SSL konfigurációs fájljai
                   megtalálhatók a célgépen, akkor a rendszer a legújabb
                   tanúsítványokkal frissíti a fájlokat.  Az értékek: Yes (igen)
                   és No (nem). Az alapértelmezett érték: Yes.
                   Példa:  setup /vCWBUPGSSLFILES=NO

  Az IBM i Access for Windows információs központ témakörében felsorolt
  általános Windows Installer tulajdonságok továbbra is alkalmazhatók:
  ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  A REBOOT Windows Installer tulajdonság az IBM i Access for Windows termék
  esetében korlátozottan alkalmazható.  A korlátozás erre a csomagra nem
  vonatkozik.
  

6.6 Adminisztrációs telepítőkészletek kiírása CD-re vagy DVD-re
---------------------------------------------------------------

  Mivel egyes CD- és DVD-író szoftverek nem megfelelően kezelik a hosszú
  fájlneveket, az adminisztrációs telepítőkészlet CD-re és DVD-re írása nem
  ajánlott. Ha problémákba ütközik egy adminisztrációs IBM i Access for Windows
  telepítőkészletet tartalmazó CD-ről vagy DVD-ről végzett telepítés során,
  akkor másolja át a telepítőkészletet a helyi merevlemezes meghajtó egyik
  könyvtárába, és a helyi példányból futtassa a setup.exe fájlt.

-------------------------------------------------------------------
7.0 Házirend-információk
-------------------------------------------------------------------

  Jelen csomag és az IBM i Access for Windows termék esetében ugyanaz a
  házirendfájl kerül felhasználásra. Ez azt jelenti, hogy a kérdéses házirendek
  közül egyesek nem alkalmazhatók ezen csomag esetében, mivel az IBM i Access
  for Windows rendszerbeli funkciók némelyike nem létezik ebben a csomagban.

-------------------------------------------------------------------

8.0 Parancsok
-------------------------------------------------------------------

  Az IBM i Access for Windows termék következő parancsai nem szerepelnek
  ebben a csomagban:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[Dokumentum vége]
