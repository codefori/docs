==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  All rights reserved. 

==============================================================================
  이 문서는 어떤 종류의 보증 없이 "현상태대로" 제공됩니다.  IBM은 이 문서에
  있는 정보와 관련된 특별한 목적과 상업성을 위해 적합성에 대한 암시적 보증,
  제한없이 포함하고 있는, 명시적 또는 암시적인 모든 보증을 거부합니다. 
  이 문서를 제공함으로써,IBM이 어떤 특허권 및 저작권에 대한 사용권을
  부여하는 것은 아닙니다. 

===============================================================================

이 문서는 2019년 11월 04에 마지막으로 갱신되었습니다.

------------------------------------------------------------------- 

목차 

-------------------------------------------------------------------  

1.0 소개
2.0 정보 소스 위치
3.0 설치
  3.1 지원되는 Windows 오퍼레이팅 시스템
  3.2 설치 고려사항
  3.3 Windows용 IBM i Access 업그레이드
  3.4 설치 실행
  3.5 프린터 드라이버 설치 후 필요한 조치
  3.6 64비트 하드웨어 설치 고려사항
  3.7 설치 로그
4.0 IBM.Data.DB2.iSeries .NET Provider 요구사항
5.0 Microsoft XML Parser 또는 Microsoft XML Core Services
6.0 고급 설치 정보
  6.1 라이센스가 부여된 제품 정보
  6.2 설치 이미지의 언어 파일
  6.3 설치 피처
  6.4 명령행 옵션
  6.5 공용 특성
  6.6 CD 또는 DVD로 관리 이미지 만들기
7.0 정책 정보
8.0 포함되지 않는 명령
  


-------------------------------------------------------------------

1.0 소개
-------------------------------------------------------------------
  이 패키지는 5733XJ1 IBM i Access Client Solutions 제품의 파트입니다.

  IBM i Access Client Solutions를 사용하여 지원되는 모든 IBM i 릴리스에
  연결할 수 있습니다.

  이 패키지에는 Windows 오퍼레이팅 시스템에서만 사용 가능한 기능이
  들어 있습니다.  이는 Windows용 7.1 IBM i Access를 기반으로 하지만
  모든 피처를 포함하지는 않습니다.

  Windows용 IBM i Access의 이 패키지에 포함된 피처는 다음과 같습니다.
    .NET 데이터 제공자
    ODBC
    OLE DB
    SSL(Secure Socket Layer) 및 인증 관리
    헤더, 라이브러리 및 문서에 대한 프로그래머 툴킷
    AFP 프린터 드라이버
    다음을 포함한 필수 프로그램:
      API
      Active X
      보안
      서비스 가능성
      연결
      NLS 인에이블먼트
      변환표
      등록정보
      정책
      네트워크 인쇄
      명령 서브세트(8.0절에서 포함되지 않은 리스트 참조)
      사용자 안내서
      애플리케이션 관리를 사용하여 패키지에 있는 기능에 대한 액세스 제어

  Windows용 IBM i Access의 다음 피처는 이 패키지에 없습니다.
  플랫폼 독립 IBM i Access Client Solutions 패키지에는 다음
  피처에 대한 대체 기능이 있습니다.
    5250 표시장치 및 프린터 에뮬레이션
    데이터 전송
    데이터 전송 Excel 추가 기능
    Operations Console
  
  Windows용 IBM i Access의 다음 피처는 이 패키지에 없습니다.
  i용 IBM Navigator에는 다음 피처에 대한 대체 기능이 있습니다.
    System i Navigator
    AFP Workbench Viewer

  리모트 명령 수신이 포함되어 있지 않습니다.  대신 Microsoft의
  리모트 데스크탑 서비스를 사용합니다.

  Toolbox for Java도 없습니다.  다운로드 정보는 다음 웹 사이트에서
  볼 수 있습니다.
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  이 패키지에 없는 Windows용 IBM i Access의 기타 피처는 다음과 같습니다.
    SCS 프린터 드라이버
    System i Navigator 플러그인의 Java 프로그래머 툴
    디렉토리 갱신
    Lotus 123 파일 형식 지원
    서비스 레벨 검사

  이 패키지 내용이 Windows용 7.1 IBM i Access와 함께 제공되므로, 문서와
  버전이 종종 사용자 안내서, 프로그래머 툴킷, 도움말 텍스트와 메세지에서
  Windows용 7.1 IBM i Access를 반영하지만 IBM i Access Client Solutions
  - Windows Application Package에도 적용 가능합니다.


-------------------------------------------------------------------

2.0 정보 소스의 위치

-------------------------------------------------------------------

  - 지원되는 오퍼레이팅 시스템, 갱신사항, 제한사항, 알려진 중요 문제점,
    새 정보 등을 포함한 IBM i Access Client Solutions에 대한 변경사항은
    IBM i Access 제품 웹 사이트에 공개됩니다.

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - 이 패키지와 함께 설치된 사용자 안내서에 제품 사용
    정보, 몇 가지 팁과 기술, 메세지, 문제해결 정보가 들어
    있습니다.

  - 헤더, 라이브러리, 문서화 피처가 설치될 때 OLE DB 제공자 및
    .NET 데이터 제공자에 대한 기술 참조도 설치됩니다.  프로그래머의
    툴킷 폴더에서 기술 참조를 찾을 수 있습니다.

  - IBM i Information Center는 기술 정보에 대한 액세스를 필요로 하는
    IBM i 전문가를 위해 설계된 주제의 콜렉션을 제공합니다.

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - 이 문서를 공개할 당시 IBM i Information Center에 IBM i Access Client
    Solutions에 대한 주제는 포함되지 않았습니다.  하지만, Windows용 IBM i Access에
    있는 정보의 대부분(설치, 관리, 프로그래밍 주제 포함)은 이 IBM i Access
    Client Solutions 패키지에 적용 가능합니다.

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks에는 IBM i 사용자에 대한 기사, 학습서, 기술
    자원이 있습니다.

    https://www.ibm.com/developerworks/ibmi

  - IBM i 웹 사이트는 제품 정보, 참조 라이브러리, 교육 로드맵 등과
    최신 IBM i 뉴스를 제공합니다.

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 설치 정보
-------------------------------------------------------------------



3.1 지원되는 Windows 오퍼레이팅 시스템
---------------------------------------

  이 패키지는 다음 Microsoft Windows 오퍼레이팅 시스템에
  설치할 수 있습니다.

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 및 Windows Server 2008 R2
         Standard Enterprise(32비트 및 64비트)
   - Windows 7
         Professional, Enterprise 및 Ultimate(32비트 및 64비트)

   다음 제한사항이 적용됩니다.
 
     a) 홈 에디션은 지원되지 않습니다.
     b) Microsoft가 지원하는 Windows 서비스 팩 레벨을 사용해야 합니다.
     c) 지원은 Microsoft가 지원을 중단하는 날짜에 중지됩니다.
     d) 설치는 Itanium 하드웨어에서 지원되지 않습니다.
     e) Microsoft Windows 하드웨어 및 메모리 권장사항을 사용합니다. 
        IBM i Access Client Solutions 기능을 위한 256MB의 추가 메모리를
        포함합니다.
     f) 다른 Windows 오퍼레이팅 시스템으로 업그레이드하는 경우에는
        제품을 설치할 수 없습니다.  다음 단계를 수행하십시오.
          1.  구성 데이터를 저장합니다.
          2.  제품을 설치 제거합니다.
          3.  Windows 오퍼레이팅 시스템을 업그레이드합니다.
          4.  제품을 설치합니다.
          5.  구성 데이터를 복원합니다.


3.2 설치 고려사항
--------------------------------------------------

  - 관리 권한이 설치 실행에 필요합니다.
  
  - 시스템별 설치만 지원됩니다.  사용자별 설치는 지원되지
    않습니다.

  - Windows Installer 4.5가 필요합니다.  이 Microsoft
    소프트웨어 구성요소가 시스템에 아직 없는 경우 설치
    중에 설치됩니다.  설치 전에 Microsoft 웹 사이트에서
    다운로드하여 설치할 수도 있습니다.

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Windows용 IBM i Access 업그레이드
-------------------------------------------

  -  Windows용 IBM i Access의 업그레이드는 지원되지 않습니다.  이 패키지를
     설치하기 전에 Windows용 IBM i Access를 제거해야 합니다.  

  -  포함되지 않은 피처 리스트는 1.0 절을 참조하십시오.  이 패키지에
     포함되지 않은 Windows용 IBM i Access의 피처를 사용하여 계속
     진행하려면 이 패키지를 설치하지 않고 Windows용 IBM i Access 7.1의
     최신 서비스팩을 계속해서 사용하십시오.

  -  Windows용 IBM i Access가 설치 제거되면, 기존 시스템
     구성이 삭제됩니다. 기존 시스템 구성을 유지하려면
     Windows용 IBM i Access를 설치 제거하기 전에 구성을 저장한 다음
     IBM i Access Client Solutions Windows Application Package가
     설치된 후 구성을 복원해야 합니다.

     다음은 구성을 저장 및 복원하는 상세 단계입니다.
     1.  CWBBACK 명령을 사용하여 Windows용 IBM i Access 구성을 백업하십시오.
             cwbback <filename.rs> /u
         예:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         이 예에서는 C:\Users\IBM_ADMIN\Backup 폴더가 이미 있는 것으로 가정합니다.

         위 명령은 해당 폴더에서 다음 두 개의 파일을 작성합니다.
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
         다음 단계로 진행하기 전에 이 두 파일이 작성되었는지 확인하십시오.

         주:
         위 두 파일이 작성되지 않았으면 저장된 구성이 없는 것입니다.  
         승격된 관리자로서 명령을 실행해 보십시오.
         실행하는 한 가지 방법은 다음과 같이 명령 프롬트를 시작하는 것입니다.
             시작->모든 프로그램->보조 프로그램->명령 프롬트
         그러나 명령 프롬트에서 마우스 왼쪽 버튼을 클릭하는 대신 마우스
         오른쪽 버튼을 클릭하고 "관리자로서 실행" 옵션을 선택하십시오.
         이 명령 프롬트를 사용하여 위 cwbback 명령을 실행하십시오.
         다음 단계로 진행하기 전에 위 두 파일이 작성되었는지 확인하십시오.

     2.  Windows용 IBM i Access를 설치 제거하십시오.
     3.  다시 부팅하십시오.
     4.  IBM i Access Client Solutions Windows Application Package를 설치하십시오.
     5.  다시 부팅하십시오.
     6.  CWBREST 명령을 사용하여 CWBBACK 명령으로 저장했던 구성을 복원하십시오.
             cwbrest <filename.rs> /c
         예:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         1단계에서 주에 있는 지시사항을 수행해야 하는 경우에도 승격된 관리자
         명령 프롬트에서 cwbrest 명령을 실행해야 합니다.

  -  위 단계 이전과 이후에 Windows 구성을 확인할 수 있는 방법은 2가지가 있습니다.
     1. Windows 레지스트리를 확인합니다.  시스템 구성이 다음에 저장되어 있습니다.
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	해당 위치에서 Windows 레지스트리의 컨텐츠를 보려면 다음 명령을 입력하십시오.
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        기본값인 "My Connections"가 아닌 다른 이름의 환경이 있으면, 위 경로에서
        적절히 대체하십시오.

     2. 같은 PC에서 플랫폼에 따라 다른 IBM i Access Client Solutions 버전이 있으면,
        기본 GUI 패널에서 다음을 선택할 수 있습니다.
            파일->연결 복사
        오른쪽에 "IBM i Access(Windows)"가 표시됩니다.  이는 Windows용 IBM i Access와
        IBM i Access Client Solutions Windows Application Package 모두에
        사용되는 구성입니다.


3.4 설치 실행
-----------------------

  - 설치 이미지에서 setup.exe를 실행하여 설치를 시작합니다.  (명령
    cwblaunch.exe는 이 제품에 제공되지 않습니다.)
   
      주:    setup.exe가 setup.ini를 통해 명령행 옵션 리스트를 사용하고
             필요한 경우 Windows Installer 버전을 갱신하므로
             Microsoft Installer(MSI) 파일의 직접 호출이 권장되지
             않습니다.

  - 디폴트 대상 폴더 사용을 권장합니다.  하지만,
    폴더를 변경하는 경우 다음을 주의하십시오.
     
     a) 드라이브의 루트 디렉토리를 선택하지 않습니다.
     b) 이미 이 제품과 관련 없는 파일이 있는 디렉토리를
        선택하지 않습니다.
     c) 네트워크 드라이브를 선택하지 않습니다.  네트워크 드라이브에
        설치하는 것은 지원되지 않습니다. 


3.5 프린터 드라이버 설치 후 필요한 조치
---------------------------------------------------

  APF 프린터 드라이버를 설치하는 경우, 프린터 드라이버를 사용하기
  전에 조치를 수행해야 합니다.  프린터 드라이버가 MIcrosoft에 의해
  디지털 서명되지 않아 설치 중에 자동으로 추가되거나 갱신되지 않으므로
  이러한 조치가 필요합니다.  

  설치 중에, 프린터 드라이버 파일이 선택된 목적지 경로의
  서브디렉토리 CWBAFP에 복사됩니다.  디폴트 목적지 경로에
  설치했다고 가정하면 경로는 다음과 같습니다.

  c:\Program Files\IBM\Client Access\CWBAFP 디렉토리 

  도움말 텍스트에 있는 Microsoft의 지시를 사용하여 프린터 드라이버를 추가하거나
  갱신하십시오. 프롬트되면, 경로를 CWBAFP로 지정하십시오. 

  여러 릴리스에서 Windows용 IBM i Access 제품을 업그레이드한 PC에
  설치하는 경우, 프린터 드라이버를 구성할 때 일부 이전 정보가 표시될 수
  있습니다.  .inf 파일에서 더 이상 사용되지 않는 정보를 제거하려면
  설치를 완료한 후 다음을 수행하십시오.

    a) 명령 프롬트 창을 여십시오.
    b) 이 디렉토리를 사용자의 설치 디렉토리로 변경하십시오. 
       디폴트 설치 디렉토리는 c:\Program Files\IBM\Client Access입니다.
    c) "cwbrminf"를 입력하고 Enter를 누르십시오. 


3.6 64비트 하드웨어 설치 고려사항
-----------------------------------------------

  지원되는 64비트 Windows 오퍼레이팅 시스템에 설치하는 경우:
  
  -  ODBC, OLE DB, ActiveX, SSL(Secure Sockets Layer)에 대해 32비트 버전과
     64비트 버전이 모두 설치됩니다.  

  -  Windows용 IBM i Access .NET 제공자는 제공자를 호출하는 애플리케이션에
     따라 32비트 및 64비트 애플리케이션 모두에서 실행됩니다.

  -  하나의 AFP 프린터 드라이버 버전만 설치됩니다.  64비트 버전은
     64비트 시스템에 설치되고 32비트 버전은 32비트 시스템에 설치됩니다.


3.7 설치 로그
---------------------

  설치 중에 두 개의 로그가 작성됩니다. 한 로그는 XJ1 특정이며 제품의
  사용자 정의 조치 정보를 포함합니다.  이 로그 이름은 "xe1instlog.txt"이고
  항상 사용자의 temp 디렉토리에 작성됩니다.

  다른 로그는 Microsoft MSI 로그이며 MSI 이벤트, 순서 및 등록정보에 대한 정보를
  포함합니다.  기본적으로 이 로그 이름은 "xe1instlogmsi.txt"이고 사용자의
  temp 디렉토리에 작성됩니다.   설치 이미지의 setup.ini를 편집하면
  이 로그를 변경할 수 있습니다.  [Startup] 키워드로 이동하여
  다음 항목을 찾고 편집하십시오. 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - 로그를 작성하지 않으려면 이 항목을 제거합니다.
    - 로그의 위치 및 이름을 변경하려면 해당 경로 및 파일명을 변경합니다.
    - 로그 내용을 변경하려면 다음 위치에 있는 Microsoft의 MSDN
      Windows Installer 명령행 옵션에서 설명된 대로 /l*를 다른
      옵션으로 변경합니다. 

      http://msdn.microsoft.com/default.aspx   

  명령행 옵션과 함께 명령 프롬트에서 setup.exe를 시작하여 setup.ini의
  디폴트 명령행 정보를 대체할 수 있습니다.



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET 제공자 요구사항 

-------------------------------------------------------------------

  - Windows용 IBM i Access .NET 제공자(IBM.Data.DB2.iSeries)를
    사용하려면 시스템에 Microsoft .NET Framework 버전 2.0 이상을
    설치해야 합니다.  지원되는 Microsoft 오퍼레이팅 시스템을
    실행 중인 대부분의 PC에는 이미 필수 .NET Framework가 설치되어
    있습니다.  .NET Framework는 다음 Microsoft 웹 사이트에서
    다운로드할 수 있습니다. 

    http://www.microsoft.com/net 

  - Windows용 Access 5.3 또는 5.4 .NET 제공자 인터페이스에 기록된
    .NET 애플리케이션을 계속 실행하려면 .NET 제공자의 10.0.0.0 버전에
    대한 런타임 요청을 12.0.0.0 버전으로 재지정해야 합니다.  app.config 파일,
    web.config 파일 또는 machine.config 파일 사용에 대한 지시사항과
    기존 애플리케이션의 경로 재지정을 위해 올바른 컴파일러를 선택하는 데
    대한 정보는 IBM DB2 for i .NET 제공자 기술 참조서의 "5.3 및 5.4와
    호환되지 않는 변경사항" 주제를 참조하십시오.

    또는 Windows용 IBM i Access 7.1 릴리스에 포함된 .NET 제공자의
    12.0.0.0 버전을 대상으로 하기 위해 새 컴파일러를 사용하여
    애플리케이션을 다시 컴파일할 수 있습니다.

  - 전체 정보 및 호환되지 않는 변경사항 리스트를 보려면
    헤더, 라이브러리, 문서화 피처를 설치한 후 .NET 제공자
    기술 참조서를 표시하십시오. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser 또는 Microsoft XML Core Services

-------------------------------------------------------------------

  Windows용 IBM i Access 데이터 전송 ActiveX 자동화 오브젝트를 사용하여
  Microsoft Excel XML 형식(Excel 2003 및 Excel XP에서 지원됨)에서 파일을
  전송하는 경우, PC에 추가 소프트웨어를 설치해야 합니다. 이 피처에서는
  Microsoft XML Parser 3.0 이상(Microsoft XML Core Services라고도 함)이
  퍼스널 컴퓨터에 설치되어 있어야 합니다. XML 구문 분석기는 많은 Microsoft 제품에
  포함되어 있습니다.  PC에 XML Parser 지원이 설치되어 있는지 판별하려면
  Microsoft KB 기사 278674를 참조하십시오.  이 기사는 다음 Microsoft 웹 사이트에
  있습니다.

  http://support.microsoft.com/kb/278674

  Microsoft XML Parser 3.0 이상이 없으면, Microsoft 웹에 액세스하여
  XML Parser 다운로드 및 설치에 대한 지침에 액세스해야 Data Transfer XML 지원을
  사용할 수 있습니다.  XML Parser 설치에 대한 정보는 Microsoft KB 기사 324460을
  참조하십시오.  이 기사는 다음 웹 사이트에 있습니다.

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 고급 설치 정보

-------------------------------------------------------------------

  사용자 인터페이스 레벨 수정, 명령 매개변수 사용, 기타 설치
  동작 및 배치 방법 제어에 대한 대부분의 정보는 Windows용
  IBM i Access에 대한 IBM i Information Center의 "PC 설정" 주제에서
  사용할 수 있습니다.  차이점은 이 절에 설명되어 있습니다.


6.1 라이센스가 있는 제품 정보
----------------------------------
  
  5733XJ1은 IBM i 오퍼레이팅 시스템에 설치할 라이센스가 있는 제품으로 패키지되어 있지 않습니다.
  PC 매체로만 사용 가능합니다. 원하는 경우, 사용자가 사용할 수 있는 위치의
  IBM i에 복사할 수 있습니다.
  

6.2 설치 이미지의 언어 파일
--------------------------------------------
  
  언어 설치 파일은 더 이상 설치 이미지의 여러 MRI29xx 디렉토리로
  구분되지 않습니다. 대신 각 언어마다 개별 cab 파일이 있습니다.  이미지에서
  이러한 cab 파일을 제거할 수 없습니다.


6.3 설치 피처
--------------------

  Windows용 IBM i Access의 일부 설치 피처는 설치할 다른 설치 피처에
  따라 다릅니다.  이 제한사항은 이 패키지에 적용되지 않습니다.

  다음 설치 피처가 설치되어야 합니다.
    req(필수 프로그램)
    langacs, amri2924(영어)

  다른 모든 설치 피처는 디폴트로 설치되지만 설정값을 변경할 수 있습니다.

  언어는 이제 필수 프로그램, ODBC 등과 같은 설치 피처입니다. 언어가 설치
  피처이므로, 설치 피처를 제어하는 데 사용되는 동일한 방법을 사용하여
  설치되는 언어를 제어할 수 있습니다.  언어에 대한 설치 피처명은
  amri29xx입니다.  


6.4 명령행 옵션
------------------------

  디폴트 명령행 옵션은 설치 이미지에 포함된 setup.ini 파일에
  지정되어 있습니다.  이러한 옵션은 옵션이 지정된 명령행에서
  setup.exe를 호출하는 경우 무시됩니다.  

  명령행에서 변환을 사용하는 경우, 변환이 옵션이므로 setup.ini의
  명령행 값이 무시됩니다.  명령행에 대한 기타 옵션은 로깅 정보
  등에 포함해야 합니다.

  자세한 정보는 3.7절 설치 로그를 참조하십시오.


6.5 공용 특성
---------------------

  Windows용 IBM i Access 공용 특성의 일부가 이 패키지에 적용 가능합니다.  사용법은
  여기에 설명된 대로 Windows용 IBM i Access의 사용법과 약간 다릅니다.

  CWBINSTALLTYPE   이 특성은 첫 번째 설치에만 사용됩니다.  유일한 값은
                   Typical 및 Custom입니다.  디폴트 값은 Typical입니다.
                   예:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   디폴트 1차 언어는 PC의 로케일입니다.  이 특성을 사용하면
                   다른 1차 언어를 지정할 수 있습니다. 사용할 값은 MRI29xx입니다. 
                   예:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   이 특성의 사용법은 Windows용 IBM i Access와 동일합니다.  이 특성을 사용하면
                   업그레이드 시 SSL 파일을 업그레이드할 수 있습니다.  SSL에 대한
                   구성 파일이 대상 PC에 있는 경우, 파일이 최신 인증서로
                   갱신됩니다.  값은 Yes와 No입니다. 디폴트는 Yes입니다.
                   예:  setup /vCWBUPGSSLFILES=NO

  Windows용 IBM i Access Information Center 주제에 나열된 공통 Windows Installer 특성은
  여전히 적용 가능합니다(ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR).  

  Windows용 IBM i Access의 REBOOT Windows Installer 특성 사용에 대한
  제한사항이 있습니다.  이 제한사항은 이 패키지에 적용되지 않습니다.
  

6.6 관리 이미지를 CD 또는 DVD로 굽기
----------------------------------------------

  일부 CD 및 DVD 굽기 소프트웨어에서 긴 파일명을 처리하는 방식의 문제점으로 인해,
  관리 이미지를 CD 또는 DVD로 굽는 것은 권장되지 않습니다. Windows용 IBM i Access의
  관리 이미지가 들어 있는 CD 또는 DVD에서 설치 문제점이 생기면 이미지를
  로컬 하드 드라이브의 디렉토리에 복사하고 로컬 사본에서 setup.exe를
  실행하십시오.

-------------------------------------------------------------------
7.0 정책 정보
-------------------------------------------------------------------

  동일한 정책 파일이 이 패키지와 Windows용 IBM i Access 모두에 사용됩니다. 즉,
  Windows용 IBM i Access의 일부 기능이 이 패키지에 없으므로 해당 패키지에
  사용될 때 해당 정책의 일부를 적용할 수 없습니다.

-------------------------------------------------------------------

8.0 명령
-------------------------------------------------------------------

  이 패키지에 없는 Windows용 IBM i Access의 명령:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[문서 끝]
