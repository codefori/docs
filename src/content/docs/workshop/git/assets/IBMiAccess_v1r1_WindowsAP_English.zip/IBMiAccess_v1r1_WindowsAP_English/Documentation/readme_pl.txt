==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Wszelkie prawa zastrzeżone. 

==============================================================================
  Dokument ten jest dostarczany w stanie, w jakim się znajdują ("as is"), bez jakichkolwiek
  gwarancji (rękojmia jest niniejszym również wyłączona.  IBM nie udziela żadnych gwarancji
  wyraźnych czy domniemanych, a w szczególności domniemanych gwarancji przydatności
  handlowej czy też przydatności do określonych celu w zakresie informacji znajdujących
  się w tym dokumencie. Publikując ten dokument, IBM nie udziela
  żadnych licencji w stosunku do patentów ani praw autorskich. 

===============================================================================

Ten dokument ostatnio zaktualizowano dnia: 04 listopada 2019

------------------------------------------------------------------- 

SPIS TREŚCI 

-------------------------------------------------------------------  

1.0 Wprowadzenie
2.0 Położenie źródeł informacji
3.0 Instalacja
  3.1 Obsługiwane systemy operacyjne Windows
  3.2 Uwagi dotyczące instalacji
  3.3 Aktualizacja produktu IBM i Access for Windows
  3.4 Uruchamianie instalacji
  3.5 Działania wymagane po zainstalowaniu sterownika drukarki
  3.6 Uwagi dotyczące instalacji na sprzęcie 64-bitowym
  3.7 Dzienniki instalacji
4.0 Wymagania dostawcy środowiska .NET Framework IBM.Data.DB2.iSeries
5.0 Microsoft XML Parser lub Microsoft XML Core Services
6.0 Informacje o instalacji zaawansowanej
  6.1 Informacje o produkcie licencjonowanym
  6.2 Pliki językowe w obrazie instalacyjnym
  6.3 Składniki instalacji
  6.4 Opcje wiersza komend
  6.5 Właściwości publiczne
  6.6 Zapisywanie obrazów administracyjnych na dysku CD lub DVD
7.0 Informacje o strategii
8.0 Nieuwzględnione komendy
  


-------------------------------------------------------------------

1.0 Wprowadzenie
-------------------------------------------------------------------
Ten pakiet jest częścią produktu 5733XJ1 IBM i Access Client Solutions.

  Produkt IBM i Access Client Solutions umożliwia nawiązanie połączenia z każdą obsługiwaną wersją platformy IBM i.

  Pakiet zawiera funkcje, które są dostępne tylko w systemach operacyjnych Windows.  Jest oparty na produkcie IBM i Access for Windows 7.1, ale nie zawiera jego wszystkich składników.

  Składniki produktu IBM i Access for Windows dostępne w tym pakiecie:
    Dostawca danych platformy .NET Framework
    ODBC
    OLE DB
    Secure Socket Layer i Zarządzanie certyfikatami
    Pakiet Programmer's Toolkit for Headers, Libraries and Documentation
    Sterownik drukarki AFP
    Wymagane programy:
      Interfejsy API
      ActiveX
      Zabezpieczenia
      Serwis
      Połączenia
      Obsługa NLS
      Tabele konwersji
      Właściwości
      Strategie
      Drukowanie w sieci
      Podzbiór komend (sekcja 8.0 zawiera listę nieuwzględnionych komend)
      Podręcznik użytkownika
      Administrowanie aplikacjami w celu kontroli dostępu do funkcji w pakiecie

  Pakiet nie zawiera następujących składników produktu IBM i Access for Windows. 
  Niezależny od platformy pakiet IBM i Access Client Solution zawiera funkcje zastępujące następujących składniki:
    Emulacja terminala i drukarki 5250
    Przesyłanie danych
    Program dodatkowy przesyłania danych programu Excel
    Operations Console
  
  Pakiet nie zawiera następujących składników produktu IBM i Access for Windows. 
  Produkt IBM Navigator for i zawiera funkcje zastępujące następujących składniki:
    System i Navigator
    Przeglądarka AFP

  Brak funkcji Przychodząca komenda zdalna.  Zamiast niej można używać usług pulpitu zdalnego firmy Microsoft.

  Brak też pakietu Toolbox for Java.  Informacje o pobieraniu można znaleźć w następującym serwisie WWW:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Inne składniki produktu IBM i Access for Windows, których brak w pakiecie:
    Sterownik drukarki SCS
    Pakiet Java Programmer's Tools do wtyczek aplikacji System i Navigator
    Aktualizacja katalogu
    Obsługa formatu pliku Lotus 123
    Sprawdzanie poziomu usługi

  Ponieważ zawartość tego pakietu jest też dostarczana wraz z produktem IBM i
Access for Windows 7.1, dokumentacja i kontrola wersji często dotyczy
Podręcznika użytkownika, pakietu Programmer's Toolkit, tekstu pomocy i
komunikatów produktu IBM i Access for Windows 7.1, ale ma również zastosowanie
do produktu IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Położenie źródeł informacji

-------------------------------------------------------------------

  - Informacje o zmianach w produkcie IBM i Access Client Solutions, w tym
obsługiwanych systemach operacyjnych, aktualizacjach, ograniczeniach, istotnych
znanych problemach, nowościach i inne będą publikowane w serwisie WWW produktu IBM i Access:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Podręcznik użytkownika instalowany z tym pakietem zawiera informacje na
temat korzystania z produktu, niektóre wskazówki i techniki, komunikaty i informacje dotyczące rozwiązywania problemów.

  - Skorowidze techniczne dostawców OLE DB i danych środowiska .NET Framework są
instalowane wraz ze składnikiem Nagłówki, biblioteki i dokumentacja.  Skorowidze
techniczne znajdują się w folderze pakietu Programmer's Toolkit.

  - Centrum informacyjne systemu IBM i udostępnia kolekcję tematów
przeznaczonych dla specjalistów używających platformy IBM i, którzy potrzebują dostępu do informacji technicznych:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - W momencie publikacji tego dokumentu Centrum informacyjne platformy IBM i
nie zawiera tematów dotyczących produktu IBM i Access Client Solutions.  Jednak
większość informacji dotyczących produktu IBM i Access for Windows ma też
zastosowanie do tego pakietu produktu IBM i Access Client Solutions, w
tym tematy związane z instalacją, administracją i programowaniem:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - Serwis developerWorks zawiera artykuły, kursy i zasoby techniczne dla użytkowników platformy IBM i:

    https://www.ibm.com/developerworks/ibmi

  - Witryna WWW platformy IBM i zawiera najnowsze wiadomości dotyczące systemu
IBM i, a także informacje o produktach, bibliotekę odniesień, przewodniki
szkoleniowe i inne:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Informacje o instalacji
-------------------------------------------------------------------



3.1 Obsługiwane systemy operacyjne Windows
------------------------------------------

  Ten pakiet można zainstalować w następujących systemach operacyjnych Microsoft Windows:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 i Windows Server 2008 R2
         Standard Enterprise (32-bitowy i 64-bitowy)
   - Windows 7
         Professional, Enterprise i Ultimate (32-bitowy i 64-bitowy)

   Mają zastosowanie poniższe ograniczenia:
 
     a) Wersje Home nie są obsługiwane.
     b) Należy używać poziomów pakietów poprawek systemu Windows, które obsługuje firma Microsoft.
     c) Obsługa zakończy się w momencie zaniechania obsługi przez firmę Microsoft.
     d) Instalacja nie jest obsługiwana na sprzęcie Itanium.
     e) Należy używać sprzętu i pamięci zgodnie z zaleceniami do systemu Microsoft Windows. Obejmuje
to też dodatkowe 256 MB pamięci na potrzeby funkcji produktu IBM i Access Client Solution.
     f) Nie można zainstalować produktu podczas aktualizacji do innego systemu operacyjnego Windows.  Należy wykonać następujące kroki:
          1.  Zapisanie danych konfiguracji.
          2.  Deinstalacja produktu.
          3.  Aktualizacja systemu operacyjnego Windows.
          4.  Instalacja produktu.
          5.  Odtworzenie danych konfiguracji.


3.2 Uwagi dotyczące instalacji
------------------------------

  - Do uruchomienia instalacji wymagane jest uprawnienia do administrowania.
  
  - Obsługiwane są tylko instalacje dla danej maszyny.  Nie są obsługiwane instalacje dla danego użytkownika.

  - Wymagany jest Instalator Windows 4.5.  Jeśli tego składnika oprogramowania
firmy Microsoft jeszcze nie ma w systemie, jest instalowany wraz z produktem.  Program
można zainstalować wcześniej, pobierając go z serwisu WWW firmy Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Aktualizacja produktu IBM i Access for Windows
-------------------------------------------

  -  Aktualizacja z produktu IBM i Access for Windows nie jest obsługiwana.  Przed zainstalowaniem tego pakietu należy usunąć produkt IBM i Access for Windows.  

  -  Informacje o nieuwzględnionych składnikach zawiera sekcja 1.0.  Jeśli planowane jest dalsze używanie w produkcie IBM i Access for Windows składników, które nie zostały uwzględnione w tym pakiecie, nie należy instalować tego pakietu, tylko kontynuować używanie najnowszego pakietu serwisowego (w wersji 7.1) produktu IBM i Access for Windows.

  -  Po zdeinstalowaniu produktu IBM i Access for Windows istniejąca
     konfiguracja systemu zostanie usunięta.  Aby zachować istniejącą
     konfigurację systemu, należy zapisać konfigurację przed
     zdeinstalowaniem produktu IBM i Access for Windows, a następnie odtworzyć ją
     po zainstalowaniu pakietu IBM i Access Client Solutions Windows Application Package.

     Poniżej znajdują się szczegółowe kroki umożliwiające zapisanie i odtworzenie konfiguracji:
     1.  Użyj komendy CWBBACK w celu utworzenia kopii zapasowej konfiguracji produktu IBM i Access for Windows.
             cwbback <nazwa_pliku.rs> /u
         Na przykład:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         W tym przykładzie przyjęto założenie, że folder C:\Users\IBM_ADMIN\Backup już istnieje.

         Powyższa komenda spowoduje utworzenie dwóch plików w tym folderze:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Przed przejściem do kolejnego kroku sprawdź, czy pliki zostały utworzone.

         UWAGA:
         Jeśli dwa powyższe pliki nie zostały utworzone, konfiguracja nie została
         zapisana.  Spróbuj wykonać tę komendę jako administrator.
         Jednym ze sposobów jest uruchomienie wiersza komend w następujący sposób:
             Start->Wszystkie programy->Akcesoria->Wiersz polecenia
         Zamiast klikać opcję Wiersz polecenia lewym przyciskiem myszy, użyj prawego
         przycisku myszy i wybierz opcję Uruchom jako administrator.
         Uruchom komendę cwbback w tym wierszu komend.
         Przed przejściem do kolejnego kroku sprawdź, czy pliki zostały utworzone.

     2.  Zdeinstaluj produkt IBM i Access for Windows.
     3.  Uruchom ponownie komputer.
     4.  Zainstaluj pakiet IBM i Access Client Solutions Windows Application Package.
     5.  Uruchom ponownie komputer.
     6.  Użyj komendy CWBREST w celu odtworzenia konfiguracji zapisanej przy użyciu komendy CWBBACK.
             cwbrest <nazwa_pliku.rs> /c
         Na przykład:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Jeśli konieczne było wykonanie instrukcji z sekcji UWAGA w kroku 1, komendę cwbrest
         także trzeba będzie uruchomić w wierszu komend administratora.

  -  Istnieje kilka sposobów sprawdzania konfiguracji systemu Windows przez i po wykonaniu
     powyższych kroków:
     1. Sprawdź rejestr systemu Windows.  Konfiguracje systemu są przechowywane w kluczu:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Aby przejrzeć zawartość rejestru systemu Windows w tym położeniu, wprowadź następującą komendę:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Jeśli zostanie znalezione środowisko o innej nazwie niż nazwa domyślna My Connections,
        wstaw odpowiednią nazwę w powyższej ścieżce.

     2. Jeśli na tym samym komputerze PC znajduje się niezależna od platformy wersja produktu IBM i Access Client Solutions,
        w głównym panelu interfejsu GUI można wybrać opcję:
            Plik->Kopij połączenia
        Po prawej stronie zostanie wyświetlona pozycja IBM i Access (Windows).  Jest to konfiguracja
        używana zarówno przez produkt IBM i Access for Windows, jak i pakiet IBM i Access Client Solutions Windows Application
        Package.


3.4 Uruchamianie instalacji
-----------------------

  - Aby rozpocząć instalację, uruchom plik setup.exe znajdujący się na obrazie instalacyjnym.  Komenda
cwblaunch.exe nie jest dostarczana z tym produktem.
   
      UWAGA: Bezpośrednie wywołanie plików produktu Microsoft Installer (MSI) nie
jest zalecane, ponieważ program setup.exe pobiera z pliku setup.ini listę
opcji wiersza komend do użycia, a w razie potrzeby także aktualizuje Instalator Windows.
    
  - Zaleca się użycie domyślnego folderu docelowego.  Jeśli jednak folder
zostanie zmieniony:
     
     a) Nie należy wybierać katalogu głównego napędu.
     b) Nie należy wybierać katalogu, który już zawiera pliki niezwiązane z produktem.
     c) Nie należy wybierać dysku sieciowego.  Instalacja na dysku sieciowym
	    nie jest obsługiwana.


3.5 Działania wymagane po zainstalowaniu sterownika drukarki
------------------------------------------------------------

  W przypadku instalowania sterownika drukarki APF należy wykonać to działanie
przed użyciem sterownika drukarki.  Jest to konieczne, ponieważ
sterownik drukarki nie może zostać automatycznie dodany lub zaktualizowany
podczas instalacji, bo nie jest podpisany cyfrowo przez firmę Microsoft.  

  Podczas instalacji pliki sterownika drukarki są kopiowane do podkatalogu o
nazwie CWBAFP w wybranej ścieżce docelowej.  Zakładając, że
instalacja odbywa się w domyślnej ścieżce docelowej, ścieżka może być
następująca:

  c:\Program Files\IBM\Client Access\CWBAFP 

  Aby dodać lub zaktualizować sterownik drukarki, należy skorzystać ze
wskazówek zawartych w pomocy firmy Microsoft.
  Po wyświetleniu zachęty
należy podać ścieżkę do katalogu CWBAFP. 

  Jeśli instalacja jest przeprowadzana na komputerze PC, na którym produkt IBM
i Access for Windows został wielokrotnie zaktualizowany, niektóre stare informacje mogą być
wyświetlane podczas konfigurowania sterownika drukarki.  Aby usunąć
  przestarzałe informacje z plików .inf, po zakończeniu instalacji
  wykonaj następujące czynności:
    a) Otwórz okno wiersza komend.
    b) Zmień katalog na katalog instalacyjny. Domyślny
        katalog instalacyjny to c:\Program Files\IBM\Client Access.
    c) Wpisz komendę cwbrminf i naciśnij klawisz Enter. 


3.6 Uwagi dotyczące instalacji na sprzęcie 64-bitowym
-----------------------------------------------------

  W przypadku instalacji w obsługiwanym 64-bitowym systemie operacyjnym Windows:
  
  - Instalowane są zarówno 32-bitowe, jak i 64-bitowe wersje ODBC, OLE DB,
ActiveX i Secure Sockets Layer (SSL).  

  - Dostawcę środowiska .NET Framework produktu IBM i Access for Windows można
uruchomić z aplikacji 32-bitowej i 64-bitowej, aplikacja zależna wywołuje dostawcę.

  - Jest instalowana tylko jedna wersja sterownika drukarki AFP.  W systemach
64-bitowych jest instalowana wersja 64-bitowa, a w systemach 32-bitowych -
wersja 32-bitowa.


3.7 Dzienniki instalacji
------------------------

  Podczas instalowania są tworzone dwa dzienniki. Jeden dziennik jest
specyficzny dla produktu XJ1 i zawiera informacje o niestandardowych działaniach produktu.  Ten dziennik ma nazwę xe1instlog.txt i zawsze zostaje utworzony w katalogu tymczasowym użytkownika.

  Drugi dziennik to dziennik Microsoft MSI zawierający informacje dotyczące
  zdarzeń MSI, sekwencji oraz właściwości.  Domyślnie ten dziennik ma nazwę xe1instlogmsi.txt i zostaje utworzony w katalogu tymczasowym użytkownika.   Ten
dziennik można zmienić, edytując plik setup.ini w obrazie instalacyjnym.  Należy
przejść do słowa kluczowego [Startup], znaleźć i edytować następujący wpis: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Aby zapobiec utworzeniu dziennika, usuń pozycję
- Aby zmienić lokalizację i nazwę dziennika, zmień ścieżkę i nazwę pliku
- Aby zmienić treść dziennika, zmień atrybut /l* na jedną lub kilka innych
opcji zgodnie z opisem w temacie dotyczącym opcji wiersza polecenia
Instalatora Windows w serwisie MSDN firmy Microsoft pod adresem 

      http://msdn.microsoft.com/default.aspx   

  Domyślne informacje wiersza komend w pliku setup.ini można przesłonić,
uruchamiając program setup.exe w wierszu komend za pomocą jego opcji.



-------------------------------------------------------------------

4.0 Wymagania dostawcy środowiska .NET Framework IBM.Data.DB2.iSeries 

-------------------------------------------------------------------

  - Dostawca .NET Provider dla produktu IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries)
    wymaga, aby w systemie zainstalowane było środowisko Microsoft .NET Framework w wersji 2.0
    lub nowszej.  Większość komputerów PC z obsługiwanymi systemami
operacyjnymi firmy Microsoft już ma zainstalowane wymagane środowisko .NET
Framework.  Środowisko .NET Framework może zostać pobrane z poniższego serwisu WWW firmy Microsoft: 

    http://www.microsoft.com/net 

  - Aby aplikacje .NET napisane dla interfejsu dostawcy .NET
    programu Access for Windows w wersji 5.3 lub 5.4 nadal działały, żądania środowiska wykonawczego dla wersji 10.0.0.0
    dostawcy .NET muszą być przekierowywane do wersji 12.0.0.0.  Instrukcje
dotyczące pliku app.config, web.config lub machine.config oraz informacje
dotyczące wybierania odpowiedniego kompilatora do przekierowywania istniejących aplikacji można
znaleźć w temacie Niekompatybilne zmiany w wersji 5.4 w stosunku do wersji 5.3 znajdującym
się w dodatkowym skorowidzu technicznym dostawcy środowiska .NET dla produktu IBM DB2 for i.

    Innym rozwiązaniem jest ponowne skompilowanie aplikacji przy użyciu nowszego kompilatora
    z wersją 12.0.0.0 jako docelową dołączoną do dostawcy .NET w wydaniu 7.1 produktu IBM i Access
    for Windows.

  - Aby uzyskać pełne informacje oraz listę niekompatybilnych zmian, należy
zainstalować składnik Nagłówki, biblioteki i dokumentacja, a następnie
wyświetlić skorowidz techniczny dostawcy środowiska .NET. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser lub Microsoft XML Core Services

-------------------------------------------------------------------

  W przypadku używania obiektów automatyzacji przesyłania danych ActiveX produktu
IBM i Access for Windows w celu przesyłania plików do i z formatu XML programu Microsoft Excel
(obsługiwanego przez programy Excel 2003 i Excel XP) na komputerze PC należy
zainstalować dodatkowe oprogramowanie. Ten składnik wymaga, aby na komputerze
był zainstalowany produkt Microsoft XML Parser 3.0 lub nowszy (znany także pod nazwą Microsoft
XML Core Services). Analizator składni XML jest dołączany do wielu produktów
  firmy Microsoft.  Aby określić, czy obsługa analizatora składni XML jest zainstalowana na komputerze osobistym użytkownika, należy
  zapoznać się z informacjami zawartymi w artykule 278674 Bazy wiedzy firmy Microsoft.  Ten artykuł może zostać znaleziony w serwisie WWW firmy Microsoft pod adresem:

  http://support.microsoft.com/kb/278674

  Jeśli produkt Microsoft XML Parser w wersji 3.0 lub nowszej nie zostanie znaleziony, konieczne będzie uzyskanie dostępu
  do serwisu WWW firmy Microsoft w celu uzyskania instrukcji dotyczących pobierania i instalowania analizatora składni XML, zanim możliwa będzie
  obsługa przesyłania danych XML.  Informacje dotyczące instalowania analizatora składni XML można
  znaleźć w artykule 324460 Bazy wiedzy firmy Microsoft.  Ten artykuł może zostać znaleziony pod następującym adresem:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Informacje o instalacji zaawansowanej

-------------------------------------------------------------------

  Użyteczna jest większość informacji dotyczących modyfikowania poziomu
interfejsu użytkownika, używania parametrów wiersza komend oraz kontrolowania
innych zachowań instalacji i metod wdrażania, które są dostępne w temacie
Konfigurowanie komputera PC w Centrum informacyjnym platformy IBM i dla
produktu IBM i Access for Windows.  Różnice opisano w tej sekcji.


6.1 Informacje o produkcie licencjonowanym
-------------------------------------------
  
  Pakiet 5733XJ1 nie jest produktem licencjonowanym do zainstalowania w systemie
operacyjnym IBM i.
  Jest dostępny tylko jako nośnik dla komputerów PC. W
razie potrzeby zawartość można skopiować do systemu IBM i w położenie dostępne
dla użytkowników.
  

6.2 Pliki językowe w obrazie instalacyjnym
------------------------------------------
  
  Pliki instalacyjne języków w obrazie instalacyjnym nie są już wydzielone do
różnych katalogów MRI29xx. Zamiast tego są dostępne oddzielne pliki cab dla
każdego języka.  Plików cab nie można usunąć z obrazu.


6.3 Składniki instalacji
------------------------

  Niektóre składniki instalacji w produkcie IBM i Access for Windows
zależą od innych instalowanych składników.  To ograniczenie nie dotyczy tego
pakietu.

  Należy zainstalować następujące składniki:
req (wymagane programy)
langacs, amri2924 (wersja angielska)

  Wszystkie pozostałe składniki są instalowane domyślnie, ale można zmienić
ustawienie.

  Języki są obecnie instalowane jako składniki, podobnie jak wymagane
programy, ODBC itd., więc można sterować ich wyborem tak
samo jak w przypadku innych instalowanych składników.  Nazwy językowych
składników instalacji są następujące: amri29xx.  


6.4 Opcje wiersza komend
------------------------

  Domyślne opcje wiersza komend są podane w pliku setup.ini zawartym w
obrazie instalacyjnym.  Opcje zostaną zignorowane w przypadku wywołania programu
setup.exe z wiersza komend bez podania opcji.  

  Jeśli w wierszu komend zostanie użyta komenda transform, wartości wiersza
komend w pliki setup.ini zostaną zignorowane, bo
transform jest opcją.  W wierszu komend należy też uwzględnić inne opcje, na
przykład potrzebne do rejestrowania.

  Więcej informacji zawiera sekcja 3.7 Dzienniki instalacji.


6.5 Właściwości publiczne
-------------------------

  Pakietu dotyczą niektóre właściwości publiczne produktu IBM i
Access for Windows.  Ich zastosowanie zmieniło się w porównaniu do użycia w
produkcie IBM i Access for Windows. Zmiany są następujące:

  CWBINSTALLTYPE Ta właściwość jest używana tylko przy pierwszej instalacji.  Jedynymi dopuszczalnymi wartościami są Typical lub Custom.  Wartość domyślna to Typical.
                   Przykład: setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG Domyślny język podstawowy jest zgodny z ustawieniem narodowym komputera PC.  Ta właściwość umożliwia określenie innego języka podstawowego. Wartość do użycia: MRI29xx. 
                   Przykład: setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES Ta właściwość ma takie same zastosowanie jak w produkcie IBM i Access for Windows.  Umożliwia aktualizację plików SSL podczas aktualizowania.  Jeśli
                 pliki konfiguracyjne SSL znajdują się na docelowym komputerze PC, zostaną
                 zaktualizowane o najnowsze certyfikaty.  Dopuszczalne wartości to Yes i No.
                   Przykład: setup /vCWBUPGSSLFILES=NO

  Wspólne właściwości Instalatora dla Windows przedstawione w temacie Centrum
informacyjnego produktu IBM i Access for Windows, których zastosowanie pozostaje bez zmian:
ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Istnieje ograniczenie używania właściwości REBOOT Instalatora dla Windows z
produktem IBM i Access for Windows.  To ograniczenie nie dotyczy tego pakietu.
  

6.6 Zapisywanie obrazów administracyjnych na dysku CD lub DVD
-------------------------------------------------------------

  Z powodu problemów z obsługą długich nazw plików przez część oprogramowania
do nagrywania płyt CD i DVD nagrywanie obrazu administracyjnego na dysk CD lub
DVD nie jest zalecane. Jeśli napotkane zostaną problemy
      podczas instalowania z dysku CD lub DVD zawierającego obraz administracyjny produktu IBM i Access for
      Windows, należy skopiować obraz do katalogu na lokalnym dysku twardym i uruchomić plik setup.exe
      z kopii lokalnej.

-------------------------------------------------------------------
7.0 Informacje o strategii
-------------------------------------------------------------------

  Plik strategii jest taki sam dla tego pakietu i produktu IBM i Access for
Windows. Oznacza to, że pewne strategie nie mają zastosowania do tego pakietu,
ponieważ brak w nim niektórych funkcji produktu IBM i Access for Windows.

-------------------------------------------------------------------

8.0 Komendy
-------------------------------------------------------------------

  Komendy produktu IBM i Access for Windows, które nie są dołączone do pakietu:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[KONIEC DOKUMENTU]
