==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Reservados todos los derechos. 

 ==============================================================================
  Este documento se proporciona "tal cual", sin garantía de ningún tipo. IBM no
  proporciona garantías, ni expresas ni implícitas, incluidas, pero sin
  limitarse a ellas, las garantías implícitas de idoneidad para un fin
  determinado y de comerciabilidad relativas a la información de este documento. 
  Con el suministro de este documento, IBM no le otorga derechos sobre patentes ni
  copyrights. 

===============================================================================

Este documento se actualizó por última vez el 4 de noviembre de 2019

------------------------------------------------------------------- 

TABLA DE CONTENIDO 

-------------------------------------------------------------------  

1.0 Información preliminar
2.0 Ubicación de fuentes de información
3.0 Instalación
  3.1 Sistemas operativos Windows soportados
  3.2 Consideraciones sobre la instalación
  3.3 Actualización de IBM i Access for Windows
  3.4 Ejecución de la instalación
  3.5 Acción necesaria después de instalar el controlador de impresora
  3.6 Consideraciones sobre la instalación de hardware de 64 bits
  3.7 Archivos de registros de la instalación
4.0 Requisitos del Proveedor .NET IBM.Data.DB2.iSeries
5.0 Microsoft XML Parser o Microsoft XML Core Services
6.0 Información de instalación avanzada
  6.1 Información sobre el producto bajo licencia
  6.2 Archivos de idioma contenidos en la imagen de instalación
  6.3 Componentes de instalación
  6.4 Opciones de línea de mandatos
  6.5 Propiedades públicas
  6.6 Grabación de imágenes administrativas en CD o DVD
7.0 Información de políticas
8.0 Mandatos no incluidos



-------------------------------------------------------------------

1.0 Información preliminar
-------------------------------------------------------------------
  Este paquete forma parte del producto 5733XJ1 IBM i Access Client Solutions.

  Puede utilizar IBM i Access Client Solutions para conectar con cualquier
  release soportado de IBM i.

  Este paquete contiene funciones que sólo están disponibles en sistemas
  operativos Windows.
  Está basado en el producto IBM i Access para Windows 7.1, pero no contiene
  todos los componentes.


  Las características incluidas en este paquete de IBM i Access para Windows son:
    .NET Data Provider
    ODBC
    OLE DB
    Capa de sockets seguros y Gestión de certificados
    Kit de herramientas del programador para cabeceras, bibliotecas y documentación
    Unidad de impresora de AFP
    Programas necesarios que incluyen:
      APIs
      Active X
      Seguridad
      Capacidad de servicio
      Conexiones
      Habilitación de NLS
      Tablas de conversión
      Propiedades
      Políticas
      Impresión de redes
      Subconjunto de mandatos (Consulte la Sección 8.0 para obtener una lista de lo que no se incluye).
      Guía del usuario
      Uso de 'Administración de aplicaciones' para controlar el acceso a funciones contenidas en el paquete


  Los componentes siguientes de IBM i Access para Windows no están incluidos en este paquete.

  El paquete de plataforma independiente IBM i Access Client Solution incluye una sustitución
  de estas características:
    Emulación de impresora y pantalla 5250
    Transferencia de datos
    Complemento de Excel de transferencia de datos
    Consola de operaciones

  Los componentes siguientes de IBM i Access para Windows no están incluidos en este paquete.

  IBM Navigator para i incluye un sustituto para estos componentes:
    System i Navigator
    Visor de AFP Workbench

  No está incluido el Mandato remoto de entrada. Como sustituto se utiliza Servicios de escritorio
  remoto de Microsoft.


  Toolbox para Java tampoco está incluido. Utilice el sitio web siguiente para obtener información
  sobre descargas:

  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Otros componentes de IBM i Access para Windows no incluidos en este paquete son:
    Controlador de impresora SCS
    Herramientas del programador Java para plug-ins de System i Navigator
    Actualización de directorios
    Soporte de formato de archivo Lotus 123
    Comprobar nivel de servicio

  Debido a que el contenido de este paquete también se suministra con IBM i Access para Windows 7.1,
  la documentación y número de versión a menudo corresponde a IBM i Access para Windows 7.1 en la Guía
  del usuario, Kit de herramientas del programador, texto de ayuda y mensajes, pero también es
  aplicable a IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Ubicación de fuentes de información

-------------------------------------------------------------------

  - En el sitio web del producto IBM i Access Solutions se publicarán los cambios realizados en él,
    tales como los referentes a sistemas operativos soportados, actualizaciones, restricciones,
    problemas conocidos importantes, información nueva y otros:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - La Guía del usuario que se instala con este paquete contiene información sobre la
    utilización del producto, algunos consejos y técnicas, mensajes e información de
    resolución de problemas.

  - Las referencias técnicas al Proveedor OLE DB y el Proveedor de datos .NET se instalan al
    instalar el componente Cabeceras, bibliotecas y documentación. Puede encontrar las
    referencias técnicas en la carpeta del Kit de herramientas del programador.

  - El Information Center de IBM i proporciona una colección de temas destinados a profesionales
    de IBM i que necesiten acceder a información técnica:


    http://publib.boulder.ibm.com/eserver/ibmi.html

  - En el momento de publicar la presente información, el Information Center de IBM i
    no contenía temas sobre IBM i Access Client Solutions. Pero gran parte de la información
    sobre IBM i Access para Windows es aplicable a este paquete de IBM i Access Client Solutions,
    incluidos los temas sobre la instalación, administración y programación:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks contiene artículos, guías de aprendizaje y recursos técnicos para
    usuarios de IBM i:

    https://www.ibm.com/developerworks/ibmi

  - El sitio web de IBM i proporciona las últimas novedades sobre IBM i, así como información
    sobre el producto, una biblioteca de consulta, planes de formación y otros temas:


    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Información de instalación
-------------------------------------------------------------------



3.1 Sistemas operativos Windows soportados
------------------------------------------

  Este paquete se puede instalar en los sistemas operativos Microsoft Windows siguientes:


   

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2

   - Windows Server 2008 y Windows Server 2008 R2
         Standard Enterprise (32 bits y 64 bits)
   - Windows 7
         Professional, Enterprise y Ultimate (32 bits y 64 bits)

   Existen las restricciones siguientes:

     a) Las ediciones Home no están soportadas.
     b) Debe utilizar los niveles de paquete de servicio de Windows que están soportados por Microsoft.
     c) Dejará de existir soporte en la fecha que Microsoft deje de dar soporte.
     d) La instalación no es posible en hardware Itanium.
     e) Utilice las recomendaciones sobre hardware y memoria de Microsoft Windows. Incluya
        256 MB adicionales de memoria para las funciones de IBM i Access Client Solution.
     f) El producto no se puede instalar cuando se actualiza a un sistema operativo
        Windows diferente. Siga estos pasos:
          1.  Guarde los datos de configuración.
          2.  Desinstale el producto.
          3.  Actualice el sistema operativo Windows.
          4.  Instale el producto.
          5.  Restaure los datos de configuración.


3.2 Consideraciones sobre la instalación
--------------------------------------------------

  - Es necesaria autorización administrativa y privilegios
    administrativos para ejecutar la instalación. Sólo están permitidas las instalaciones por equipo.  
    Las instalaciones por usuario no están permitidas.


  - Es necesario Windows Installer 4.5.  Este componente de software de Microsoft se instala
    durante la instalación del producto si no está ya presente en el sistema.
    Puede instalarlo antes de la instalación mediante su descarga desde el sitio web de
    Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Actualización de IBM i Access for Windows
---------------------------------------------

  -  No se admite la actualización de IBM i Access para Windows.
     Antes de instalar este paquete, debe eliminar IBM i Access para Windows. 

  -  Consulte la Sección 1.0 para ver la lista de componentes que no se incluyen. Si
     desea continuar utilizando las características de IBM i Access para Windows no
     incluidas en este paquete, no instale este paquete y continúe utilizando el último
     service pack de 7.1 IBM i Access para Windows.

  -  Una vez desinstalado IBM i Access for Windows, se suprimirá la configuración
     del sistema existente. Para conservar la configuración del sistema
     existente, debe guardar la configuración antes de desinstalar IBM i Access for
     Windows y después restaurar la configuración después de instalar IBM i
     Access Client Solutions Windows Application Package.

     Estos son los pasos detallados para guardar y restaurar la configuración:
     1.  Utilice el mandato CWBBACK para hacer una copia de seguridad de la configuración de
         IBM i Access for Windows.
             cwbback <nombre_archivo.rs> /u
         Por ejemplo:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Este ejemplo presupone que la carpeta C:\Users\IBM_ADMIN\Backup ya existe.

         El mandato anterior creará dos archivos en esa carpeta:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
         Asegúrese de que se hayan creado estos dos archivos antes de ir al paso siguiente.

         NOTA:
         Si no se han creado los dos archivos anteriores, no tiene una configuración
         guardada. Intente ejecutar el mandato como un administrador elevado.
         Una forma de hacerlo es iniciar una indicador de mandatos de la manera siguiente:
             Inicio->Todos los programas->Accesorios->Indicador de mandatos
         Pero en lugar de pulsar el botón izquierdo sobre Indicador de mandatos, pulse el
         botón derecho del ratón y seleccione la opción "Ejecutar como administrador".
         Ejecute el mandato cwbback mediante este indicador de mandatos.
         Asegúrese de que se hayan creado los dos archivos anteriores antes de ir al paso
         siguiente.

     2.  Desinstale IBM i Access para Windows.
3.  Reinicie.
4.  Instale IBM i Access Client Solutions Windows Application Package.
               5. Reinicie.
     6.  Utilice el mandato CWBREST para restaurar la configuración guardada con el
         mandato CWBBACK.
             cwbrest <nombre_archivo.rs> /c
         Por ejemplo:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Si ha tenido que seguir las instrucciones de la NOTA del paso 1, también
         deberá ejecutar el mandato cwbrest desde un indicador de mandatos de
         administrador elevado.

  -  Hay dos maneras de verificar la configuración de Windows antes y después de los pasos
     anteriores:
     1. Compruebe el registro de Windows. Las configuraciones del sistema se almacenan en:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Para ver el contenido del registro de Windows en esa ubicación, especifique este mandato:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\Mis conexiones"

        Si tiene un entorno con un nombre distinto del predeterminado
        "Mis conexiones", haga el cambio pertinente en la vía de acceso anterior.

     2. Si tiene la versión independiente de la plataforma IBM i Access Client Solutions en el
        mismo PC, en el panel principal de la interfaz gráfica de usuario puede seleccionar:
            Archivo->Copiar conexiones
        El lado derecho mostrará "IBM i Access (Windows)". Esta es la configuración utilizada
        para IBM i Access for Windows y para IBM i Access Client Solutions Windows Application
        Package.


3.4 Ejecución de la instalación
-----------------------

  - Ejecute setup.exe en la imagen de instalación para iniciar la instalación. (El mandato
    cwblaunch.exe no se entrega con este producto.)

      NOTA:  no es recomendable ejecutar directamente los archivos del programa
             de instalación de Microsoft (MSI), pues setup.exe utiliza setup.ini
             para obtener una lista de opciones de línea de mandatos que se
             deben utilizar y para actualizar la versión del programa de instalación
             de Windows si es necesario.

  - Es recomendable utilizar la carpeta de destino predeterminada. Pero
    si cambia la carpeta:

     a) No seleccione el directorio raíz de una unidad.
     b) No seleccione un directorio que contenga archivos no relacionados con
        este producto.
     c) No seleccione una unidad de red. La instalación en una unidad de red no está permitida.


3.5 Acción necesaria después de instalar el controlador de impresora
--------------------------------------------------------------------

  Si instala el controlador de impresora APF, debe emprender una acción antes de utilizar
  el controlador de impresora. Esto es necesario porque el controlador de impresora no se puede
  añadir ni actualizar automáticamente durante la instalación pues no está firmado digitalmente
  por Microsoft. 

  Durante la instalación, los archivos del controlador de impresora se copian en un subdirectorio
  denominado CWBAFP situado en la vía de destino elegida. La vía de destino predeterminada es:


  c:\Archivos de programa\IBM\Client Access\CWBAFP

  Utilice las instrucciones proporcionadas en el texto de ayuda de Microsoft para añadir
  o actualizar el controlador de impresora. Cuando se le solicite, especifique la vía de
  acceso de CWBAFP. 

  Si está instalando en un PC donde el producto IBM i Access para Windows se ha actualizado
  durante varios releases, puede aparecer información antigua cuando configure
  el controlador de impresora. Para eliminar la
  información obsoleta de los archivos .inf, haga lo siguiente después de
  completar la instalación:
    a) Abra una ventana del indicador de mandatos.
    b) Cambie al directorio del directorio de instalación. El directorio
        de instalación por omisión es c:\Archivos de programa\IBM\Client Access.
    c) Escriba "cwbrminf" y pulse Intro. 


3.6 Consideraciones sobre la instalación en hardware de 64 bits
---------------------------------------------------------------

  Cuando se instala en un sistema operativo Windows soportado de 64 bits:

  -  Se instalan la versión de 32 bits y de 64 bits para ODBC, OLE DB, ActiveX y
     Secure Sockets Layer (SSL).  

  -  El Proveedor .NET de IBM i Access para Windows se ejecuta desde aplicaciones de 32 y 64 bits,
     dependiendo de la aplicación que llame al proveedor. 

  -  Se instala una sola versión del controlador de impresora AFP. La versión de 64 bits
     se instala en sistemas de 64 bits y la versión de 32 bits se instala en sistemas de 32 bits. 


3.7 Archivos de registro de la instalación
------------------------------------------

  Durante la instalación se crean dos archivos de registro. Uno de los archivos de registro
  es específico de XJ1 y contiene información de acción personalizada del producto. Este
  archivo de registro se denomina "xe1instlog.txt" y se crea siempre en el directorio temp
  del usuario.

  El otro archivo de registro es el archivo de registro de MSI de Microsoft, que
  contiene información sobre sucesos, secuencias y propiedades de MSI. El nombre
  predeterminado de este archivo de registro es "xe1instlogmsi.txt" y se crea en
  el directorio temp del usuario. Puede cambiar este archivo de registro editando setup.ini
  en la imagen de instalación. Localice la palabra clave [Startup], busque y edite esta entrada: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    -Para impedir la creación del archivo de registro, elimine la entrada
    -Para cambiar la ubicación y el nombre del archivo, cambie la vía y el nombre del archivo
    -Para cambiar el contenido del archivo, cambie /l* por otra opción, de acuerdo con las
     opciones de línea de mandatos del programa de instalación MSDN Windows de Microsoft que se
     describen en esta ubicación:


      http://msdn.microsoft.com/default.aspx   

  Para alterar temporalmente la información de línea de mandatos predeterminada contenida
  en setup.ini, inicie setup.exe en el indicador de mandatos especificando opciones de
  línea de mandatos.




-------------------------------------------------------------------

4.0 Requisitos del Proveedor .NET IBM.Data.DB2.iSeries

-------------------------------------------------------------------

  - El proveedor .NET de IBM i Access para Windows (IBM.Data.DB2.iSeries)
    necesita que Microsoft .NET Framework Versión 2.0 o posterior esté instalado
    en el sistema. La mayoría de los PC donde se ejecutan sistemas operativos
    Microsoft soportados ya tienen instalado el producto .NET Framework necesario.
    Puede descargar .NET Framework desde el siguiente sitio web de Microsoft: 

    http://www.microsoft.com/net 

  - Para evitar perturbar aplicaciones .NET que se escribieron para la interfaz
    del proveedor .NET de IBM i Access para Windows 5.3 o 5.4, las solicitudes de
    ejecución para la versión 10.0.0.0 del proveedor .NET se deben redirigir a
    la versión 12.0.0.0. Consulte el tema "Incompatible changes from 5.3 and 5.4"
    en la publicación "IBM DB2 for i .NET Provider Technical Reference" para
    obtener instrucciones sobre cómo utilizar un archivo app.config, un archivo
    web.config o un archivo machine.config y para obtener información sobre cómo
    seleccionar un compilador apropiado para redirigir aplicaciones existentes. 

    Como alternativa, puede volver a compilar la aplicación utilizando un
    compilador nuevo para actuar sobre la versión 12.0.0.0 del proveedor .NET
    incluida en el release 7.1 de IBM i Access para Windows.


  - Para obtener información completa y una lista de cambios incompatibles, instale
    el componente 'Cabeceras, bibliotecas y documentación' y abra la publicación
    .NET Provider Technical Reference.   

-------------------------------------------------------------------

5.0 Microsoft XML Parser o Microsoft XML Core Services

-------------------------------------------------------------------

  Cuando se utilizan objetos de automatización ActiveX de IBM i Access para Windows para
  intercambiar archivos de formato XML de Microsoft Excel (soportado por Excel 2003 y
  Excel XP), se debe instalar software adicional en el PC. Este componente
  necesita que el Analizador XML 3.0 o posterior, de Microsoft, también conocido
  como Microsoft XML Core Services, esté instalado en el PC.
  El analizador XML se incluye en muchos productos Microsoft.
  Para determinar si el analizador XML está instalado en el PC, consulte el
  artículo 278674 en la base de conocimientos de Microsoft. Puede encontrar
  este artículo en el siguiente sitio web de Microsoft:

  http://support.microsoft.com/kb/278674

  Si el analizador Microsoft XML Parser 3.0 o posterior no se encuentra,
  necesitará acceder al sitio web de Microsoft para conocer cómo descargar e
  instalar el analizador XML a fin de poder utilizar el soporte de XML para
  transferencia de datos. Consulte el artículo 324460 en la base de
  conocimientos de Microsoft para obtener información sobre la instalación del
  analizador XML. Este artículo se puede encontrar en:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Información de instalación avanzada 

-------------------------------------------------------------------

  Puede utilizar la mayor parte del tema "Configuración del PC" contenido en el Information Center
  de IBM i Access para Windows en lo referente a modificar el nivel de interfaz de usuario, utilizar
  parámetros de línea de mandatos y controlar el comportamiento de la instalación y métodos de
  despliegue.
  Las diferencias se describen en esta sección. 


6.1 Información sobre el producto bajo licencia
-----------------------------------------------

  5733XJ1 no se proporciona como producto bajo licencia para ser instalado en el sistema
  operativo IBM i.
  Sólo está disponible como soporte de almacenamiento de PC. Puede copiarlo en IBM i en
  una ubicación a la que puedan acceder los usuarios, si lo desea.
  

6.2 Archivos de idioma contenidos en la imagen de instalación
-------------------------------------------------------------

  Los archivos de idioma de la instalación ya no residen en directorios MRI29xx diferentes en la
  imagen de instalación. En lugar de ello, existen archivos cab separados para cada idioma. No
  puede eliminar estos archivos cab de la imagen de instalación. 


6.3 Componentes de instalación
------------------------------

  Algunos componentes de IBM i Access para Windows dependen de otros componentes de instalación
  para poder instalarse.  Esta restricción no es aplicable a este paquete.

  Es necesario instalar los componentes de instalación siguientes:
  req (programas necesarios), langacs, amri2924 (inglés)

  Los demás componentes se instalan de forma predeterminada, pero puede cambiar este comportamiento.

  Ahora los idiomas son componentes de la instalación, tal como Required Programs,
  ODBC, etc. Por ello, puede controlar qué idiomas se instalan utilizando los mismos
  métodos utilizados para controlar cualquier componente de la instalación.
  Los nombres de componentes de instalación para los idiomas son amri29xx.  


6.4 Opciones de línea de mandatos
---------------------------------

  En el archivo setup.ini contenido en la imagen de instalación están especificadas las opciones
  de línea de mandatos predeterminadas.
  Estas opciones no se tienen en cuenta si ejecuta setup.exe desde la línea de mandatos y
  especifica opciones.  

  Si utiliza una transformación en la línea de mandatos,
  los valores de línea de mandatos contenidos en setup.ini no se tendrán en cuenta
  porque la transformación es una opción. Tendrá que incluir otras opciones en la línea
  de mandatos tales como información sobre archivos de registro. 

  Para obtener más información, consulte la Sección 3.7 Archivos de registro de la instalación.


6.5 Propiedades públicas
------------------------

  Algunas de las propiedades públicas de IBM i Access para Windows son aplicables a este paquete. 
  A continuación se describen los cambios de uso existentes respecto a IBM i Access para Windows:

  CWBINSTALLTYPE   Esta propiedad sólo se utiliza para una instalación inicial. Sus únicos valores
                   son Típica y Personalizada. El valor predeterminado es Típica.
                   Ejemplo:  setup /vCWBINSTALLTYPE=Típica

  CWBPRIMARYLANG   El idioma principal predeterminado es el entorno local del PC. 
                   Esta propiedad le permite especificar un idioma principal diferente.
                   El valor que se debe utilizar es MRI29xx. 
                   Ejemplo:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   El uso de esta propiedad es el mismo que para IBM i Access para Windows.
                   Le permite actualizar los archivos de SSL durante una actualización. 
                   Si se encuentran archivos de configuración de SSL en el PC de destino,
                   los archivos se actualizarán con los últimos certificados. 
                   Los valores son Sí y No. El valor predeterminado es Sí. 
                   Ejemplo:  setup /vCWBUPGSSLFILES=NO

  Siguen siendo aplicables las propiedades comunes del Instalador de Windows que están listadas
  en el Information Center de IBM i Access para Windows:  ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Existe una restricción en el uso de la propiedad REBOOT del Instalador de Windows para
  IBM i Access para Windows. Esta restricción no es aplicable a este paquete.
  

6.6 Grabación de imágenes administrativas en CD o DVD
-----------------------------------------------------

  Debido a problemas en la forma en que algunos programas de grabación de CD y DVD tratan
  los nombres de archivo largos, no es recomendable grabar un imagen administrativa en un CD
  o DVD. Si tiene problemas al instalar desde de un CD o DVD que contiene una imagen
  administrativa de IBM i Access para Windows, copie la imagen en un directorio del disco duro
  local y ejecute setup.exe desde la copia local.

-------------------------------------------------------------------
7.0 Información de políticas
-------------------------------------------------------------------

  Se utiliza el mismo archivo de política para este paquete e IBM i Access para Windows. 
  Por tanto, algunas de esas políticas no son aplicables cuando se utilizan para este paquete,
  pues algunas de las funciones de IBM i Access para Windows no existen en este paquete. 

-------------------------------------------------------------------

8.0 Mandatos
-------------------------------------------------------------------

  Los mandatos de IBM i Access para Windows que no están incluidos en este paquete son:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe


   [FIN DEL DOCUMENTO]
