==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  All rights reserved. 

==============================================================================
  Dette dokumentet leveres i den stand det befinner seg ("as is"),
  uten garantier av noe slag.  IBM gir ingen garantier, uttrykt
  eller underforstått, inkludert, uten begrensning, underforståtte
  garantier vedrørende anvendelse for et bestemt formål eller
  salgbarhet i forbindelse med informasjonen i dette dokumentet.
  Ved å levere dette dokumentet tildeler IBM ingen lisenser til
  eventuelle patenter eller opphavsretter. 

===============================================================================

Dette dokumentet ble sist oppdatert 04. november 2019

------------------------------------------------------------------- 

INNHOLD 

-------------------------------------------------------------------  

1.0 Innledning
2.0 Informasjonskilder
3.0 Installering
  3.1 Støttede Windows-operativsystemer
  3.2 Hensyn å ta ved installering
  3.3 Oppgradere fra IBM i Access for Windows
  3.4 Kjøre installasjonsprogrammet
  3.5 Nødvendige handlinger etter installering av skriverstyreprogram
  3.6 Hensyn ved installering av 64-biters maskinvare
  3.7 Installasjonslogger
4.0 IBM.Data.DB2.iSeries .NET Provider - krav
5.0 Microsoft XML Parser eller Microsoft XML Core Services
6.0 Avansert installeringsinformasjon
  6.1 Informasjon om lisensiert produkt
  6.2 Språkfiler i installeringsbildet
  6.3 Installerbare funksjoner
  6.4 Kommandolinjeparametere
  6.5 Allmenne egenskaper
  6.6 Brenne administrative bilder til CD eller DVD
7.0 Policyinformasjon
8.0 Kommandoer som ikke er med i pakken
  


-------------------------------------------------------------------

1.0 Innledning
-------------------------------------------------------------------
  Denne pakken er en del av produktet 5733XJ1 IBM i Access Client Solutions.

  Du kan bruke IBM i Access Client Solutions for tilkobling til en støttet IBM i-
  utgave.

  Denne pakken inneholder funksjoner som bare er tilgjengelige på Windows-
  operativsystemer.  Den er basert på produktet 7.1 IBM i Access for Windows, men
  inneholder ikke alle funksjonene i det produktet.

  Følgende funksjoner fra IBM i Access for Windows er med i denne pakken:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer og Sertifikatadministrasjon
    Verktøysett for programmerere for Inkluderingsfiler, biblioteker og dokumentasjon
    AFP-skriverstyreprogram
    Nødvendige programmer, inkludert:
      APIer
      Active X
      Sikkerhet
      Servicemuligheter
      Tilkoblinger
      Språkfunksjoner
      Konverteringstabeller
      Egenskaper
      Policyer
      Nettverksutskrift
      Delsett av kommandoer (Se punkt 8.0 for en liste over hvilke som ikke er med.)
            Brukerhåndbok
      Bruk av Applikasjonsadministrasjon for styring av tilgjengelighet til funksjoner i denne pakken.

  Følgende funksjoner fra IBM i Access for Windows er ikke med i denne pakken. 
  
  Den plattformuavhengige IBM i Access Client Solution-pakken inneholder en erstatning
  for disse funksjonene:
    5250-skjerm- og -skriveremulering
    Dataoverføring
    Excel-tillegg for dataoverføring
    Operasjonskonsoll
  
  Følgende funksjoner fra IBM i Access for Windows er ikke med i denne pakken. 
  
  IBM Navigator for i inneholder en erstatning for disse funksjonene:
    System i-navigator
    Visningsprogram for AFP-arbeidsområde

  Innkommende fjernkommando er ikke med i pakken.  Erstatningen er å bruke Microsofts
  Eksterne skrivebordstjenester.

  Toolbox for Java er heller ikke med i pakken.  Du finner informasjon om nedlasting
  på følgende nettsted:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Andre funksjoner fra IBM i Access for Windows som ikke er med i denne pakken:
    SCS-skriverstyreprogram
    Java Programmer's Tools-pluginmoduler for System i-navigator
    Katalogoppdatering
    Støtte for Lotus 123-filformat
    Kontroller servicenivå

  Siden innholdet i denne pakken også leveres sammen med 7.1 IBM i Access for Windows,
  henviser dokumentasjonen og versjonsinformasjonen til 7.1 IBM i Access for Windows i
  brukerhåndboken, verktøysettet for programmerere, hjelpetekst og meldinger, men
  informasjonen gjelder også for IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Informasjonskilder

-------------------------------------------------------------------

  - Endringer i IBM i Access Client Solutions, inkludert støttede operativsystemer,
oppdateringer, begrensninger, viktige kjente problemer og ny informasjon,
blir publisert på IBM i Access-produktnettstedet:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Brukerhåndboken som blir installert sammen med denne pakken, inneholder informasjon
    om hvordan du bruker produktet, tips og teknikker, meldinger og feilsøking.

  - Tekniske referanser til OLE DB-formidleren og .NET Data Provider blir installert
    når du installerer funksjonen Inkluderingsfiler, biblioteker og dokumentasjon.  Du
    finner de tekniske referansene i Programmer's Toolkit-mappen.

  - IBM i Information Center inneholder en samling med emner utarbeidet for
    IBM i-eksperter som trenger tilgang til teknisk informasjon:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - På utgivelsestidspunktet for denne publikasjonen inneholdt ikke IBM i Information Center
    emner om IBM i Access Client Solutions.  Men mye av informasjonen under IBM i Access
    for Windows gjelder også for denne IBM i Access Client Solutions-pakken, inkludert emnene
    om installering, administrasjon og programmering:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks inneholder artikler, opplæring og tekniske ressurser for
    IBM i-brukere:

    https://www.ibm.com/developerworks/ibmi

  - IBM i-nettstedet inneholder de siste IBM i-nyhetene i tillegg til produktinformasjon, et
    referansebibliotek, veikart for opplæring, og mye mer:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Installeringsinformasjon
-------------------------------------------------------------------



3.1 Støttede Windows-operativsystemer
-------------------------------------

  Denne pakken kan installeres på følgende Microsoft Windows-operativsystemer:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 og Windows Server 2008 R2
         Standard Enterprise (32-bits og 64bits)
   - Windows 7
         Professional, Enterprise og Ultimate (32-bits og 64-bits)

   Disse begrensningene gjelder:
 
          a) Home Editions støttes ikke.
          b) Du må bruke Windows-servicepakkenivåer som støttes av Microsoft.
          c) Støtten opphører når Microsoft avslutter sin støtte.
          d) Installering støttes ikke på Itanium-maskinvare.
          e) Bruk maskinvare og minne som anbefales for Microsoft Windows. Inkluder
        256 MB med ekstra minne for IBM i Access Client Solution-funksjoner.
          f) Produktet kan ikke installeres når du oppgraderer til et annet
        Windows-operativsystem.  Følg denne fremgangsmåten:
          1.  Lagre konfigurasjonsdata.
               2.  Deinstaller produktet.
               3.  Oppgrader Windows-operativsystemet.
               4.  Installer produktet.
               5.  Gjenopprett konfigurasjonsdataene.


3.2 Hensyn å ta ved installering
--------------------------------------------------

  - Administrativ autorisasjon og administrative rettigheter kreves for å kjøre
    installasjonsprogrammet.
  
  - Bare installering per maskin støttes.  Installering per bruker støttes ikke.

  - Windows Installer 4.5 er nødvendig.  Denne Microsoft-programvarekomponenten
    blir installert under installeringen hvis den ikke allerede finnes på
    systemet.  Du kan installere den før installeringen ved å laste den ned
    fra Microsofts nettsted:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Oppgradere fra IBM i Access for Windows
-------------------------------------------

  -  Oppgradering fra IBM i Access for Windows støttes ikke.  Du må
     fjerne IBM i Access for Windows før du installerer denne pakken.  

  -  Punkt 1.0 inneholder en liste over funksjonene som ikke er med i pakken.  Hvis
     du vil fortsette å bruke funksjonene i IBM i Access for Windows som ikke
     er med i denne pakken, må du ikke installere denne pakken, men fortsette å
     bruke den nyeste servicepakken for 7.1 IBM i Access for Windows.

  -  Når du har avinstallert IBM i Access for Windows, blir den eksisterende
     systemkonfigurasjonen slettet.  Hvis du vil beholde den eksisterende
     systemkonfigurasjonen, må du lagre konfigurasjonen før du avinstallerer
     IBM i Access for Windows og deretter gjenopprette konfigurasjonen når IBM i
     Access Client Solutions Windows Application Package er installert.

     Detaljert beskrivelse av hvordan du lagrer og gjenoppretter konfigurasjonen:
     1.  Utfør kommandoen CWBBACK for å reservekopiere IBM i Access for Windows-
         konfigurasjonen.
             cwbback <filename.rs> /u
         For eksempel:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Dette eksempelet forutsetter at mappen C:\Users\IBM_ADMIN\Backup finnes.

         Kommandoen ovenfor oppretter to filer i denne mappen:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Kontroller at de to filene er opprettet, før du går til neste trinn.

         MERK:
         Hvis de to filene ovenfor ikke ble opprettet, har du ikke en lagret
         konfigurasjon.  Prøv å utføre kommandoen som administrator.
         En måte du kan gjøre det på, er ved å åpne en ledetekst:
             Start->Alle programmer->Tilbehør->Ledetekst
         Men i stedet for å venstreklikke på Ledetekst, høyreklikker du og
         velger alternativet "Kjør som Administrator".
         Utfør cwbback-kommandoen ovenfor fra denne ledeteksten.
         Kontroller at de to filene ovenfor er opprettet, før du går til neste trinn.

          2.  Deinstaller IBM i Access for Windows.
          3.  Start maskinen på nytt.
          4.  Installer IBM i Access Client Solutions Windows Application Package.
          5.  Start maskinen på nytt.
          6.  Utfør kommandoen CWBREST for å gjenopprette konfigurasjonen du lagret
              med kommandoen CWBBACK.
             cwbrest <filename.rs> /c
         For eksempel:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Hvis du måtte følge instruksjonene under MERK i trinn 1, må du også
         utføre kommandoen CWBREST fra en administrator-ledetekst.

  -  Det er flere måter du kan verifisere Windows-konfigurasjonen på før og
     etter trinnene ovenfor:
     1. Kontroller Windows-registeret.  Systemkonfigurasjoner er lagret her:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Hvis du vil se innholdet i Windows-registeret for den plasseringen, oppgir du denne kommandoen:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Hvis du har et miljø som har et annet navn enn standardverdien
        "My Connections", endrer du banen ovenfor tilsvarende.

     2. Hvis du har en plattformuavhengige versjonen av IBM i Access Client Solutions på samme
        PC, kan du velge følgende fra hovedvinduet i det grafiske brukergrensesnittet:
            Fil->Kopier tilkoblinger
        Høyre side vil vise "IBM i Access (Windows)".  Dette er konfigurasjonen som brukes for
        både IBM i Access for Windows og IBM i Access Client Solutions Windows Application
        Package.


3.4 Kjøre installasjonsprogrammet
---------------------------------

  - Kjør setup.exe i installeringskopien for å starte installeringen.  (Kommandoen
    cwblaunch.exe leveres ikke med dette produktet.)
   
            Merk:  Direkte aktivering av MSI-filer (Microsoft Installer) anbefales ikke
             fordi setup.exe bruker setup.ini for en liste over kommandolinje-
             parametere som skal brukes, og for oppdatering av Windows Installer-
             versjonen hvis det er nødvendig.
    
  - Det anbefales at du bruker standard målmappe.  Merk følgende hvis du endrer
    mappen:
     
          a) Ikke velg rotkatalogen for en stasjon.
          b) Ikke velg en katalog som allerede inneholder filer som ikke
        er knyttet til dette produktet.
          c) Ikke velg en nettverksstasjon.  Installering på en nettverksstasjon
        støttes ikke.


3.5 Nødvendige handlinger etter installering av skriverstyreprogram
-------------------------------------------------------------------

  Hvis du installerer AFP-skriverstyreprogrammet, er det ting du må gjøre før du
  kan bruke det.  Det er nødvendig fordi skriverstyreprogrammet ikke kan tilføyes
  eller oppdateres automatisk under installeringen siden det ikke er digitalt
  signert av Microsoft.  

  Under installeringen kopieres skriverstyreprogramfilene til underkatalogen
  CWBAFP under målbanen som er valgt.  Hvis du installerer med standard
  målbane, er banen følgende:

  c:\Programfiler\IBM\Client Access\CWBAFP 

  Følg Microsofts instruksjoner i hjelpeteksten når du skal tilføye eller
  oppdatere skriverstyreprogrammet.
  Oppgi banen til CWBAFP når du blir bedt om det. 

  Hvis du installerer på en PC som har oppgradert IBM i Access
  for Windows-produktet over flere utgaver, kan det hende at gammel
  informasjon vises når du konfigurerer skriverstyreprogrammet.  Du kan
  fjerne den gamle informasjonen fra .inf-filene ved å gjøre følgende
  etter at du har fullført installeringen:

    a) Åpne et forespørselsbilde.
        b) Endre katalog til installeringskatalogen. Standard
       installeringskatalog er c:\Programfiler\IBM\Client Access.
        c) Skriv inn "cwbrminf", og trykk på Enter. 


3.6 Hensyn ved installering av 64-biters maskinvare
---------------------------------------------------

  Når du installerer på et støttet 64-biters Windows-operativsystem:
  
  -  Både 32-biters versjonen og 64-biters versjonen blir installert for ODBC, OLE DB,
     ActiveX og Secure Sockets Layer (SSL).  

  -  .NET-formidleren for IBM i Access for Windows kjører fra både 32-biters og
     64-biters applikasjoner avhengig av applikasjonen som anroper formidleren.

  -  Bare en versjon av AFP-skriverstyreprogrammet blir installert.  64-biters versjonen
     blir installert på 64-biter systemer og 32-biters versjonen blir installert på
     32-biters systemer.


3.7 Installasjonslogger
-----------------------

  To logger opprettes under installeringen. En logg er spesifikk for XJ1 og
  inneholder informasjon om de tilpassede handlingene for produktet.  Denne
  loggen har navnet "xe1instlog.txt" og opprettes alltid i brukerens
  temp-katalog.

  Den andre loggen er Microsfts MSI-logg. Den inneholder informasjon om
  MSI-hendelser, -sekvenser og -egenskaper.  Som standard har denne loggen
  navnet "xe1instlogmsi.txt", og den opprettes i brukerens temp-katalog.   Du
  kan endre denne loggen ved å redigere setup.ini i installeringsbildet.  Gå
  til nøkkelordet [Startup], og finn og rediger denne posten: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Hvis du vil forhindre at loggen opprettes, fjerner du posten
    - Hvis du vil endre plassering og navn for loggen, endrer du banen og filnavnet
    - Hvis du vil endre innholdet i loggen, endrer du /l* til noe annet, som
      beskrevet i Microsofts MSDN Windows Installer Command Line Options
      på denne adressen: 

      http://msdn.microsoft.com/default.aspx   

  Standard kommandolinjeinformasjon i setup.ini kan overstyres ved at du starter
  setup.exe på kommandolinjen med kommandolinjeparametere.



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET Provider - krav 

-------------------------------------------------------------------

  - IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries)
    krever at Microsoft .NET Framework versjon 2.0 eller senere er installert på
    systemet.  På de fleste PCer som kjører støttede Microsoft-operativsystemer, er
    .NET Framework allerede installert.  Du kan laste ned .NET Framework fra Microsofts nettsted: 

    http://www.microsoft.com/net 

  - For å unngå problemer med .NET-applikasjoner som er skrevet for .NET-formidlergrensesnittet
    Access for Windows 5.3 eller 5.4, må kjøreforespørsler for 10.0.0.0-versjonen av
    .NET-formidleren omdirigeres til 12.0.0.0-versjonen.  Se emnet "Incompatible changes from 5.3
    and 5.4" i IBM DB2 for i .NET Provider Technical Reference hvis du vil ha instruksjoner om
    bruk av en app.config-fil, en web.config-fil eller en machine.config-fil og informasjon om
    valg av en passende kompilator for omdirigering av eksisterende applikasjoner.

    Applikasjonen kan også kompileres på nytt ved å bruke en nyere kompilatorer til å utnytte
    12.0.0.0-versjonen av .NET-formidleren som er inkludert i IBM i Access for Windows
    utgave 7.1.

  - Hvis du vil ha fullstendig informasjon og en liste over endringer som ikke er kompatible,
    installerer du funksjonen Inkluderingsfiler, biblioteker og dokumentasjon,
    og deretter åpner du .NET Provider Technical Reference. 

-------------------------------------------------------------------

5.0 IBM Microsoft XML Parser eller Microsoft XML Core Services

-------------------------------------------------------------------

  Når du bruker IBM i Access for Windows Data Transfer ActiveX-automatiseringsobjekter
  ved overføring av filer til og fra Microsoft Excel XML-formatet (støttes av Excel 2003
  og Excel XP), må tilleggsprogramvare være installert på PCen. Denne funksjonen krever
  at Microsoft XML Parser 3.0 eller nyere, også kjent som Microsoft XML Core Services,
  er installert på PCen. XML Parser er inkludert i mange Microsoft-produkter.  Når du skal
  finne ut om XML Parser-støtte er installert på PCen, kan du lese Microsoft KB-artikkel
  278674.  Du finner denne artikkelen på Microsofts nettsted med denne adressen:

  http://support.microsoft.com/kb/278674

  Hvis Microsoft XML Parser 3.0 eller senere ikke blir funnet, må du få tilgang til
  Microsofts nettsted for å få instruksjoner om nedlasting og installering av XML Parser
  før du kan bruke XML-støtten i dataoverføringen.  Microsofts KB-artikkel 324460
  inneholder informasjon om installering av XML Parser.  Du finner denne artikkelen her:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Avansert installeringsinformasjon

-------------------------------------------------------------------

  Du kan bruke det meste av informasjonen om endring av brukergrensesnittnivå, bruk av
  kommandolinjeparametere og kontroll av andre installeringsmiljøer og
  distribueringsmetoder i emnegruppen "Setting the PC" i IBM Information Center for
  IBM i Access for Windows.  Forskjellene er beskrevet nedenfor.


6.1 Informasjon om lisensiert produkt
-------------------------------------
  
  5733XJ1 er ikke pakket som et lisensiert produkt som skal installeres på IBM i-operativsystemet.
  Det er bare tilgjengelig som PC-medium. Du kan kopiere det til IBM i på en plassering som er
  tilgjengelig for brukerne, hvis du ønsker det.
  

6.2 Språkfiler i installeringsbildet
------------------------------------
  
  Installeringsfilene for språk er ikke lenger atskilt i forskjellige MRI29xx-kataloger
  i installeringsbildet. Det finnes i stedet egne cab-filer for hvert språk.  Du kan
  ikke fjerne disse cab-filene fra installeringsbildet.


6.3 Installerbare funksjoner
----------------------------

  Enkelte installerbare funksjoner i IBM i Access for Windows var avhengig av at andre
  installerbare funksjoner var installert.  Denne begrensningen gjelder ikke for denne pakken.

  Følgende installerbare funksjoner må installeres:
    req (nødvendige programmer)
    langacs, amri2924 (engelsk)

  Alle andre installerbare funksjoner blir installert som standard, men du kan endre innstillingen.

  Språk er nå installerbare funksjoner slik nødvendige programmer og ODBC er. Siden språk er
  installerbare funksjoner, kan du bestemme hvilke språk du vil installere, på samme måte
  som når du velger andre installerbare funksjoner.  Navnene på de installerbare funksjonene
  for språk er amri29xx.  


6.4 Kommandolinjeparametere
---------------------------

  Standard kommandolinjeparametere er oppgitt i filen setup.ini som er inkludert i
  installeringsbildet.  Disse parameterne blir oversett hvis du starter setup.exe fra
  kommandolinjen og oppgir parametere.  

  Om du bruker transformering på kommandolinjen, blir kommandolinjeverdiene i setup.ini
  oversett fordi transform er en parameter.  Du må ta med andre parametere på
  kommandolinjen også, for eksempel informasjon om logging.

  Se punkt 3.7 Installasjonslogger hvis du ønsker mer informasjon.


6.5 Allmenne egenskaper
-----------------------

  Enkelte av de allmenne egenskapene i IBM i Access for Windows gjelder for denne pakken.  Bruken
  er endret noe i forhold til i IBM i Access for Windows, slik det er beskrevet her:

  CWBINSTALLTYPE   Denne egenskapen brukes bare ved første gangs installering.  De eneste
                   verdiene er Typical og Custom.  Standardverdien er Typical.
                                      Eksempel: setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Standard primærspråk er språkmiljøet på PCen.  Med denne egenskapen kan du
                   oppgi et annet primærspråk. Verdien er MRI29xx. 
                   
                   Eksempel: setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Bruken av denne egenskapen er som i IBM i Access for Windows.  Den gjør det mulig
                   å oppgradere SSL-filene under en oppgradering.  Hvis konfigurasjonsfilene for
                   SSL blir funnet på mål-PCen, blir filene oppdatert med de nyeste
                   sertifikatene.  Verdiene er Yes og No.
                                      Eksempel: setup /vCWBUPGSSLFILES=NO

  De vanlige Windows Installer-egenskapene som er oppgitt i IBM i Access for Windows Information Center,
  gjelder fortsatt:  ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Det finnes en begrensning for bruken av Windows Installer-egenskapen REBOOT sammen med
  IBM i Access for Windows.  Denne begrensningen gjelder ikke for denne pakken.
  

6.6 Brenne administrative bilder til CD eller DVD
-------------------------------------------------

  På grunn av problemer med hvordan diverse programvare for CD- og DVD-brenning håndterer
  lange filnavn, anbefales det ikke at du brenner et administrativt bilde til en CD eller
  DVD. Hvis du får problemer med installering fra en CD eller DVD som inneholder et administrativt
  bilde av IBM i Access for Windows, kan du kopiere bildet til en katalog på den lokale
  harddisken og kjøre setup.exe fra den lokale kopien.

-------------------------------------------------------------------
7.0 Policyinformasjon
-------------------------------------------------------------------

  Samme policy-fil blir brukt for denne pakken og IBM i Access for Windows. Det
  betyr at enkelte av policyene ikke gjelder for denne pakken, fordi enkelte av
  funksjonene i IBM i Access for Windows ikke finnes i denne pakken.

-------------------------------------------------------------------

8.0 Kommandoer
-------------------------------------------------------------------

  Kommandoer i IBM i Access for Windows som ikke er med i denne pakken:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    

   [SLUTTEN PÅ DOKUMENTET]
