==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Her hakkı saklıdır. 

==============================================================================
     Bu belge, herhangi bir garanti verilmeden "olduğu gibi" sağlanmıştır.  IBM,
    ticarilik ve belirli bir amaca uygunluk için açık veya zımni garantiler de
    dahil, ancak bunlarla sınırlı olmamak üzere tüm garantileri reddeder. Bu
    belgenin düzenlenmesiyle, IBM herhangi bir patent ya da telif hakkı için
    lisans vermiş olmaz. 

===============================================================================

Bu belgenin en son güncellemesi:  04 Kasım 2019

------------------------------------------------------------------- 

İÇİNDEKİLER 

-------------------------------------------------------------------  

1.0 Giriş 2.0 Bilgi Kaynaklarının Yeri 3.0 Kuruluş
  3.1 Desteklenen Windows İşletim Sistemleri
  3.2 Kuruluşta Dikkat Edilmesi Gereken Koşullar
  3.3 IBM i Access for Windows ürününden büyütme
  3.4 Kuruluşun Çalıştırılması
  3.5 Yazıcı Sürücüsünün Kuruluşundan Sonra Yapılması Gereken İşlemler
  3.6 64 Bitlik Donanım Kuruluşuyla İlgili Dikkat Edilmesi Gereken Koşullar
  3.7 Kuruluş Günlükleri
4.0 IBM.Data.DB2.iSeries .NET Provider Gereksinimleri
5.0 Microsoft XML Parser ya da Microsoft XML Core Services
6.0 İleri Düzey Kuruluş Bilgileri
  6.1 Lisanslı Ürün Bilgileri
  6.2 Kuruluş Görüntüsündeki Dil Dosyaları
  6.3 Kuruluş Özellikleri
  6.4 Komut Satırı Seçenekleri
  6.5 Genel Özellikler
  6.6 Denetimci Görüntülerini CD ya da DVD'ye Yazma
7.0 İlke Bilgileri
8.0 İçerilmeyen Komutlar
  


-------------------------------------------------------------------

1.0 Giriş
-------------------------------------------------------------------
  Bu paket 5733XJ1 IBM i Access Client Solutions ürününün bir parçasıdır.

  IBM i Access Client Solutions ürününü kullanarak, desteklenen herhangi bir IBM i yayın düzeyine bağlanabilirsiniz.

  Bu pakette, yalnızca Windows işletim sistemlerinde kullanılabilen işlevler yer almaktadır.  Paket, 7.1 IBM i Access for Windows ürününü temel almaktadır, ancak bu ürünün tüm özelliklerini içermez.

  Bu pakette yer alan IBM i Access for Windows özellikleri şunlardır:
    .NET Data Provider
    ODBC
    OLE DB
    Güvenlik Yuva Katmanı ve Sertifika Yönetimi
    Üstbilgiler, Kitaplıklar ve Belgeler içim Programcı Araç Takımı
    AFP Yazıcı Sürücüsü
    Gerekli Programlar şu şekildedir:
      API'ler
      Active X
      Güvenlik
      Hizmet Verilebilirlik
      Bağlantılar
      NLS Etkinleştirme
      Dönüştürme çizelgeleri
      Özellikler
      İlkeler
      Ağda Yazdırma
      Komut Alt Kümeleri (Burada yer almayan komutların listesi için bkz. Bölüm 8.0.)
      Kullanıcı Kılavuzu
      Paketteki işlevlere erişimi denetlemek için Uygulama Yönetimi'nin kullanımı

  Aşağıda listelenen IBM i Access for Windows özellikleri bu paketin bir parçası değildir. 
  Platformdan bağımsız IBM i Access Client Solution paketinde şu özelliklerin yerine geçen özellikler vardır:
    5250 Görüntüleme ve Yazıcı Öykünmesi
    Veri Aktarma
    Veri Aktarma Excel Eklentisi
    Operations Console
  
  Aşağıda listelenen IBM i Access for Windows özellikleri bu paketin bir parçası değildir. 
  IBM Navigator for i uygulamasında şu özelliklerin yerine geçen özellikler vardır:
    System i Navigator
    AFP Workbench Viewer

  Gelen Uzak Komut içerilmez.  Bunun yerine Microsoft'un
  Remote Desktop Services olanağı kullanılacaktır.

  Toolbox for Java içerilmez.  Aşağı yükleme bilgileri için şu web sitesini kullanın:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  IBM i Access for Windows ürününün bu pakette yer almayan diğer özellikleri şunlardır:
    SCS Yazıcı Sürücüsü
    System i Navigator eklentilerine ilişkin Java Programcı Araçları
    Dizin Güncelleme
    Lotus 123 Dosya Biçimi Desteği
    Denetim Hizmet Düzeyi

  Bu paketin içeriği, 7.1 IBM i Access for Windows ürünüyle de birlikte gönderildiğinden,
  Kullanıcı Kılavuzu, Programcı Araç Takımı, yardım metinleri ve iletilerdeki belgeler ve
  sürüm bilgileri genellikle 7.1 IBM i Access for Windows uygulamasını yansıtır, ancak bunlar
  aynı zamanda IBM i Access Client Solutions - Windows Application Package ürünü için de
  geçerlidir.


-------------------------------------------------------------------

2.0  Bilgi Kaynaklarının Yeri

-------------------------------------------------------------------

  - Desteklenen işletim sistemleri, güncellemeler, kısıtlamalar,
önemli bilinen sorunlar, yeni bilgiler dahil ve bunlarla sınırlı
olmamak üzere IBM i Access Client Solutions ürünündeki
değişiklikler IBM i Access ürün web sitesinde yayınlanacaktır:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Bu paketle birlikte sağlanan Kullanıcı Kılavuzu'nda ürünü kullanma, ipuçları ve teknikler,
iletiler ve sorun giderme bilgileri hakkında bilgi sağlanmaktadır.

  - OLE DB sağlayıcısına ve .NET Data Provider olanağına ilişkin teknik başvurular
Üst Bilgiler, Kitaplıklar ve Belgeler özellikleri kurulduğunda yüklenir.  Teknik başvuruları
Programcı Araç Takımı'nda bulabilirsiniz.

  - IBM i Information Center olanağı, teknik bilgilere erişmesi gereken IBM i uzmanları için
tasarlanmış konular sağlar.

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Bu belgenin yayınlandığı tarihte, IBM i Information Center olanağında IBM i Access Client
    Solutions ürününe ilişkin konular yer almamaktaydı.  Ancak, kuruluş, yönetim ve programlama
    konuları da içinde olmak üzere IBM i Access for Windows kapsamındaki birçok bilgi
    IBM i Access İstemci Client Solutions ürünün bu paketi için de geçerlidir.

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks web sitesinde, IBM i kullanıcıları için makaleler, eğitim ve
    teknik kaynaklar yer almaktadır:

    https://www.ibm.com/developerworks/ibmi

  - IBM i web sitesi, en son IBM i haberlerinin yanı sıra ürün bilgileri, bir başvuru
  kitaplığı ve eğitim yol haritaları içermektedir:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Kuruluş Bilgileri
-------------------------------------------------------------------



3.1 Desteklenen Windows İşletim Sistemleri
---------------------------------------

  Bu paket, şu Microsoft Windows işletim sistemlerine kurulabilir:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 ve Windows Server 2008 R2
         Standard Enterprise (32 bit ve 64 bit)
   - Windows 7
         Professional, Enterprise ve Ultimate (32 bit ve 64 bit)

   Aşağıdaki kısıtlamalar geçerlidir:
 
     a) Home Edition sürümleri desteklenmemektedir.
     b) Microsoft'un desteklediği Windows hizmet paketi düzeylerini kullanmanız gerekir.
     c) Microsoft'un desteği kaldırıldığında, bu üründeki destek de kaldırılır.
     d) Itanium donanımlarında kuruluş desteklenmemektedir.
     e) Microsoft Windows donanım ve bellek önerilerini kullanın. IBM i Access
     Client Solution işlevleri için 256 MB'lik ek bir bellek ekleyin.
     f) Ürün, farklı bir Windows işletim sistemine büyütme yaparken kurulmaz.  Şu adımları izleyin:
          1.  Konfigürasyon verilerini kaydedin.
          2.  Ürünü kaldırın.
          3.  Windows işletim sistemini büyütün.
          4.  Ürünü kurun.
          5.  Konfigürasyon verilerini geri yükleyin.


3.2 Kuruluşta Dikkat Edilmesi Gereken Koşullar
--------------------------------------------------

  - Kuruluşu gerçekleştirmek için denetimci yetkisi ve ayrıcalıkları gerekir.
  
  - Yalnızca makine başına kuruluşlar desteklenmektedir.  Kullanıcı başına kuruluşlar
  desteklenmez.

  - Windows Installer 4.5 sürümü gereklidir.  Bu Microsoft yazılım bileşeni
    sistemde yoksa kuruluş işlemi sırasında kurulur.  Bu bileşeni Microsoft web
    sitesinden yükleyerek kuruluş işleminden önce kurabilirsiniz:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 IBM i Access for Windows ürününden büyütme
-------------------------------------------

  -  IBM i Access for Windows ürününden büyütme desteklenmez.  Bu  paketi kurmadan
     önce, IBM i Access for Windows ürününü kaldırmalısınız.  

  -  İçerilmeyen özelliklerin bir listesi için Bölüm 1.0'a bakın.  Bu pakete dahil olmayan
     özellikleri IBM i Access for Windows'ta kullanmaya devam etmek istiyorsanız, bu paketi
     kurmayıp 7.1 IBM i Access for Windows'un en son hizmet paketini kullanmaya devam edin.

  -  IBM i Access for Windows kaldırıldığında var olan sistem yapılanışı
     silinir. Var olan sistem yapılanışını korumak için, IBM i Access for Windows'u
     kaldırmadan önce yapılanışı kaydedip IBM i Access Client Solutions Windows
     Application Package kurulduktan sonra geri yüklemeniz gerekecektir. 

     Aşağıda, yapılanışınızı kaydetmek ve gri yüklemek için ayrıntılı
adımlar verilmiştir:
     1.  IBM i Access for Windows yapılanışını yedeklemek için CWBBACK komutunu kullanın.
             cwbback <dosyaadı.rs> /u
         Örneğin:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Bu örnek C:\Users\IBM_ADMIN\Backup klasörünün önceden var olduğunu varsayar.

         Yukarıdaki komut ilgili klasörde iki dosya oluşturur:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Sonraki adıma geçmeden önce bu iki dosyasının oluşturulduğundan emin olun.

         NOT:
         Yukarıdaki iki dosya oluşturulmadıysa kayıtlı bir yapılanışınız yok demektir.  Komutu yükseltilmiş yönetici olarak çalıştırmayı deneyin.
         Bunu yapmanın yollarından biri şudur:
             Başlat->Tüm Programlar->Donatılar->Komut İstemi
         Ancak komut isteminden sol tıklatma kullanmak yerine sağ
         tıklatın ve "Yönetici olarak çalıştır" seçeneğini belirleyin.
         Bu komut istemini kullanarak yukarıdaki cwbback komutunu çalıştırın.
         Sonraki adıma geçmeden önce yukarıdaki iki dosyanın oluşturulduğundan emin olun.

     2.  IBM i Access for Windows'u kaldırın.
     3.  Sistemi yeniden başlatın.
     4.  IBM i Access Client Solutions Windows Uygulama Paketini kurun.
     5.  Sistemi yeniden başlatın.
     6.  CWBBACK komutuyla saklanan konfigürasyonu geri yüklemek için CWBREST
         komutunu kullanın.
             cwbrest <dosyaadı.rs> /c
         Örneğin:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Adım 1'deki NOT içindeki yönergeleri izlemeniz istendiyse cwbrest komutunu da
         yükseltilmiş yönetici komut isteminden çalıştırmanız gerekir.

  -  Windows yapılanışınızı yukarıdaki adımlardan önce ve sonra
     doğrulayabileceğiniz birkaç yöntem bulunamktadır:
     1. Windows kayıt defterini denetleyin.  Sistem yapılanışları şurada depolanır:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Bu konumdaki Windows kayıt defteri içeriğini görüntülemek için şu komutu girin:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Varsayılan "Bağlantılarım" ortamından farklı adda bir ortamınız varsa
        yukarıdaki yolda uygun değişiklikleri yapın.

     2. Aynı kişisel bilgisayarda platformdan bağımsız bir IBM i Access Client Solutions
        sürümünüz varsa, GGUI panosunda şunu seçebilirsiniz:
            Dosya->Bağlantıları Kopyala
        Sağ tarafta "IBM i Access (Windows)" görüntülenir.  Bu, hem
        IBM i Access for Windows hem de IBM i Access Client
        Solutions Windows Uygulama Paketi için kullanılan bir yapılanıştır.


3.4 Kuruluşun Çalıştırılması
-----------------------

  - Kuruluşu başlatmak için kuruluş görüntüsünde setup.exe'yi çalıştırın.  (cwblaunch.exe komutu bu ürünle birlikte sağlanmaz.)
   
      NOT:   Microsoft Installer (MSI) dosyalarının doğrudan başlatılması önerilmez.
             Bunun nedeni setup.exe dosyasının, kullanılacak bir dizi Komut Satırı
             Seçenekleri için ve gerekirse Windows Installer sürümünü güncellemek için
             setup.ini dosyasını kullanmasıdır.
    
  - Varsayılan hedef klasörü kullanmanız önerilir.  Ancak, klasörü değiştirirseniz:
     
     a) Sürücünün kök dizinini seçmeyin.
     b) Bu ürünle ilgili olmayan dosyaları içeren bir dizini seçmeyin.
     c) Bir ağ sürücüsü seçmeyin.  Bir ağ sürücüsüne kuruluş desteklenmez.


3.5 Yazıcı Sürücüsünün Kuruluşundan Sonra Yapılması Gereken İşlemler
---------------------------------------------------

  APF yazıcı sürücüsünü kurarsanız, yazıcı sürücüsünü kullanmadan önce bir işlem yapmanız
gerekir.  Yazıcı sürücüsünün Microsoft tarafından dijital olarak imzalanmaması nedeniyle,
yazıcı sürücüsü kuruluş sırasında otomatik olarak eklenemediği ya da güncellenemediği
için bu işlem gereklidir.  

  Kuruluş işlemi sırasında, yazıcı sürücüsü dosyaları seçilen bir hedef yolundaki CWBAFP
adlı bir alt dizine kopyalanır.  Kuruluş işlemi varsayılan hedef yola yapılırsa, yol şu
şekilde olur:

  c:\Program Files\IBM\Client Access\CWBAFP dizini 

  Yazıcı sürücüsünü eklemek ya da güncellemek için yardım metni içinde Microsoft'un
yönergelerini izleyin.
  İstendiğinde, CWBAFP dizin yolunu belirleyin. 

  IBM i Access for Windows ürününün birkaç yayın düzeyi büyütmesinin gerçekleştirilmiş
  olduğu bir kişisel bilgisayar üzerinde kuruluş yapıyorsanız, bir yazıcı sürücüsü
  konfigürasyonu tanımlanırken bazı eski bilgiler görüntülenebilir.  Artık geçerli olmayan
  bu bilgileri .inf dosyalarından kaldırmak için kuruluşu tamamladıktan sonra aşağıdaki
  işlemleri yapın:
    a) Bir komut istemi penceresi açın.
    b) Kuruluş dizininize gidin. Varsayılan kuruluş dizini c:\Program Files\
        IBM\Client Access dizinidir.
    c) "cwbrminf" yazın ve Enter tuşuna basın. 


3.6 64 bitlik donanım kuruluş koşulları
-----------------------------------------------

  Desteklenen 64 bitlik bir Windows işletim sisteminde kuruluş yaparken:
  
  -  ODBC, OLE DB, ActiveX ve Secure Sockets Layer (SSL) için 32 bitlik sürüm ve 64 bitlik
     sürümün kurulu olması gerekir.  

  -  IBM i Access for Windows .NET Provider, sağlayıcıyı çağıran uygulamaya bağlı olarak
     hem 32 bitlik hem de 64 bitlik uygulamalar üzerinde çalışır.

  -  AFP Yazıcı Sürücüsünün yalnızca bir sürümü kurulur.  64 bitlik sürüm, 64 bitlik sistemlere
     ve 32 bitlik sürüm ise 32 bit sistemlere kurulur.


3.7 Kuruluş günlükleri
---------------------

  Kuruluş sırasında iki günlük yaratılır. Günlüklerden biri XJ1'e özgüdür; diğeri ise
  ürününün özel bilgi işlem bilgilerini içerir.  "xe1instlog.txt" adını taşıyan bu günlük
  her zaman kullanıcının geçici dizininde yaratılır.

  Diğer günlük, MSI olayları, sıraları ve özellikleriyle ilgili bilgilerin bulunduğu
  Microsoft'un MSI günlüğüdür.  Varsayılan değer olarak, bu günlük "xe1instlogmsi.txt"
  adını taşır ve kullanıcının geçici dizinde yaratılır.   Bu günlüğü, kuruluş görüntüsündeki
  setup.ini dosyasını düzenleyerek değiştirebilirsiniz.  [Startup] anahtar sözcüğüne gidin, şu girişi bulun
  ve düzenleyin: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Günlüğün yaratılmasını engellemek için girişi kaldırın
    - Günlüğün konumunu ve adını değiştirmek için yolu ve dosya adını değiştirin
    - Günlüğün içeriğini değiştirmek için /l* parametresini aşağıdaki adreste
    Microsoft'un MSDN Windows Installer Command Line Options konusunda açıklanan farklı
    seçeneklere ayarlayın: 

      http://msdn.microsoft.com/default.aspx   

  setup.ini dosyasındaki varsayılan komut satırı bilgileri, komut satırı seçenekleriyle
  birlikte komut bilgi isteminde setup.exe komutu başlatılarak geçersiz kılınabilir.



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET Provider gereksinimleri 

-------------------------------------------------------------------

  - IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries), sisteminizde
    Microsoft .NET Framework Version 2.0 ya da sonraki sürümünün kurulu olmasını
    gerektirir.  Desteklenen Microsoft işletim sistemlerinde çalışan birçok
    kişisel bilgisayarda gerekli olan .NET Framework programı önceden kuruludur.  .NET Framework, aşağıdaki Microsoft Web sitesinden yüklenebilir: 

    http://www.microsoft.com/net 

  - Access for Windows 5.3 ya da 5.4 .NET Provider arabiriminde yazılan .NET uygulamalarını
    kesmemek için .NET Provider'ın 10.0.0.0 sürümünü çalıştırma istekleri, yeni 12.0.0.0
    sürümüne yöneltilmelidir.  Bir app.config dosyası, web.config dosyası ya da machine.config
    dosyasının kullanılmasına ve varolan uygulamaları yeniden yönlendirmek için uygun bir
    derleyici seçmeye ilişkin yönergeler için IBM DB2 for IBM i işletim sistemine ilişkin
    .NET Provider Technical Reference belgesindeki "Incompatible changes from 5.3 and 5.4"
    başlıklı konuya bakın.

    Ayrıca, uygulama, IBM i Access for Windows 7.1 yayın düzeyinde içerilen
    .NET Provider'daki 12.0.0.0 sürümü hedeflenerek yeni derleyici kullanılarak da
    yeniden derlenebilir.

  - Tam bilgilere ve uyumsuz değişikliklerin bir listesine erişmek için Üstbilgiler,
    Kitaplıklar ve Belgeler özelliğini kurmanız ve daha sonra, .NET Provider Teknik
    Başvuru olanağını görüntülemeniz gerekir. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser ya da Microsoft XML Core Services

-------------------------------------------------------------------

  IBM i Access for Windows Veri Aktarma ActiveX otomasyon nesnelerini kullanarak
  Microsoft Excel XML biçiminden ve Microsoft Excel XML biçimine (Excel 2003 ve
  Excel XP) dosyaları aktarmak için kişisel bilgisayarınızda ek bir yazılımın kurulu olması
  gerekir. Bu özellik, Microsoft XML Parser 3.0 ya da sonra bir sürümünün de (Microsoft XML
  Core Services olarak bilinir) kişisel bilgisayarınızda kurulu olmasını gerektirir. XML Parser
  birçok Microsoft ürününde yer alır.  XML Parser desteğinin kişisel bilgisayarınızda kurulu olup
  olmadığını belirlemek için 278674 numaralı Microsoft makalesine bakın.  Bu makaleyi aşağıdaki
  Microsoft Web sitesinde bulabilirsiniz:

  http://support.microsoft.com/kb/278674

  Microsoft XML Parser 3.0 ya da sonraki sürümü yoksa, Veri Aktarımı XML desteğini
  kullanmadan önce XML Parser'ın yüklenmesi ve kurulması konusunda yönergeler için Microsoft
  Web sitesine erişmeniz gerekir.  XML Parser'ın kurulmasıyla ilgili bilgi için 324460
  numaralı Microsoft makalesine başvurun.  Bu makaleyi aşağıdaki
  Microsoft Web sitesinde bulabilirsiniz:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 İleri Düzey Kuruluş Bilgileri

-------------------------------------------------------------------

  - IBM i Access for Window ürününe ilişkin IBM i Information Center olanağındaki
    "Setting up the PC" başlığı altında bulunan, kullanıcı arabirimi düzeyinin değiştirilmesi,
    komut satırı parametrelerinin kullanılması ve diğer kuruluş ortamlarının denetlenmesi ve
    yerleştirme yöntemleriyle ilgili bilgilerin çoğunu kullanabilirsiniz.  Farklar bu bölümde açıklanmıştır.


6.1 Lisanlı Ürün Bilgileri
----------------------------------
  
  5733XJ1, IBM i işletim isteminde kurulmak üzere bir Lisanslı Ürün olarak
  paketlenmemiştir.
  Yalnızca kişisel bilgisayar ortamında kullanılabilir. İsterseniz,
  bunu kullanıcılarınız için uygun olan bir konumda IBM i uygulamasına ekleyebilirsiniz.
  

6.2 Kuruluş Görüntüsündeki Dil Dosyaları
--------------------------------------------
  
  Dil kuruluş dosyaları, kuruluş görüntüsünde artık farklı MRI29xx dizinlerine ayrılmamaktadır. Bunun yerine, her bir dil için ayrı cab dosyaları var.  Bu cab dosyalarını görüntüden
  kaldıramazsınız.


6.3 Kuruluş Özellikleri
--------------------

  IBM i Access for Windows uygulamasındaki bazı kuruluş özellikleri, kurulacak diğer
  kuruluş özelliklerine bağlıdır.  Bu sınırlama, bu paket için geçerli değildir.

  Aşağıdaki kuruluş özelliklerinin kurulması zorunludur:
    req (Zorunlu programlar)
    langacs, amri2924 (İngilizce)

  Bütün diğer kuruluş özellikleri varsayılan olarak kurulur, ancak bu ayarı siz değiştirebilirsiniz.

  Diller de artık Zorunlu Programlar, ODBC vb. gibi birer kuruluş özelliğidir. Bu nedenle,
  herhangi bir kuruluş özelliğini denetlemek için kullandığınız aynı yöntemleri kullanarak
  hangi dilleri kuracağınızı denetleyebilirsiniz.  Dillere ilişkin kuruluş özelliği adları,
  amri29xx şeklindedir.  


6.4 Komut Satırı Seçenekleri
------------------------

  Varsayılan komut satırı seçenekleri, kuruluş görüntüsünde yer alan setup.ini dosyasında
  bulunur.  Komut satırından herhangi bir seçenek belirlenmiş bir şekilde setup.exe dosyasını
  çağırırsanız bu seçenekler dikkate alınmaz.  

  Komut satırında bir dönüştürme kullanıyorsanız, dönüştürme bir özellik olduğu
  için setup.ini dosyasındaki komut satırı değerleri dikkate alınmaz.  Komut satırına, örneğin,   günlüğe kaydetme bilgileri gibi diğer seçenekleri de dahil etmeniz gerekir.

  Ek bilgi için Bölüm 3.7 Kuruluş Günlükleri başlıklı konuya bakın.


6.5 Genel Özellikler
---------------------

  Bazı IBM i Access for Windows genel özellikleri bu paket için geçerlidir.  IBM i Access for Windows kullanımından farklı olan değişiklikler aşağıda şu şekilde açıklanmıştır:

  CWBINSTALLTYPE   Bu özellik yalnızca ilk kuruluş sırasında kullanılır.  Değerler yalnızca
  Typical and Custom'dır.  Varsayılan değer ise Typical değeridir.
                   Örnek:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Varsayılan birincil dil, kişisel bilgisayarınızın yerel ayarıdır.  Bu özellik farklı bir birincil dil belirlemenizi sağlar. Varsayılan değer MRI29xx değerini kullanmaktır. 
                   Örnek:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Bu özelliğin kullanımı, IBM i Access for Windows ile aynıdır.  Büyütme işlemi sırasında SSL dosyalarını büyütmenizi sağlar.  SSL konfigürasyon dosyaları hedef kişisel bilgisayarda varsa, dosyalar son sertifikalar kullanılarak güncellenir.  Değerler Yes ve No değerleridir. Varsayılan değer ise Yes değeridir.
                   Örnek:  setup /vCWBUPGSSLFILES=NO

  IBM i Access for Windows Information Center konusunda listelenen ortak Windows Installer özellikleri geçerli olmaya devam eder: ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  REBOOT Windows Installer özelliğinin IBM i Access for Windows uygulamasıyla birlikte kullanılmasında bir sınırlama vardır.  Bu sınırlama bu pakete uygulanamaz.
  

6.6 Denetimci Görüntülerini CD ya da DVD'ye Yazma
----------------------------------------------

  CD ve DVD yazma yazılımlarının uzun dosya adlarını işleyişiyle ilgili sorunlar nedeniyle,
      bir denetimci görüntüsünün CD ya da DVD'ye yazılması önerilmez. IBM i Access for
      Windows ürününün bir denetimci görüntüsünü içeren bir CD ya da DVD'den kuruluş yaparken
      sorun yaşıyorsanız, görüntüyü yerel sabit diskteki bir dizine kopyalayın ve yerel kopyada
      setup.exe dosyasını çalıştırın.

-------------------------------------------------------------------
7.0 İlke Bilgileri
-------------------------------------------------------------------

  Aynı ilke dosyası, hem bu paket için hem de IBM i Access for Windows için kullanılır. Bunun anlamı, bu ilkelerden bazıları bu paket için kullanıldığında uygulanamaz. Bunun nedeni ise, IBM i Access for Windows uygulamasındaki bazı işlevlerin bu pakette yer almamasıdır.

-------------------------------------------------------------------

8.0 Komutlar
-------------------------------------------------------------------

  Bu pakette yer almayan IBM i Access for Windows komutları:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[BELGE SONU]
