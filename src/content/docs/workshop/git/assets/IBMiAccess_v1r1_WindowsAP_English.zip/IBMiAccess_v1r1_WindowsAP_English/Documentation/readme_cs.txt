==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019. Všechna práva vyhrazena. 

==============================================================================
  Tento dokument je poskytován tak, "jak je", bez jakéhokoli druhu záruky. IBM
  odmítá veškeré záruky, vyjádřené nebo odvozené, včetně záruk
  poskytnutých bez omezení, zahrnuté záruky způsobilosti
  ke zvláštnímu účelu a prodejnosti s ohledem na informace uvedené
  v tomto dokumentu. Poskytnutím tohoto dokumentu IBM
  neuděluje žádnou licenci k žádným patentům nebo autorským právům. 

===============================================================================

Dokument byl naposledy aktualizován:  04. listopadu 2019

------------------------------------------------------------------- 

OBSAH 

-------------------------------------------------------------------  

1.0 Úvod
2.0 Umístění zdrojů informací
3.0 Instalace
  3.1 Podporované operační systémy Windows
  3.2 Pokyny k instalaci
  3.3 Upgrade z produktu IBM i Access for Windows
  3.4 Spuštění instalace
  3.5 Akce požadované po instalaci ovladače tiskárny
  3.6 Pokyny k instalaci 64bitového hardwaru
  3.7 Instalační protokoly
4.0 Požadavky poskytovatele IBM.Data.DB2.iSeries .NET Provider
5.0 Microsoft XML Parser nebo Microsoft XML Core Services
6.0 Informace o rozšířené instalaci
  6.1 Informace o licencovaném produktu
  6.2 Jazykové soubory v obrazu instalace
  6.3 Funkce instalace
  6.4 Volby příkazového řádku
  6.5 Veřejné vlastnosti
  6.6 Vypálení administrativních obrazů na disk CD nebo DVD
7.0 Informace o zásadách
8.0 Nezahrnuté příkazy
  


-------------------------------------------------------------------

1.0 Úvod
-------------------------------------------------------------------
  Tento balík je částí produktu 5733XJ1 IBM i Access Client Solutions.

  Produkt IBM i Access Client Solutions se používá pro připojení k jakémukoli
  podporovanému vydání systému IBM i.

  Tento balík obsahuje funkce, které jsou k dispozici pouze na operačních
  systémech Windows. Je založen na verzi 7.1 produktu IBM i Access for Windows,
  ale neobsahuje všechny funkce.

  Balík zahrnuje tyto funkce z produktu IBM i Access for Windows:
    .NET Data Provider
    ODBC
    OLE DB
    zabezpečení SSL a správa certifikátů
    Programmer's Toolkit týkající se záhlaví, knihoven a dokumentace
    ovladač tiskárny AFP
    Požadované programy zahrnují:
      rozhraní API
      Active X
      zabezpečení
      provozuschopnost
      připojení
      povolení NLS
      konverzní tabulky
      vlastnosti
      zásady
      síťový tisk
      podmnožina příkazů (viz část 8.0, která uvádí seznam nezahrnutých položek)
      uživatelská příručka
      použití administrace aplikací k řízení přístupu k funkcím v balíku

  Balík nezahrnuje následující funkce z produktu IBM i Access for Windows. 
  Balík produktu IBM i Access Client Solutions, který je nezávislý na platformě,
  zahrnuje náhrady těchto funkcí:
    emulace tiskárny a obrazovky 5250
    doplněk do programu Excel pro přenos dat
    přenos dat
    Operations Console
  
  Balík nezahrnuje následující funkce z produktu IBM i Access for Windows. 
  Produkt IBM Navigator for i zahrnuje náhradu těchto funkcí:
    System i Navigator
    prohlížeč pracovní plochy AFP

  Není zahrnutý příchozí vzdálený příkaz. Náhradou je použití služeb vzdálené
  plochy společnosti Microsoft.

  Produkt Toolbox for Java rovněž není zahrnutý. Ke stažení informací použijte
  tento webový server:
   
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Balík nezahrnuje tyto další funkce z produktu IBM i Access for Windows:
    ovladač tiskárny SCS
    moduly plug-in Java Programmer's Tools for System i Navigator
    aktualizace adresáře
    podpora formátu souborů Lotus 123
    kontrola úrovně služeb

  Jelikož se obsah tohoto balíku posílá rovněž s verzí 7.1 produktu IBM i Access for Windows,
  dokumentace a správa verzí často odráží verzi 7.1 produktu IBM i Access for Windows
  v uživatelské příručce, sadě nástrojů pro programátory, textu nápovědy a zprávách, ale je
  rovněž použitelná pro produkt IBM i Access Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Umístění zdrojů informací

-------------------------------------------------------------------

  - Změny v produktu IBM i Access Client Solutions včetně podporovaných operačních systémů,
    aktualizací, omezení, významných známých problémů, nových informací a mnoha dalších
    budou publikovány na webu produktu IBM i Access:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - Uživatelská příručka, která se nainstaluje s tímto balíkem, obsahuje
    informace o použití produktu, některé rady a techniky, zprávy a informace
    o odstraňování problémů.

  - Technické odkazy na poskytovatele DB OLE a .NET Data Provider se nainstalují
    při instalace funkce Záhlaví, knihovny a dokumentace. Technické odkazy
    naleznete ve složce Programmer's Toolkit.

  - Informační centrum systému IBM i poskytuje kolekci témat navržených pro profesionály
    používající systém IBM i, kteří potřebují přístup k technickým informacím:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - V době publikování těchto informací nezahrnovalo Informační centrum systému IBM i témata
    týkající se produktu IBM i Access Client Solutions. Avšak řada informací uvedených
    pro produkt IBM i Access for Windows je použitelná i pro tento balík produktu IBM i Access
    Client Solutions včetně témat instalace, administrace a programování:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - Fórum IBM i developerWorks obsahuje články, výukové programy a technické prostředky
    pro uživatele systému IBM i:

    https://www.ibm.com/developerworks/ibmi

  - Webový server systému IBM i nabízí nejčerstvější novinky týkající se systému IBM i a informace
    o produktu, výukové orientační plány a další:

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Informace o instalaci
-------------------------------------------------------------------



3.1 Podporované operační systémy Windows
----------------------------------------

  Balík lze instalovat na tyto operační systémy Microsoft Windows:

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
     
   - Windows Server 2008 a Windows Server 2008 R2
         Standard Enterprise (32bitový a 64bitový)
   - Windows 7
         Professional, Enterprise a Ultimate (32bitový a 64bitový)

   Platí tato omezení:
 
     a) Vydání Home Edition nejsou podporovaná.
     b) Musíte použít úrovně servisních balíků Windows, které podporuje společnost Microsoft.
     c) Podpora skončí dnem, kdy ji zruší společnost Microsoft.
     d) Instalace není podporovaná na hardwaru Itanium.
     e) Použijte doporučení týkající se hardwaru a paměti systémů Microsoft Windows. Přidejte
        dalších 256 MB paměti pro funkce produktu IBM i Access Client Solution.
     f) Produkt nelze instalovat během upgradu na jiný operační systém
        Windows. Postupujte takto:
          1.  Uložte konfigurační data.
          2.  Odinstalujte produkt.
          3.  Proveďte upgrade operačního systému Windows.
          4.  Instalujte produkt.
          5.  Obnovte konfigurační data.


3.2 Pokyny k instalaci
--------------------------------------------------

  - Pro spuštění instalace je mít nutné oprávnění administrátora.
  
  - Jsou podporované pouze instalace na počítač. Instalace na uživatele
    nejsou podporované.

  - Požaduje se Instalační služba systému Windows verze 4.5. Tato softwarová komponenta
    společnosti Microsoft se instaluje během instalace, pokud se již na systému
    nenachází. Můžete ji nainstalovat předem stažením z webového serveru
    společnosti Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Upgrade z produktu IBM i Access for Windows
-------------------------------------------

  -  Upgrade z produktu IBM i Access for Windows není podporovaný. Před instalací
     tohoto balíku musíte odebrat produkt IBM i Access for Windows.  

  -  V sekci 1.0 naleznete seznam funkcí, které nejsou zahrnuté. Chcete-li
     nadále používat funkce produktu IBM i Access for Windows, které nejsou
     součástí tohoto balíku, neinstalujte jej a pokračujte v používání
     nejnovějšího servisního balíku produktu 7.1 IBM i Access for Windows.

  -  Když se produkt IBM i Access for Windows odinstaluje, existující konfigurace
     systému se odstraní. Chcete-li zachovat existující konfiguraci
     systému, musíte ji uložit před spuštěním odinstalace produktu
     IBM i Access for Windows a pak obnovit po instalaci balíku IBM i
     Access Client Solutions Windows Application Package.

     Podrobný postup, jak uložit a obnovit konfiguraci:
     1.  Příkazem CWBBACK proveďte zálohu konfigurace produktu IBM i Access
         for Windows.
             cwbback <název_souboru.rs> /u
         například:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         Tento příklad předpokládá, že složka C:\Users\IBM_ADMIN\Backup již existuje.

         Výše uvedený příkaz vytvoří ve složce 2 soubory:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 Ujistěte se, že se tyto 2 soubory vytvořily, než přejdete na další krok.

         POZN.:
         Pokud se výše uvedené 2 soubory nevytvořily, konfigurace se
         neuložila.  Zkuste příkaz spustit jako vyšší administrátor.
         Jedním ze způsobů, jak to provést, je spustit příkazový řádek takto:
             Start -> Všechny programy -> Příslušenství -> Příkazový řádek
         Místo abyste na příkazovém řádku klepli levým tlačítkem, použijte pravé
         tlačítko a vyberte volbu "Spustit jako administrátor".
         Spusťte pomocí tohoto příkazového řádku výše uvedený příkaz cwbback.
         Ujistěte se, že se výše uvedené 2 soubory vytvořily, než přejdete na další krok.

     2.  Odinstalujte produkt IBM i Access for Windows.
     3.  Znovu spusťte systém.
     4.  Nainstalujte balík IBM i Access Client Solutions Windows Application Package.
     5.  Znovu spusťte systém.
     6.  Použijte příkaz CWBREST, abyste obnovili konfiguraci
         uloženou příkazem CWBBACK.
             cwbrest <název_souboru.rs> /c
         například:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Pokud jste museli postupovat podle pokynů v POZN. v kroku 1, budete muset
         spustit příkaz cwbrest z příkazového řádku vyššího administrátora.

  -  Existuje několik způsobů, jak ověřit konfiguraci Windows před a po provedení
     výše uvedených kroků:
     1. Zkontrolujte registr Windows. Konfigurace systému jsou uložené v cestě:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Chcete-li zobrazit obsah registru Windows v tomto umístění, zadejte příkaz:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"
        
        Jestliže se vaše prostředí jmenuje jinak než výchozí
        "Moje připojení", proveďte ve výše uvedené cestě odpovídající substituci.

     2. Je-li verze produktu IBM i Access Client Solutions na vašem PC nezávislá
        na platformě, můžete v hlavním panelu grafického rozhraní vybrat:
            Soubor -> Kopírovat připojení
        Na pravé straně se zobrazí "IBM i Access (Windows)". Jedná se o konfiguraci použitou
        pro produkt IBM i Access for Windows i IBM i Access Client Solutions Windows Application
        Package.


3.4 Spuštění instalace
----------------------

  - Spusťte setup.exe v obrazu instalace, abyste spustili instalaci.  (Příkaz
    cwblaunch.exe se s tímto produktem nedodává.)
   
      POZN.: Přímé vyvolání souborů instalačního programu Microsoft Installer (MSI)
             se nedoporučuje, protože příkaz setup.exe používá soubor setup.ini
             k získání seznamu voleb příkazového řádku, které se mají použít, a
             k aktualizaci verze Instalační služby systému Windows, je-li potřeba.
    
  - Doporučuje se použít výchozí cílovou složku.  Avšak pokud
    změníte složku:
     
     a) Nevybírejte kořenový adresář jednotky.
     b) Nevybírejte adresář, který již obsahuje soubory, které
        se nevztahují k tomuto produktu.
     c) Nevybírejte síťovou jednotku. Instalace na síťový disk
	       není podporovaná.


3.5 Akce požadované po instalaci ovladače tiskárny
---------------------------------------------------

  Pokud instalujete ovladač tiskárny APF, musíte před jeho použitím provést
  akci. Je to potřebné, protože ovladač tiskárny se nemůže být během instalace
  automaticky přidat nebo aktualizovat, jelikož není digitálně podepsaný společností Microsoft.  

  Během instalace se soubory ovladače tiskárny kopírují do podadresáře s názvem
  CWBAFP pod zvolenou cílovou cestou. Za předpokladu, že instalujete do výchozí
  cílové cesty, by cesta byla:

  c:\Program Files\IBM\Client Access\adresář_CWBAFP 

  Použijte návody v textu nápovědy společnosti Microsoft, chcete-li přidat nebo aktualizovat ovladač tiskárny.
  Při výzvě uveďte cestu do adresáře CWBAFP. 

  Pokud provádíte instalaci na počítači, na kterém byl proveden upgrade
  produktu IBM i Access for Windows přes více vydání, mohou se při konfiguraci
  ovladačů tiskáren zobrazovat zastaralé informace. Odstranění
  zastaralých údajů ze souborů .inf proveďte po skončení instalace takto:

    a) Otevřete okno příkazového řádku.
    b) Přejděte do adresáře instalace. Výchozí adresář instalace je
           c:\Program Files\IBM\Client Access.
    c) Zadejte "cwbrminf" a stiskněte klávesu Enter. 


3.6 Pokyny k instalaci 64bitového hardwaru
------------------------------------------

  Při instalaci na podporovaný 64bitový operační systém Windows:
  
  -  Instaluje se 32bitová i 64bitová verze komponent ODBC, OLE DB,
     ActiveX a zabezpečení SSL (Secure Sockets Layer).  

  -  Poskytovatel produkt IBM i Access for Windows .NET se spouští ze 32bitových i
     64bitových aplikací v závislosti na tom, jakého poskytovatele aplikace volá.

  -  Instaluje se pouze jedna verze ovladače tiskárny AFP. 64bitová verze se instaluje
     na 64bitové systémy a 32bitová verze se instaluje na 32bitové systémy.


3.7 Protokoly instalace
-----------------------

  Během instalace se vytvoří 2 protokoly. Jeden z protokolů je specifický pro produkt XJ1
  a obsahuje informace o vlastních akcích produktu. Tento protokol se jmenuje "xe1instlog.txt"
  a vždy se vytvoří v adresáři temp uživatele.

  Druhý protokol je protokol Microsoft MSI, který obsahuje informace o událostech,
  posloupnostech a vlastnostech MSI. Standardně se tento protokol jmenuje
  "xe1instlogmsi.txt" a je vytvořen v adresáři temp uživatele. Protokol
  můžete změnit úpravou souboru setup.ini v instalačním obrazu. Přejděte
  na klíčové slovo [Startup], vyhledejte a upravte tento záznam: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - chcete-li zabránit vytvoření protokolu, odeberte položku
    - chcete-li změnit umístění a název protokolu, změňte cestu a název souboru
    - chcete-li změnit obsah protokolu, změňte /l* na jinou volbu(y), což popisuje
      článek Microsoft's MSDN Windows Installer Command Line Options na adrese 

      http://msdn.microsoft.com/default.aspx   

  Výchozí informace příkazového řádku v souboru setup.ini lze přepsat spuštěním souboru
  setup.exe z příkazového řádku s volbami.



-------------------------------------------------------------------

4.0 Požadavky poskytovatele IBM.Data.DB2.iSeries .NET Provider 

-------------------------------------------------------------------

  - Poskytovatel .NET produktu IBM i Access for Windows (IBM.Data.DB2.iSeries)
    vyžaduje instalaci rozhraní Microsoft .NET Framework verze 2.0 nebo
    vyšší. Většina počítačů, na kterých běží podporované operační systémy
    Microsoft, již má požadovaný rozhraní .NET Framework instalované. Rozhraní
   .NET Framework lze stáhnout z webových stránek Microsoft: 

    http://www.microsoft.com/net 

  - Chcete-li se vyvarovat přerušení aplikací .NET, které byly napsány pro
    rozhraní poskytovatele .NET produktu Access for Windows 5.3 nebo 5.4, musí
    být běhové požadavky pro verzi 10.0.0.0 poskytovatele .NET přesměrovány na verzi
    12.0.0.0. Více pokynů k použití souborů app.config, web.config nebo machine.config
    a informací o výběru vhodného kompilátoru pro přesměrování existujících
    aplikací najdete v příručce IBM DB2 for i .NET Provider Technical Reference
    v tématu "Nekompatibilní změny z verze 5.3 a 5.4".

    Jinak je také možné překompilovat aplikaci novějším kompilátorem do cílové
    verze 12.0.0.0 poskytovatele .NET, který je součástí verze 7.1 produktu
    IBM i Access for Windows.

  - Chcete-li získat úplný seznam nekompatibilních změn, nainstalujte funkci
    Záhlaví, knihovny a dokumentace a pak zobrazte příručku .NET Provider Technical
    Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser nebo Microsoft XML Core Services

-------------------------------------------------------------------

  Když používáte objekty automatizace ActiveX přenosu dat produktu IBM i Access for Windows
  k přenosu souborů do a z formátu Microsoft Excel XML (podporované aplikací Excel 2003
  a Excel XP), musíte na svůj počítač instalovat další software. Tato funkce vyžaduje,
  aby byl na počítači nainstalován produkt firmy Microsoft XML Parser verze 3.0 a výše,
  který je znám pod názvem Microsoft XML Core Services. Produkt XML Parser je součástí
  mnoha produktů společnosti Microsoft. Prohlédněte si článek Microsoft KB 278674,
  abyste zjistili, zda je nainstalována podpora produktu XML Parser. Tento článek naleznete
  na webu společnosti Microsoft:

  http://support.microsoft.com/kb/278674

  Pokud produktu Microsoft XML Parser 3.0 nebo vyšší nenaleznete, musíte se před
  použitím podpory produktu Data Transfer XML připojit k webu společnosti
  Microsoft, abyste získali pokyny ke stažení a instalování produktu
  XML Parser. Prohlédněte si článek Microsoft KB 324460
  s informacemi o instalování produktu XML Parser. Tento článek naleznete na adrese:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Informace o rozšířené instalaci

-------------------------------------------------------------------

  Většinu informací můžete použít při úpravě úrovně uživatelského rozhraní, použití
  parametrů příkazového řádku, ovládání dalšího chování instalace a implementaci
  metod v tématu "Nastavení PC" v Informačním centru systému IBM i pro produkt
  IBM i Access for Windows. Odlišnosti popisuje tato sekce.


6.1 Informace o licencovaném produktu
-------------------------------------
  
  Produkt 5733XJ1 není zabalený jako licencovaný produkt, který lze instalovat
  na operační systém IBM i.
  Je k dispozici pouze jako médium PC. Můžete jej kopírovat
  do systému IBM i na místo, které je dostupné uživatelům, je-li třeba.
  

6.2 Jazykové soubory v obrazu instalace
---------------------------------------
  
  Jazykové instalační soubory již nejsou rozdělené do různých adresářů MRI29xx v obrazu
  instalace. Místo toho jsou k dispozici oddělené soubory cab pro každý jazyk. Soubory
  cab nemůžete z obrazu odebrat.


6.3 Funkce instalace
--------------------

  Některé funkce instalace v produktu IBM i Access for Windows závisí na jiných funkcích
  instalace, které se mají instalovat. Toto omezení neplatí pro tento balík.

  Následující funkce instalace se požadují k instalaci:
    req (požadované programy)
    langacs, amri2924 (angličtina)

  Všechny ostatní funkce instalace se instalují standardně, ale nastavení můžete změnit.

  Jazyky nyní představují funkce instalace, stejně jako Požadované programy, ODBC atd.
  Protože jsou jazyky funkce instalace, můžete řídit, které jazyky se instalují stejnými
  metodami použitými k řízení jakékoli funkce instalace. Názvy funkcí instalace pro jazyky
  jsou amri29xx. 


6.4 Volby příkazového řádku
---------------------------

  Výchozí volby příkazového řádku jsou uvedené v souboru setup.ini, který je součástí
  obrazu instalace. Tyto volby se ignorují, když vyvoláte příkaz setup.exe z příkazového
  řádku s jakýmikoli uvedenými volbami.  

  Pokud používáte transformaci na příkazovém řádku, hodnoty příkazového řádku v souboru setup.ini
  se budou ignorovat, protože transformace je volba. Na příkazovém řádku budete muset zahrnout
  další volby, jako jsou informace o protokolování.

  Další informace uvádí sekce 3.7 Protokoly instalace.


6.5 Veřejné vlastnosti
----------------------

  Některé veřejné vlastnosti produktu IBM i Access for Windows jsou použitelné pro tento
  balík. Použití se částečně liší od použití v produktu IBM i Access for Windows,
  jak je popsáno dále:

  CWBINSTALLTYPE   Tato vlastnost se použije pouze při první instalaci. Jediné hodnoty jsou
                   Typická a Vlastní. Výchozí je Typická.
                   Příklad:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   Výchozí primární jazyk je národní prostředí PC. Tato vlastnost umožňuje
                   uvést jiný primární jazyk. Použitá hodnota je MRI29xx. 
                   Příklad:  setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   Použití této vlastnosti je stejné, jako v produktu IBM i Access for
                   Windows. Umožňuje provést upgrade souborů SSL během upgradu. Pokud se na cílovém PC
                   najdou konfigurační soubory pro SSL, soubory se aktualizují nejnovějšími
                   certifikáty. Hodnoty jsou Yes a No. Výchozí je Yes.
                   Příklad:  setup /vCWBUPGSSLFILES=NO

  Obecné vlastnosti Instalační služby systému Windows vypsané v tématech Informačního centra
  produktu IBM i Access for Windows zůstávají použitelné:  ADDLOCAL, REMOVE, INSTALLDIR, TARGETDIR.  

  Pro použití vlastnosti REBOOT Instalační služby systému Windows s produktem IBM i Access
  for Windows platí omezení. Toto omezení neplatí pro tento balík.
  

6.6 Vypálení administrativních obrazů na disk CD nebo DVD
---------------------------------------------------------

  Vzhledem k problémům, které má některý vypalovací software s dlouhými názvy souborů
      při vypalování disků CD a DVD se nedoporučuje vypalovat administrativní obraz
      na disky CD a DVD. Pokud máte problém při instalaci z disku CD nebo DVD
      s administrativním obrazem produktu IBM i Access for Windows, zkopírujte obraz
      do adresáře na místní pevný disk a příkaz setup.exe spusťte z místní kopie.

-------------------------------------------------------------------
7.0 Informace o zásadách
-------------------------------------------------------------------

  Stejný soubor zásad se používá pro tento balík i produkt IBM i Access for
  Windows. To znamená, že některé z těchto zásad nejsou použitelné, když se použijí
  pro tento balík, poněvadž některá funkce produktu IBM i Access for Windows
  neexistuje v tomto balíku.

-------------------------------------------------------------------

8.0 Příkazy
-------------------------------------------------------------------

  Příkazy produktu IBM i Access for Windows, které nejsou součástí tohoto balíku:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe
    
[KONEC DOKUMENTU]
