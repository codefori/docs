==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  All rights reserved. 


==============================================================================
  本文件不提供任何形式的保證。IBM 不為明示或默示地任何保證（包含但不限於
  本文件內未侵害他人權利、可售性及符合特定效用等保證的資訊）。
  提供本文件，不表示 IBM 對任何專利或版權提供任何授權。


===============================================================================

此文件的前次更新日期：2019 年 11 月 04 日

------------------------------------------------------------------- 

目錄

-------------------------------------------------------------------  

1.0 簡介
2.0 資訊來源位置
3.0 安裝
  3.1 支援的 Windows 作業系統
  3.2 安裝注意事項
  3.3 從 IBM i Access for Windows 升級
  3.4 執行安裝
  3.5 安裝印表機驅動程式後的必要動作
  3.6 64 位元硬體安裝注意事項
  3.7 安裝日誌
4.0 IBM.Data.DB2.iSeries .NET Provider 基本要求
5.0 Microsoft XML Parser 或 Microsoft XML Core Services
6.0 進階安裝資訊
  6.1 授權產品資訊
  6.2 安裝映像檔中的語言檔
  6.3 安裝特性
  6.4 指令行選項
  6.5 公開內容
  6.6 將管理映像檔燒錄至 CD 或 DVD
7.0 原則資訊
8.0 未併入的指令
  


-------------------------------------------------------------------

1.0 簡介
-------------------------------------------------------------------
  此套件是 5733XJ1 IBM i Access Client Solutions 產品的一部分。

  您可以使用 IBM i Access Client Solutions 來連接至任何支援的 IBM i 版本。

  此套件所含的功能，只適用於 Windows 作業系統。它是以 7.1 IBM i Access
  for Windows 產品為基礎，但不包含所有特性。

  此套件所包括的 IBM i Access for Windows 特性如下：
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer 及憑證管理
    用於標頭、檔案庫及文件的程式設計師工具程式
    AFP 印表機驅動程式
    必要程式，包括：
      API
      作用中 X
      安全
      服務功能
      連線
      NLS 啟用
      轉換表
      內容
      原則
      網路列印
      指令子集（如需未併入的指令清單，請參閱第 8.0 節。）
      使用手冊
      使用「應用程式管理」以控制對套件中功能的存取

  此套件不包括 IBM i Access for Windows 的下列特性。
  此獨立式平台 IBM i Access Client Solution 套件包含這些特性的取代項目：
    5250 顯示器與印表機模擬
    資料傳送
    資料傳送 Excel 增益集
    作業主控台

  此套件不包括 IBM i Access for Windows 的下列特性。
  IBM Navigator for i 包括下列特性的替代特性：
    System i 領航員
    AFP 工作台檢視器

  不包括「進入的遠端指令」。替代方案是使用 Microsoft 的「遠端桌面服務」。

  也不包括 Toolbox for Java。請使用下列網站來取得下載資訊：

  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  不包括在此套件中的其他 IBM i Access for Windows 特性如下：
    SCS 印表機驅動程式
    「System i 領航員」外掛程式的 Java 程式設計師工具
    目錄更新
    Lotus 123 檔案格式支援
    檢查服務層次

  因為此套件的內容也隨附 7.1 IBM i Access for Windows，所以文件與版本
  通常會在「使用手冊」、「程式設計師工具程式」、說明文字及訊息中反
  映 7.1 IBM i Access for Windows，但也適用於 IBM i Access Client
  Solutions - Windows Application Package。


-------------------------------------------------------------------

2.0 資訊來源位置

-------------------------------------------------------------------

  - IBM i Access Client Solutions 的變更（包括支援的作業系統、更新、限制、
    重要的已知問題、新資訊及其他）將會發佈在 IBM i Access 產品網站上：

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - 與此套件一起安裝的「使用手冊」，包含使用產品的相關資訊、
    一些要訣與技術、訊息，以及疑難排解資訊。 

  - 安裝「標頭、檔案庫及文件」特性時，即會安裝 OLE DB 提供者及 .NET Data Provider 的
    技術參考手冊。您可以在 Programmer's Toolkit 資料夾中找到技術參考手冊。

  - IBM i Information Center 提供主題集合，其是針對需要存取技術資訊的 IBM i 專家所設計：

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - 本書出版時，「IBM i 資訊中心」並未包括 IBM i Access Client Solutions 的相關主題。
    但 IBM i Access for Windows 下的眾多資訊均適用於 IBM i Access Client Solutions
    的此套件，包括安裝、管理及程式設計主題：

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks 包含 IBM i 使用者適用的文章、指導教學及技術資源：

    https://www.ibm.com/developerworks/ibmi

  - IBM i 網站提供最新的 IBM i 消息，以及產品資訊、參考文獻書庫、教育訓練圖等等：

    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 安裝資訊
-------------------------------------------------------------------



3.1 支援的 Windows 作業系統
---------------------------------------

  此套件可以安裝在下列 Microsoft Windows 作業系統上：

   

   - Windows Server 2019 Standard、Windows Server 2019 Datacenter

   - Windows Server 2016 Standard、Windows Server 2016 Datacenter

   - Windows 10 Pro、Windows 10 Enterprise

   - Windows 8.1 Pro、Windows 8.1 Enterprise、Windows Server 2012 R2- Windows Server 2008 及 Windows Server 2008 R2
         Standard Enterprise（32 位元及 64 位元）
   - Windows 7
         Professional、Enterprise 及 Ultimate（32 位元及 64 位元）

   下列限制適用：

     a) 不支援家用版。
     b) 您必須使用 Microsoft 支援的 Windows 服務套件層次。
     c) 在 Microsoft 捨棄支援時，支援將中斷。
     d) 不支援在 Itanium 硬體上安裝。
     e) 使用 Microsoft Windows 硬體及記憶體建議。
        另外包括 256 MB 的記憶體，供 IBM i Access Client Solution 功能使用。
     f) 升級至不同的 Windows 作業系統時，不能安裝產品。請遵循下列步驟：
          1.  儲存配置資料。
          2.  解除安裝產品。
          3.  升級 Windows 作業系統。
          4.  安裝產品。
          5.  還原配置資料。


3.2 安裝注意事項
--------------------------------------------------

  - 執行安裝需要具備管理權限及專用權。

  - 只支援依機器安裝。不支援依使用者安裝。

  - 需要 Windows Installer 4.5。
    如果系統上沒有這個 Microsoft 軟體元件，則會在安裝期間加以安裝。
    從 Microsoft 網站下載此元件，即可在安裝之前加以安裝：

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 從 IBM i Access for Windows 升級
-------------------------------------------

  -  不支援從 IBM i Access for Windows 進行升級。您必須移除
     IBM i Access for Windows，然後才能安裝此套件。

  -  請參閱第 1.0 節，以取得未併入的特性清單。如果您想要繼續
     使用 IBM i Access for Windows 中未併入於此套件的特性，
     請不要安裝此套件，並繼續使用 IBM i Access for Windows 7.1
     的最新服務修正程式包。

  -  解除安裝 IBM i Access for Windows 時，將刪除現有系統配置。
     若要保留現有系統配置，您將需要先儲存配置，
     然後再解除安裝 IBM i Access for Windows，
     並在安裝 IBM i Access Client Solutions Windows Application Package 之後
     還原配置。

     以下是儲存及還原配置的詳細步驟：
     1.  使用 CWBBACK 指令來備份 IBM i Access for Windows 配置。
             cwbback <filename.rs> /u
         例如：
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         此範例假設資料夾 C:\Users\IBM_ADMIN\Backup 已存在。

         上述指令將在該資料夾中建立兩個檔案：
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
	 在移至下一步之前，確定已建立這兩個檔案。

         附註：
         如果尚未建立上述兩個檔案，則您沒有已儲存的配置。
         請嘗試以提升的管理者身分執行指令。
         作法為依照下列方式啟動命令提示字元：
             開始->所有程式->附屬應用程式->命令提示字元
         不是在「命令提示字元」上按一下滑鼠左鍵，而是按一下滑鼠右鍵
         選取「以系統管理員身分執行」選項。
         使用此命令提示字元執行上述 cwbback 指令。
         在移至下一步之前，確定已建立上述兩個檔案。

               2.  解除安裝 IBM i Access for Windows。
               3.  重新開機。
               4.  安裝 IBM i Access Client Solutions Windows Application Package。
               5.  重新開機。
     6.  使用 CWBREST 指令，來還原已利用 CWBBACK 指令儲存的配置。
             cwbrest <filename.rs> /c
         例如：
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         如果您需要遵循步驟 1 中「附註」內的指示，也將需要從提升的管理者命令提示字元
         執行 cwbrest 指令。

  -  有數種方式，您可以用來在上述步驟前後驗證 Windows 配置：
     1. 檢查 Windows 登錄。系統配置儲存在下列位置：
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	若要在該位置檢視 Windows 登錄的內容，請輸入此指令：
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"

        如果您具有名稱不是預設 "My Connections" 的環境，請在上述路徑中換成
        適當的名稱。

     2. 如果您在同一 PC 上具有 IBM i Access Client Solutions 的獨立式平台版本，
        則可以選取：
            檔案->複製連線
        右側將顯示 "IBM i Access (Windows)"。此配置同時用於 IBM i Access
        for Windows 及 IBM i Access Client Solutions Windows Application
        Package。


3.4 執行安裝
-----------------------

  - 執行安裝映像檔中的 setup.exe 來啟動安裝。
    （本產品未提供指令 cwblaunch.exe。）      附註：不建議直接呼叫 Microsoft Installer (MSI) 檔案，
            因為 setup.exe 會將 setup.ini 用於要使用的指令行選項清單，
            並視需要更新 Windows Installer 版本。

  - 建議您使用預設的目的地資料夾。但如果您變更資料夾：

     a) 請勿選取磁碟機的根目錄。
     b) 請勿選取所含檔案與本產品無關的目錄。
     c) 請勿選取網路磁碟機。不支援安裝到網路磁碟機。




3.5 安裝印表機驅動程式後的必要動作
---------------------------------------------------

  如果安裝 APF 印表機驅動程式，則必須在使用印表機驅動程式之前採取動作。
  這是必要動作，是因為 Microsoft 未數位簽署印表機驅動程式，
  而導致無法在安裝期間自動新增或更新該印表機驅動程式。

  在安裝期間，印表機驅動程式檔案會複製到所選擇目的地路徑下的子目
  錄（名為 CWBAFP）中。假設您已安裝到預設的目的地路徑，則路徑會是：

  c:\Program Files\IBM\Client Access\CWBAFP 目錄

  使用其說明文字中的 Microsoft 目錄，以新增或更新印表機驅動程式。
  出現提示時，請指定 CWBAFP 的路徑。

  如果您是在已跨多個版次升級 IBM i Access for Windows 產品的 PC 上安裝，
  則在配置印表機驅動程式時，可能會顯示一些舊資訊。 
  若要移除 .inf 檔案的已作廢資訊，請在完成安裝之後執行下列動作： 

    a) 開啟命令提示字元視窗。
    b) 將目錄變更為安裝目錄。預設
        安裝目錄為 c:\Program Files\IBM\Client Access。
    c) 鍵入 cwbrminf，然後按 Enter 鍵。


3.6 64 位元硬體安裝注意事項
-----------------------------------------------

  在支援的 64 位元 Windows 作業系統上安裝時：

  -  會安裝 ODBC、OLE DB、ActiveX 及 Secure Sockets Layer (SSL) 的 32 位元版本
     及 64 位元版本。

  -  IBM i Access for Windows .NET Provider 會從 32 位元及 64 位元應用程式執行，
     視呼叫提供者的應用程式而定。

  -  只會安裝一個版本的「AFP 印表機驅動程式」。
     64 位元版本會安裝在 64 位元系統上，而 32 位元版本會安裝在 32 位元系統上。


3.7 安裝日誌
---------------------

  安裝期間，會建立兩個日誌。其中一個是 XJ1 的專用日誌，包含產品的自訂動
  作資訊。此日誌名為 "xe1instlog.txt"，且一律在使用者的暫存目錄中建立。

  另一個日誌是 Microsoft MSI 日誌，其中包含 MSI 事件、順序及內容
  的相關資訊。根據預設值，
  此日誌名為 xe1instlogmsi.txt，且在使用者的暫存目錄中建立。您可以藉由編輯安裝映像檔中的 setup.ini 來變更
  此日誌。請移至 [Startup] 關鍵字，尋找並編輯此項目：

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - 若要防止建立日誌，請移除項目
    - 若要變更日誌的位置及名稱，請變更路徑及檔名
    - 若要變更日誌的內容，請將 /l* 變更為不同選項，
      如 Microsoft 的「MSDN Windows Installer 指令行選項」
      所述，其位置為

      http://msdn.microsoft.com/default.aspx   

  在命令提示字元中使用指令行選項啟動 setup.exe，
  可以置換 setup.ini 中的預設指令行資訊。



-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET Provider 基本要求

-------------------------------------------------------------------

  - IBM i Access for Windows .NET Provider (IBM.Data.DB2.iSeries)
    需要在系統上安裝 Microsoft .NET Framework 2.0 版或更新版本。
    執行支援的 Microsoft 作業系統的大部分 PC，都已安裝必要的
    .NET Framework。您可以從下列 Microsoft 網站下載 .NET Framework：

    http://www.microsoft.com/net 

  - 若要避免岔斷寫入 Access for Windows 5.3 或 5.4 .NET Provider 介
    面的 .NET 應用程式，必須將 .NET Provider 10.0.0.0 版的執行時間
    要求重新導向到 12.0.0.0 版。如需使用 app.config 檔案、
    web.config 檔案或 machine.config 檔案的相關指示，以及選取
    適當編譯器以重新導向現有應用程式的相關資訊，請參閱
    「IBM DB2 for i .NET Provider 技術參考手冊」中的
    「與 5.3 及 5.4 不相容的變更」主題。


    另外，也可以使用較新的編譯器，以 IBM i Access for Windows 7.1
    版次所含的 12.0.0.0 版 .NET Provider 作為目標，重新編譯應用程式。
    

  - 如需不相容變更的完整資訊及清單，請安裝「標頭、檔案庫及文件」特性，
    然後顯示「.NET Provider 技術參考手冊」。 

-------------------------------------------------------------------

5.0 Microsoft XML Parser 或 Microsoft XML Core Services

-------------------------------------------------------------------

  使用 IBM i Access for Windows Data Transfer ActiveX 自動化物件，
  傳入及傳出 Microsoft Excel XML 格式（受 Excel 2003 及 Excel XP 支援）的
  檔案時，必須在您的 PC 上安裝其他軟體。此特性需要在您個人電腦上安裝
  Microsoft XML Parser 3.0 或以上版本（也稱為 Microsoft XML Core Services）。
  許多 Microsoft 產品均隨附「XML 剖析器」。
  若要判定您 PC 是否已安裝「XML 剖析器」支援，請參閱
  Microsoft KB 文章 278674。此文章位於 Microsoft 網站，網址為：

  http://support.microsoft.com/kb/278674

  如果找不到 Microsoft XML Parser 3.0 或更新版本，您必須先存取
  Microsoft 網站，以取得下載及安裝「XML 剖析器」的相關指示，
  然後才能使用「資料傳送 XML」支援。如需安裝「XML 剖析器」的相
  關資訊，請參閱 Microsoft KB 文章 324460。此文章位於：

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 進階安裝資訊

-------------------------------------------------------------------

  您可以使用「IBM i 資訊中心」中 IBM i Access for Windows 的「設定 PC」主題中，
  有關修改使用者介面層次、使用指令行參數、控制其他安裝行為與部署方法的大部分
  資訊。本節說明差異之處。


6.1 授權產品資訊
----------------------------------

  5733XJ1 未包裝為要安裝在 IBM i 作業系統上的「授權產品」。
  只能以 PC 媒體取得它。如果您想要，可以將它複製到 IBM i 中
  您的使用者可用的位置。
  

6.2 安裝映像檔中的語言檔
--------------------------------------------

  在安裝映像檔中，語言安裝檔不再分隔至不同的 MRI29xx 目錄。
  而是每個語言有不同的 cab 檔。您不能從映像檔中移除這些 cab 檔。


6.3 安裝特性
--------------------

  IBM i Access for Windows 中的部分安裝特性，取決於其他要安裝的
  安裝特性。此限制不適用於此套件。

  下列為必須安裝的安裝特性：
    req（必要程式）
    langacs、amri2924（英文）

  所有其他安裝特性均預設為安裝，但您可以變更設定。

  語言現在是安裝特性，就像「必要程式」、ODBC 等一樣。因為語言是安裝特性，
  所以您可以使用用來控制任何安裝特性的相同方法，來控制所安裝的語言。
  語言的安裝特性名稱是 amri29xx。


6.4 指令行選項
------------------------

  預設指令行選項是在安裝映像檔所包括的 setup.ini 檔中指定。
  如果您從指令行使用任何指定的選項來呼叫 setup.exe，
  則將忽略這些選項。

  如果您是在指令行上使用轉換，則將忽略 setup.ini 中的指令
  行值，因為轉換是一個選項。您將需要在指令行上，將其他選項
  併入如記載資訊等項目。

  如需相關資訊，請參閱第 3.7 節「安裝日誌」。


6.5 公開內容
---------------------

  部分 IBM i Access for Windows 公開內容適用於此套件。
  其用法與 IBM i Access for Windows 中的用法有些許不同，如下所述：

  CWBINSTALLTYPE   此內容僅用於第一次安裝。唯一值是 Typical 及 Custom。
                   預設值是 Typical。
                   範例：setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   預設的主要語言是您 PC 的語言環境。
                   此內容可讓您指定不同的主要語言。使用的值是 MRI29xx。
                   範例：setup /vCWBPRIMARYLANG=MRI2989

  CWBUPGSSLFILES   此內容的用法與 IBM i Access for Windows 相同。
                   它可讓您在升級期間升級 SSL 檔案。
                   如果在目標 PC 上找到 SSL 的配置檔，則將使用最新憑
                   證來更新這些檔案。值是 Yes 及 No。預設值是 Yes。
                   範例：setup /vCWBUPGSSLFILES=NO

  「IBM i Access for Windows 資訊中心」主題中列出的一般 Windows Installer 內容仍適用：
  ADDLOCAL、REMOVE、INSTALLDIR、TARGETDIR。

  使用 REBOOT Windows Installer 內容搭配 IBM i Access for Windows 時，
  有一個限制。此限制不適用於此套件。


6.6 將管理映像檔燒錄至 CD 或 DVD
----------------------------------------------

  由於部分 CD 及 DVD 燒錄軟體處理長檔名時會發生問題，
  因此不建議將管理壓縮檔燒錄至 CD 或 DVD。如果從包含
  IBM i Access for Windows 管理壓縮檔的 CD 或 DVD 安裝時
  發生問題，請將該壓縮檔複製到本端硬碟上的目錄，然後從
  本端副本執行 setup.exe。

-------------------------------------------------------------------
7.0 原則資訊
-------------------------------------------------------------------

  此套件與 IBM i Access for Windows 使用相同的原則檔。
  這表示當那些原則用於此套件時，其中的部分原則並不適用，
  因為此套件沒有 IBM i Access for Windows 的部分功能。

-------------------------------------------------------------------

8.0 指令
-------------------------------------------------------------------

  此套件不包括 IBM i Access for Windows 的下列指令：
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe


   [文件結束]
