==============================================================================

            5733XJ1 IBM i Access Client Solutions
              Windows Application Package 1.1.0
    
   (c) Copyright IBM Corporation 1996, 2019.  Alle rechten voorbehouden.
 

==============================================================================
  Dit document wordt "AS IS" verstrekt, zonder enige garantie. Met
  betrekking tot de inhoud van dit document geeft IBM geen enkele
  garantie, uitdrukkelijk noch stilzwijgend, met inbegrip van, maar
  niet beperkt tot, de stilzwijgende garanties voor verkoopbaarheid
  of geschiktheid voor een bepaald doel. Het verstrekken van dit
  document betekent niet dat IBM licentie op enig octrooi of
  auteursrecht verleent. 

===============================================================================

Dit document is voor het laatst bijgewerkt op:  4 november 2019

------------------------------------------------------------------- 

INHOUDSOPGAVE 

-------------------------------------------------------------------  

1.0 Introductie
2.0 Locatie van informatiebronnen
3.0 Installatie
  3.1 Ondersteunde Windows-besturingssystemen
  3.2 Overwegingen bij installatie
  3.3 Upgrade vanuit IBM i Access for Windows
  3.4 Uitvoeren van installatie
  3.5 Actie vereist na installeren van printerstuurprogramma
  3.6 Overwegingen bij installatie voor 64-bits hardware
  3.7 Installatielogboeken
4.0 Vereisten voor IBM.Data.DB2.iSeries .NET Provider
5.0 Microsoft XML Parser of Microsoft XML Core Services
6.0 Uitgebreide installatie-informatie
  6.1 Informatie over gelicentieerde producten
  6.2 Taalbestand in het installatie-image
  6.3 Installatiefuncties
  6.4 Opties voor de opdrachtregel
  6.5 Openbare eigenschappen
  6.6 Beheer-images naar CD of DVD branden
7.0 Informatie over beleidsdefinities
8.0 Niet-inbegrepen opdrachten
  


-------------------------------------------------------------------

1.0 Introductie
-------------------------------------------------------------------
  Dit pakket is onderdeel van het product 5733XJ1 IBM i Access Client
  Solutions.

  U kunt IBM i Access Client Solutions gebruiken voor het maken van een
  verbinding met elke ondersteunde release van IBM i.


  Dit pakket bevat functies die alleen beschikbaar zijn in
  Windows-besturingssystemen.
  Het is gebaseerd op het product 7.1 IBM i Access for Windows maar
  bevat niet alle voorzieningen ervan.


  De voorzieningen van IBM i Access for Windows in dit pakket zijn:
    .NET Data Provider
    ODBC
    OLE DB
    Secure Socket Layer en Certificaatbeheer
    Programmer's Toolkit voor headers, bibliotheken en documentatie
    AFP-printerstuurprogramma
    Vereiste programma's, waaronder:
      API's
      Active X
      Beveiliging
      Onderhoudbaarheid
      Verbindingen
      NLS-functionaliteit
      Conversietabellen
      Eigenschappen
      Beleidsdefinities
      Afdrukken via netwerk
      Subset van opdrachten (zie deel 8.0 voor een lijst van niet-opgenomen
      items.)
      Gebruikershandleiding
      Gebruik van Toepassingenbeheer voor het besturen van toegang tot
      de functies in het het pakket


  De volgende voorzieningen van IBM i Access for Windows zijn niet in dit
  pakket inbegrepen. 
  Het platform-onafhankelijke IBM i Access Client Solution-pakket bevat een
  vervanging voor deze voorzieningen:
    5250-beeldscherm- en printeremulator
      Gegevensoverdracht
      Excel-invoegtoepassing voor Gegevensoverdracht
      Operations Console

  De volgende voorzieningen van IBM i Access for Windows zijn niet in dit
  pakket inbegrepen. 
  IBM Navigator for i bevat een vervanging voor deze voorzieningen:
    System i Navigator
    AFP Workbench Viewer

  Inkomende opdracht op afstand is niet inbegrepen. U kunt in plaats hiervan
  Remote Desktop Services van Microsoft gebruiken.

  Toolbox for Java is ook niet inbegrepen. Op de volgende website kunt u
  gegevens over het downloaden ervan vinden:
  http://www-03.ibm.com/systems/i/software/toolbox/index.html

  
  Andere voorzieningen van IBM i Access for Windows die niet in dit pakket zijn
  inbegrepen, zijn:
    SCS-printerstuurprogramma
    Java Programmer's Tools for System i Navigator plug-ins
    Directory bijwerken
    Ondersteuning voor Lotus 123.bestandsindeling
    Serviceniveau controleren

  Omdat de inhoud van dit pakket ook wordt geleverd bij  7.1 IBM i Access for
  Windows, wordt in de documentatie en versiegegevens vaak 7.1 IBM i Access for
  Windows aangegeven in de Gebruikershandleiding, de Programmer's Toolkit, de
  Help-tekst en berichten. Deze zijn echter ook van toepassing op IBM i Access
  Client Solutions - Windows Application Package.


-------------------------------------------------------------------

2.0 Locatie van informatiebronnen

-------------------------------------------------------------------

  - Wijzigingen in IBM i Access Client Solutions, waaronder ondersteuning van besturingssystemen,
    updates, beperkingen, significante bekende problemen, nieuwe informatie en meer wordt
    gepubliceerd op de productwebsite van IBM i Access:

    http://www-03.ibm.com/systems/power/software/i/access/index.html

  - De Gebruikershandleiding die bij dit pakket is geïnstalleerd, bevat
    informatie over het gebruik van het product, een aantal tips en technieken,
    berichten en informatie over probleemoplossing.


  - Technische verwijzingen naar de OLE DB-provider en de .NET Data Provider
    worden geïnstalleerd tijdens de installatie van de voorziening Headers,
    bibliotheken en documentatie. U vindt de technische verwijzingen in de map
    van de Programmer's Toolkit.

  - Het IBM i Informatiecentrum is een verzameling onderwerpen voor IBM i-experts
    die technische informatie willen opzoeken:

    http://publib.boulder.ibm.com/eserver/ibmi.html

  - Ten tijde van deze publicatie bevatte het IBM i Informatiecentrum geen
    onderwerpen over IBM i Access Client Solutions. Veel van de
    informatie onder IBM i Access for Windows is van toepassing op
    dit pakket van IBM i Access Client Solutions, met inbegrip van onderwerpen
    over installatie, beheer en programmeren:

http://publib.boulder.ibm.com/infocenter/iseries/v7r1m0/index.jsp?topic=%2Frzahg%2Frzahgicca2.htm


  - IBM i developerWorks bevat artikelen, zelfstudieprogramma's en technische
    resources voor gebruikers van IBM i:

    https://www.ibm.com/developerworks/ibmi

  - Op de IBM i-website vindt u het laatste IBM i-nieuws, productinformatie,
    een referentiebibliotheek, educatieve onderwerpen en nog veel meer:


    http://www-03.ibm.com/systems/i/
    
-------------------------------------------------------------------

3.0 Installatie-informatie
-------------------------------------------------------------------



3.1 Ondersteunde Windows-besturingssystemen
--------------------------------------------

  Dit pakket kan worden geïnstalleerd op de volgende besturingssystemen van
  Microsoft Windows:

   

   - Windows Server 2019 Standard, Windows Server 2019 Datacenter

   - Windows Server 2016 Standard, Windows Server 2016 Datacenter

   - Windows 10 Pro, Windows 10 Enterprise

   - Windows 8.1 Pro, Windows 8.1 Enterprise, Windows Server 2012 R2
- Windows Server 2008 en Windows Server 2008 R2
         Standard Enterprise (32-bits en 64-bits)
- Windows 7
         Professional, Enterprise en Ultimate (32-bits en 64-bits)

   De volgende beperkingen zijn van toepassing:

     a) Home-edities worden niet ondersteund.
     b) U dient Windows-servicepackniveaus te gebruiken die Microsoft
        ondersteunt.
     c) Ondersteuning vervalt op het moment dat Microsoft geen ondersteuning
        meer levert.
     d) Installatie op Itanium-hardware wordt niet ondersteund.
     e) Gebruik de aanbevelingen voor hardware en geheugen van Microsoft
        Windows. Voeg hieraan 256 MB extra geheugen toe voor functies van
        IBM i Access Client Solution.
     f) Het product kan niet geïnstalleerd worden bij het upgraden naar een
        ander Windows-besturingssysteem. Volg deze stappen:
          1.  Sla de configuratiegegevens op.
     2.  Verwijder het product.
     3.  Voer de upgrade van het Windows-besturingssysteem uit
     4.  Installeer het product.
     5.  Herstel de configuratiegegevens.


3.2 Overwegingen bij installatie
--------------------------------------------------

  - Voor het uitvoeren van de installatie hebt u beheerdersmachtiging
    en -bevoegdheid nodig.
  - Alleen installatie per machine wordt ondersteund. Installatie per gebruiker
    wordt niet ondersteund.


  - Windows Installer 4.5 is vereist. Deze Microsoft-softwarecomponent
    wordt tijdens de installatie geïnstalleerd als hij not niet op het systeem
    aanwezig is. U kunt deze component installeren voordat u aan de installatie
    begint door hem te downloaden vanaf de website van Microsoft:

    http://www.microsoft.com/DownLoads/details.aspx?familyid=5A58B56F-60B6-4412-95B9-54D056D6F9F4



3.3 Upgrade vanuit IBM i Access for Windows
-------------------------------------------

  -  Het upgraden van IBM i Access for Windows wordt niet ondersteund. Verwijder eerst
   IBM i Access for Windows voordat u dit pakket installeert.  

  -  Raadpleeg Deel 1.0 voor de lijst van voorzieningen die niet inbegrepen zijn.  Als u
   functies in IBM i Access for Windows wilt blijven gebruiken die niet in dit pakket
   opgenomen zijn, installeer dit pakket dan niet en blijf het recentste
   servicepakket van 7.1 IBM i Access for Windows gebruiken.

  -  Als IBM i Access for Windows wordt verwijderd, wordt de bestaande
     systeemconfigurati gewist. Om de bestaande systeemconfiguratie te
     behouden, moet u de configuratie opslaan voordat u IBM i Access
     for Windows verwijdert en daarna de configuratie herstellen nadat
     het Windows-toepassingspakket van IBM i Access Client Solutions
     geïnstalleerd is.

     Hieronder volgen de stappen voor het opslaan en herstellen van uw configuratie:
     1.  Gebruik de opdracht CWBBACK om een backup maken van de
         configuratie van IBM i Access for Windows.
             cwbback <filename.rs> /u
         Bijvoorbeeld:
             cwbback C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /u
         In dit voorbeeld wordt er vanuit gegaan dat de map C:\Users\IBM_ADMIN\Backup al aanwezig is.

         Met deze opdracht maakt u twee bestanden in die map:
             IAWIN_CONFIG.RS
             IAWIN_CONFIG.ts
Controleer of deze twee bestanden gemaakt zijn voordat u doorgaat met de volgende stap. 

         OPMERKING:
         Als de twee bestanden niet gemaakt zijn, hebt u geen opgeslagen configuratie.
Probeer de opdracht als beheerder met extra machtigingen uit te voeren.
Een manier om dat te doen is het starten van een opdrachtprompt:
                Start->Alle Programma's->Bureau-accessoires->Opdrachtprompt
         In plaats van klikken met de linker muisknop op de Opdrachtprompt,          gebruikt u de rechter muisknop en selecteert u de optie "Uitvoeren als          beheerder".
         Voer de hierboven genoemde opdracht cwbback uit met deze opdrachtprompt.
         Controleer of de hiervoor genoemde twee bestanden gemaakt zijn voordat u doorgaat met de          volgende stap.

          2.  Verwijder IBM i Access for Windows.
     3.  Start opnieuw op.
     4.  Installeer IBM i Access Client Solutions Windows Application Package.
     5.  Start opnieuw op.
     6.  Gebruik de opdracht CWBREST om de configuratie te herstellen die met de
         opdracht CWBBACK is opgeslagen.
             cwbrest <filename.rs> /c
         Bijvoorbeeld:
             cwbrest C:\Users\IBM_ADMIN\Backup\IAWIN_CONFIG.RS /c

         Als u de instructies in de OPMERKING in stap 1 gevolgd hebt, moet u de opdracht
         cwbrest ook met uitgebreide machtigingen voor de beheerder uitvoeren.


  -  Er is een aantal manieren waarop uw Windows-configuratie kunt verifiëren voor en na
   de bovenstaande stappen:
     1. Controleer het Windows-register. De systeemconfiguraties worden opgeslagen bij:
        HKEY_CURRENT_USER\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections

	Om de inhoud van het Windows-register op die locatie te bekijken, voert u deze opdracht uit:
        reg query "HKCU\Software\IBM\Client Access Express\CurrentVersion\Environments\My Connections"

        Als u een omgeving hebt met een andere naam dan de standaardnaam
        "My Connections" past u het pad hierboven dienovereenkomstig aan. 

     2. Als u de platform-onafhankelijke versie van IBM i Access Client Solutions op dezelfde
        PC hebt, kunt u in het hoofdvenster van de GUI het volgende selecteren:
            Bestand->Verbindingen kopiëren
        Rechts ziet u "IBM i Access (Windows)". Dit is de configuratie die gebruikt wordt
        voor IBM i Access for Windows en voor IBM i Access Client Solutions Windows Application
        Package.


3.4 De installatie utivoeren
----------------------------

  - Voer setup.exe in het installatie-image uit om de installatie te starten. (De
    opdracht cwblaunch.exe wordt niet bij dit product geleverd.)
OPMERKING: Rechtstreeks aanroepen van MSI-bestanden (Microsoft Installer)
             wordt niet aanbevolen omdat setup.exe gebruik maakt van setup.ini
             voor een lijst van te gebruiken opties op de opdrachtregel en voor
             het bijwerken van de versie van Windows Installer als dat nodig is.

  - U wordt aangeraden de standaardbestemmingsmap te gebruiken.
Als u de map echter wilt wijzigen, let dan op het volgende:

     a) Selecteer geen hoofddirectory van een station.
     b) Selecteer geen directory die al bestanden bevat die gerelateerd zijn
        aan dit product.
     c) Selecteer geen netwerkstation. Installatie op een netwerkstation
        wordt niet ondersteund.



3.5 Actie vereist na installeren van een printerstuurprogramma
--------------------------------------------------------------

  Als u een printerstuurprogramma installeert moet u actie ondernemen voordat
  u het printerstuurprogramma gebruikt. De printerstuurprogramma's kunnen
  tijdens de installatie namelijk niet automatisch worden toegevoegd of
  bijgewerkt omdat ze niet digitaal zijn ondertekend door Microsoft.


  Bij de installatie worden de bestanden met printerstuurprogramma's gekopieerd
  naar een subdirectory met de naam CWBAFP onder het doelpad dat u hebt gekozen.
  Als u de installatie naar het standaard doelpad hebt uitgevoerd, is
  het pad:

  c:\Program Files\IBM\Client Access\CWBAFP 

  Voeg het printerstuurprogramma to of werk het bij aan de hand van de
  aanwijzingen van Microsoft in hun Help-tekst. Als om een pad wordt gevraagd,
  geeft u CWBAFP op. 

  Als u het stuurprogramma installeert op een PC waarop via verschillende
  releases een upgrade is aangebracht op IBM i Access for Windows, wordt
  mogelijk oude informatie afgebeeld als u het printerstuurprogramma
  configureert. Als u de verouderde informatie uit de .inf-bestanden wilt
  verwijderen, doet u het volgende nadat u de installatie hebt voltooid:
    a) Open een venster met een opdrachtaanwijzing.
    b) Wijzig de directory in uw installatiedirectory. De standaard
       installatiedirectory is c:\Program Files\IBM\Client Access.
    c) Typ "cwbrminf" en druk op Enter. 


3.6 Overwegingen bij de installatie van 64-bits hardware
--------------------------------------------------------

  Bij installatie op een ondersteund 64-bits Windows-besturingssysteem geldt
  het volgende:
  -  Zowel de 32-bits versie als de 64-bits versie worden geïnstalleerd voor
     ODBC, OLE DB, ActiveX en SSL (Secure Sockets Layer).  

  -  De IBM i Access for Windows .NET Provider kan worden uitgevoerd op 32-bits en
     64-bits toepassingen, afhankelijk van de toepassing die de Provider
     aanroept.


  -  Er wordt slechts één versie van het AFP-printerstuurprogramma
     geïnstalleerd. De 64-bits versie wordt geïnstalleerd op 64-bits systemen
     en de 32-bits versie wordt geïnstalleerd op 32-bits systemen.


3.7 Installatielogboeken
------------------------

  Tijdens de installatie worden er twee logboeken gemaakt. Het ene logboek is
  specifiek voor XJ1 en bevat informatie over aangepaste actie voor het product. 
  Dit logboek heet "xe1instlog.txt" en wordt altijd in de directory temp
  van de gebruiker gemaakt.

  Het andere logboek is het MSI-logboek van Microsoft dat informatie bevat over
  MSI-events, -sequences en -eigenschappen. Dit logboek heet standaard
  "xe1instlogmsi.txt" en wordt in de directory temp van de gebruiker gemaakt.   
   U kunt dit logboek wijzigen door setup.ini in het installatie-image te
   wijzigen. Ga naar het sleutelwoord [Startup] en bewerk dit item: 

  CmdLine=/l*vx "%temp%\xj1instlogmsi.txt"

    - Verwijder de gegevens als u niet wilt dat een logboek wordt gemaakt
    - Wijzig het pad en de bestandsnaam om de locatie en naam van het logboek
      te wijzigen
    - Als u de inhoud van het logboek wilt wijzigen, wijzigt u /l* in (een)
      andere optie(s) zoals wordt beschreven in Windows Installer Command Line
      Options op de MSDN-website van Microsoft: 

      http://msdn.microsoft.com/default.aspx   

  De standaardgegevens voor de opdrachtregel in setup.ini kunnen worden
  overschreven door setup.exe te starten bij de opdrachtaanwijzing met opties
  voor de opdrachtregel.




-------------------------------------------------------------------

4.0 IBM.Data.DB2.iSeries .NET Provider-vereisten 

-------------------------------------------------------------------

  - Voor IBM i Access for Windows .NET Provider
    (IBM.Data.DB2.iSeries) moet .NET Framework 2.0 of hoger van Microsoft
    op uw systeem zijn geïnstalleerd. Op de meeste PC's met een ondersteund
    Microsoft-besturingssysteem is het vereiste .NET Framework al geïnstalleerd.
    Het .NET Framework kan worden gedownload van de volgende
    Microsoft-website: 

    http://www.microsoft.com/net     

  

  - Als u wilt voorkomen dat .NET-toepassingen die zijn geschreven voor Access for Windows 5.3
    of 5.4 .NET Provider, worden onderbroken, moeten runtimeaanvragen voor versie 10.0.0.0
    van de .NET provider worden doorgestuurd naar versie 12.0.0.0.
    Raadpleeg het onderwerp Incompatible changes from 5.3 and 5.4 in
    de IBM DB2 for i .NET Provider Technical Reference voor instructies over
    het gebruik van een app.config-bestand, een web.config-bestand of een
    machine.config-bestand en voor informatie over de selectie van een passend
    compileerprogramma voor het doorsturen van bestaande toepassingen.

    De toepassing kan ook opnieuw worden gecompileerd met een nieuwere compiler die kan werken
    met versie 12.0.0.0 van .NET Provider in release 7.1 van IBM i Access for Windows. 

  - Voor volledige informatie en een lijst met incompatibele wijzigingen
    installeert u de voorziening Headers, Bibliotheken en Documentatie
    en opent u vervolgens .NET Provider Technical Reference. 

-------------------------------------------------------------------

5.0 Microsoft XML Parser of Microsoft XML Core Services


-------------------------------------------------------------------

  Als u de ActiveX-automatiseringsobjecten van IBM i Access for Windows Data
  Transfer gebruikt voor het overdragen van bestanden vanuit de Microsoft
  Excel XML-indeling (ondersteund door Excel 2003 en Excel XP), moet er
  extra software op uw PC worden geïnstalleerd. Voor deze voorziening moet de
  Microsoft XML Parser 3.0 of hoger, ook wel Microsoft XML Core Services
  genoemd, op uw PC zijn geïnstalleerd. De XML Parser is opgenomen in veel
  Microsoft-producten. Om te bepalen of de ondersteuning voor de XML
  Parser is geïnstalleerd, raadpleegt u kunt u Microsoft KB-artikel 278674. U
  kunt dit artikel vinden op de Microsoft-website:

  http://support.microsoft.com/kb/278674

  Als Microsoft XML Parser 3.0 of hoger niet wordt gevonden, kunt u op de Microsoft-website instructies vinden voor
  het downloaden en installeren van de XML Parser voordat u de
  ondersteuning voor de overdracht van XML-gegevens kunt gebruiken. Raadpleeg Microsoft KB-artikel 324460
  voor informatie over het installeren van de XML Parser. U kunt dit artikel vinden op:

  http://support.microsoft.com/kb/324460


-------------------------------------------------------------------

6.0 Uitgebreide installatie-informatie

-------------------------------------------------------------------

  - U kunt de meeste informatie over het aanpassen van het niveau van de
    gebruikersinterface, het gebruik van parameters op de opdrachtregel
    en het kiezen van andere installatie-opties en methoden van ingebruikname
    gebruiken in het onderwerp 'De PC installeren' in het IBM i
    Informatiecentrum voor IBM i Access for Windows. Verschillen
    worden in dit gedeelte beschreven.



6.1 Informatie over gelicentieerde producten
--------------------------------------------

  5733XJ1 is niet als Gelicentieerd product verpakt voor installatie in het
  IBM i-besturingssysteem. Het is alleen beschikbaar in de vorm van PC-media.
  U kunt het desgewenst naar de IBM i kopiëren op een locatie die voor uw
  gebruikers toegankelijke is.
  

6.2 Taalbestanden in het installatie-image
--------------------------------------------

  De installatiebestanden voor verschillende talen zijn niet meer in aparte
  directory's met naam MRI29xx in het installatie-image ondergebracht. In
  plaats daarvan zijn er afzonderlijke CAB-bestanden voor elke taal.
  U kunt deze CAB-bestanden niet uit het image verwijderen.



6.3 Installatiefuncties
-----------------------

  Bepaalde installatiefuncties in IBM i Access for Windows waren afhankelijk
  van andere installatiefuncties die geïnstalleerd werden. Deze beperking is
  niet van toepassing op dit pakket.


  De volgende installatiefuncties moeten verplicht geïnstalleerd worden: req
  (vereiste programma's) langacs, amri2924 (English)

  Alle andere installatiefuncties worden standaard geïnstalleerd, maar u kunt
  ze aanpassen.


  Talen zijn nu installatiefuncties, net als Vereiste programma's, ODBC, etc.
  Omdat talen Installatiefuncties zijn, kunt u aangeven welke talen worden
  geïnstalleerd. Dit gaat met dezelfde methoden die ook worden gebruikt voor
  het installeren van andere voorzieningen. De namen van de installatiefuncties
  zijn amri29xx.  


6.4 Opties voor de opdrachtregel
--------------------------------

  De standaard opdrachtregelopties worden aangegeven in het bestand
  setup.ini dat zich in het installatie-image bevindt. Deze opties worden
  genegeerd als u setup.exe start vanaf de opdrachtregel met daarbij een
  aantal opties.  

  Als u op de opdrachtregel een conversie gebruikt, worden de waarden op de
  opdrachtregel in setup.ini genegeerd, omdat de conversie een optie is. U
  dient andere opties op de opdrachtregel op te nemen, bijvoorbeeld over
  logboekregistratie.

  Zie deel 3.7 Installatielogboeken voor meer informatie.


6.5 Openbare eigenschappen
--------------------------

  Een aantal van de openbare eigenschappen van IBM i Access for Windows zijn
  van toepassing op dit pakket. Het gebruik is iets anders dan in IBM i Access
  for Windows, zie hieronder:

  CWBINSTALLTYPE   Deze eigenschap wordt gebruikt als er voor de eerste keer
                   geïnstalleerd wordt. De enige waarden zijn Typical en
                   Custom. De standaardwaarde is "Typical".
                   Voorbeeld:  setup /vCWBINSTALLTYPE=Typical

  CWBPRIMARYLANG   De standaard primaire taal is de locale van uw PC. Met
                   deze eigenschap kunt u een andere primaire taal opgeven.
                   De te gebruiken waarde is MRI29xx. 
                   Voorbeeld:  setup /vCWBPRIMARYLANG=MRI2923

  CWBUPGSSLFILES   Het gebruik van deze eigenschap is hetzelfde als voor
                   IBM i Access for Windows. U kunt hiermee tijdens een upgrade
                   de SSL-bestanden upgraden. Als de configuratiebestanden voor
                   SSL op de doel-PC worden gevonden, worden de bestanden
                   bijgewerkt met de recentste certificaten. De waarden zijn Yes
                   en No. De standaardwaarde is Yes.
                   Voorbeeld:  setup /vCWBUPGSSLFILES=NO

  De algemene eigenschappen van Windows Installer die in het Informatiecentrum
  van IBM i Access for Windows worden genoemd, blijven van toepassing: ADDLOCAL,
  REMOVE, INSTALLDIR, TARGETDIR.  

  Er geldt een beperking voor het gebruik van de Windows Installer-eigenschap
  REBOOT bij IBM i Access for Windows. Deze beperking is niet van toepassing op
  dit pakket. 

6.6 Beheer-images naar CD of DVD branden
----------------------------------------

      Als gevolg van de problemen die optreden als bepaalde CD- en
      DVD-brandsoftware met lange namen moeten werken, wordt het branden van
      een beheer-image op een CD of DVD niet aanbevolen. Als u problemen
      ondervindt bij installatie vanaf een CD of DVD met een beheer-image van
      IBM i Access for Windows, kopieert u de image naar een directory
      op de lokale vaste schijf en start u setup.exe vanuit de lokale kopie.

-------------------------------------------------------------------
7.0 Informatie over beleidsdefinities
-------------------------------------------------------------------

  Hetzelfde beleidsbestand als dat voor IBM i Access for Windows wordt gebruikt
  voor dit pakket. Dit betekent dat een aantal van deze beleidsdefinities
  niet van toepassing zijn als ze voor dit pakket worden gebruikt, omdat een
  aantal van de functies in IBM i Access for Windows niet in dit pakket
  aanwezig is.


-------------------------------------------------------------------

8.0 Opdrachten
-------------------------------------------------------------------

  De volgende opdrachten van IBM i Access for Windows zijn niet in dit pakket
  inbegrepen:
    cwbdsk.exe
    cwbemcup.exe
    cwbinplg.exe
    cwbin5250.exe
    cwbunins.exe
    cwblaunch.exe
    cwblog.exe
    cwbsvd.exe
    cwbtf.exe
    cwbuisxe.exe
    cwbunnav.exe
    cwbunrse.exe
    cwb3uic.exe
    lstsplf.exe
    rmtcmd.exe
    rfrompcb.exe
    rtopcb.exe
    rxferpcb.exe
    srvview.exe
    strapp.exe

[Einde van document]
